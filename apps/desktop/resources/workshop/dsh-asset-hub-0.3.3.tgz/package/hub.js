/**
 * Minimal HTTP client for the Capability Asset Center API (v1).
 *
 * Pure Node module: no Cordis imports, so it can be smoke-tested directly.
 * Uses node:http / node:https instead of fetch so a self-signed certificate can
 * be accepted per request (`insecureTLS`) without changing process-wide TLS
 * settings.
 */

import http from 'node:http'
import https from 'node:https'
import { randomBytes } from 'node:crypto'

const KINDS = new Set(['mcp', 'skill', 'plugin'])
const MAX_DOWNLOAD_BYTES = 80 * 1024 * 1024

export class HubError extends Error {
  constructor({ status = 0, code = 'HUB_ERROR', message = '请求失败', details = undefined } = {}) {
    super(message)
    this.name = 'HubError'
    this.status = status
    this.code = code
    this.details = details
  }
}

export function normalizeBaseUrl(input) {
  let value = String(input ?? '').trim()
  if (value === '') return ''
  if (!/^https?:\/\//i.test(value)) value = `https://${value}`
  value = value.replace(/\/+$/, '')
  let url
  try {
    url = new URL(value)
  } catch {
    throw new HubError({ code: 'INVALID_BASE_URL', message: `无效的服务地址：${input}` })
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    throw new HubError({ code: 'INVALID_BASE_URL', message: '服务地址只能是 http 或 https' })
  }
  return url.toString().replace(/\/+$/, '')
}

export function defaultInsecureTls(baseUrl) {
  try {
    const url = new URL(baseUrl)
    return url.protocol === 'https:' && /^\d{1,3}(\.\d{1,3}){3}$/.test(url.hostname)
  } catch {
    return false
  }
}

export function assertKind(kind) {
  if (!KINDS.has(kind)) throw new HubError({ code: 'VALIDATION_ERROR', message: `未知的资产类型：${kind}` })
  return kind
}

function joinQuery(path, query) {
  if (!query) return path
  const params = new URLSearchParams()
  for (const [key, value] of Object.entries(query)) {
    if (value === undefined || value === null || value === '') continue
    if (Array.isArray(value)) {
      for (const item of value) if (item !== undefined && item !== null && item !== '') params.append(key, String(item))
    } else {
      params.append(key, String(value))
    }
  }
  const search = params.toString()
  return search ? `${path}?${search}` : path
}

function headerValue(headers, name) {
  const value = headers?.[name]
  return Array.isArray(value) ? value[0] : value
}

function once(url, { method, headers, body, insecureTLS, timeoutMs }) {
  return new Promise((resolve, reject) => {
    const isHttps = url.protocol === 'https:'
    const transport = isHttps ? https : http
    const options = {
      method,
      headers,
      timeout: timeoutMs,
    }
    if (isHttps) options.rejectUnauthorized = !insecureTLS
    if (body) {
      options.headers = { ...headers, 'content-length': body.length }
    }
    const req = transport.request(url, options, (res) => {
      const chunks = []
      let size = 0
      res.on('data', (chunk) => {
        size += chunk.length
        if (size > MAX_DOWNLOAD_BYTES) {
          req.destroy(new HubError({ code: 'PAYLOAD_TOO_LARGE', message: '响应体超过 80MB 上限' }))
          return
        }
        chunks.push(chunk)
      })
      res.on('end', () => {
        resolve({
          status: res.statusCode ?? 0,
          headers: res.headers,
          body: Buffer.concat(chunks),
        })
      })
      res.on('error', (error) => reject(wrapNetworkError(error, url)))
    })
    req.on('timeout', () => {
      req.destroy(new HubError({ code: 'TIMEOUT', message: `请求超时（${Math.round(timeoutMs / 1000)}s）` }))
    })
    req.on('error', (error) => reject(wrapNetworkError(error, url)))
    if (body) req.write(body)
    req.end()
  })
}

function wrapNetworkError(error, url) {
  if (error instanceof HubError) return error
  const code = error?.code || ''
  if (code === 'ECONNREFUSED') {
    return new HubError({ code: 'NETWORK_ERROR', message: `无法连接 ${url.host}，请检查服务地址和网络` })
  }
  if (code === 'ENOTFOUND') {
    return new HubError({ code: 'NETWORK_ERROR', message: `无法解析主机 ${url.hostname}` })
  }
  if (code === 'DEPTH_ZERO_SELF_SIGNED_CERT' || code === 'SELF_SIGNED_CERT_IN_CHAIN' || code === 'UNABLE_TO_VERIFY_LEAF_SIGNATURE' || code === 'CERT_HAS_EXPIRED') {
    return new HubError({ code: 'TLS_ERROR', message: 'TLS 证书校验失败；自签证书环境请在设置中开启「忽略证书校验」或配置受信任证书' })
  }
  return new HubError({ code: 'NETWORK_ERROR', message: `网络请求失败：${error?.message || String(error)}` })
}

function decodePayload(res) {
  const text = res.body.toString('utf8')
  if (!text) return { text: '', payload: null }
  try {
    return { text, payload: JSON.parse(text) }
  } catch {
    return { text, payload: null }
  }
}

function throwIfFailed(res, payload, text) {
  const failed = res.status < 200 || res.status >= 300 || (payload && payload.success === false)
  if (!failed) return
  const error = payload && typeof payload === 'object' ? payload.error : undefined
  const message =
    (error && typeof error === 'object' && error.message) ||
    (payload && typeof payload.message === 'string' && payload.message) ||
    text.slice(0, 300) ||
    `HTTP ${res.status}`
  throw new HubError({
    status: res.status,
    code: (error && typeof error === 'object' && error.code) || `HTTP_${res.status}`,
    message,
    details: error && typeof error === 'object' ? error.details : undefined,
  })
}

export function buildMultipart(fields, file) {
  const boundary = `----dshAssetHub${randomBytes(10).toString('hex')}`
  const chunks = []
  for (const [key, value] of Object.entries(fields)) {
    if (value === undefined || value === null || value === '') continue
    chunks.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${key}"\r\n\r\n${String(value)}\r\n`, 'utf8'))
  }
  const filename = String(file.filename || 'upload.bin').replace(/["\r\n]/g, '_')
  chunks.push(
    Buffer.from(
      `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${filename}"\r\nContent-Type: application/octet-stream\r\n\r\n`,
      'utf8',
    ),
  )
  chunks.push(file.buffer)
  chunks.push(Buffer.from(`\r\n--${boundary}--\r\n`, 'utf8'))
  return { body: Buffer.concat(chunks), contentType: `multipart/form-data; boundary=${boundary}` }
}

export function envelopeOf(payload) {
  return {
    data: payload && typeof payload === 'object' && 'data' in payload ? payload.data : payload,
    meta: payload && typeof payload === 'object' ? payload.meta : undefined,
  }
}

export function textOf(data) {
  if (typeof data === 'string') return data
  if (data === undefined || data === null) return ''
  return JSON.stringify(data, null, 2)
}

function accessTokenOf(data) {
  const accessToken = typeof data?.access_token === 'string' ? data.access_token : ''
  if (!accessToken) {
    throw new HubError({ code: 'AUTH_INVALID_RESPONSE', message: '登录响应缺少 access_token' })
  }
  return accessToken
}

export class HubClient {
  constructor({ baseUrl, token = '', insecureTLS = false, timeoutMs = 30000 }) {
    this.baseUrl = normalizeBaseUrl(baseUrl)
    if (!this.baseUrl) throw new HubError({ code: 'INVALID_BASE_URL', message: '尚未配置服务地址' })
    this.token = token
    this.insecureTLS = insecureTLS
    this.timeoutMs = timeoutMs
  }

  url(path, query) {
    return new URL(`${this.baseUrl}${joinQuery(path, query)}`)
  }

  headers(extra = {}) {
    const headers = { accept: 'application/json, text/plain, */*', ...extra }
    if (this.token) headers.authorization = `Bearer ${this.token}`
    return headers
  }

  async raw(path, { method = 'GET', query, body, headers, contentType, timeoutMs } = {}) {
    let url = this.url(path, query)
    let payload = body
    let currentMethod = method
    for (let hop = 0; hop <= 3; hop += 1) {
      const res = await once(url, {
        method: currentMethod,
        headers: this.headers({ ...headers, ...(contentType ? { 'content-type': contentType } : {}) }),
        body: payload,
        insecureTLS: this.insecureTLS,
        timeoutMs: timeoutMs ?? this.timeoutMs,
      })
      const location = headerValue(res.headers, 'location')
      if ([301, 302, 303, 307, 308].includes(res.status) && location) {
        const next = new URL(location, url)
        if (next.hostname !== url.hostname) {
          throw new HubError({ status: res.status, code: 'REDIRECT_REFUSED', message: `服务端重定向到了其他主机：${next.host}` })
        }
        if (currentMethod !== 'GET' && currentMethod !== 'HEAD' && res.status !== 307 && res.status !== 308) {
          throw new HubError({
            status: res.status,
            code: 'REDIRECT_REFUSED',
            message: '服务地址返回了重定向且会丢失请求体；请直接把服务地址设为 https 地址',
          })
        }
        url = next
        if (res.status === 303) currentMethod = 'GET'
        continue
      }
      return res
    }
    throw new HubError({ code: 'TOO_MANY_REDIRECTS', message: '服务端重定向次数过多' })
  }

  async json(path, options = {}) {
    const res = await this.raw(path, options)
    const { text, payload } = decodePayload(res)
    throwIfFailed(res, payload, text)
    return envelopeOf(payload)
  }

  async text(path, options = {}) {
    const res = await this.raw(path, options)
    const { text, payload } = decodePayload(res)
    throwIfFailed(res, payload, text)
    if (payload && typeof payload === 'object' && 'success' in payload) {
      const { data } = envelopeOf(payload)
      if (data && typeof data === 'object' && !Array.isArray(data)) {
        if (typeof data.content === 'string') return data.content
        if (typeof data.text === 'string') return data.text
      }
      return textOf(data)
    }
    return text
  }

  async meta() {
    const { data } = await this.json('/api/v1/assets/meta')
    return data
  }

  /**
   * Exchange account credentials for a short-lived access token.
   *
   * The access token is only used to mint a PAT (see createPat); it is never
   * stored. The plugin's long-term credential is always a PAT.
   */
  async login(email, password) {
    const { data } = await this.json('/api/auth/login', {
      method: 'POST',
      body: Buffer.from(JSON.stringify({ email, password }), 'utf8'),
      contentType: 'application/json',
    })
    return accessTokenOf(data)
  }

  /** Mint a PAT with the given scopes, authenticated by a fresh access token. */
  async createPat(accessToken, { name = 'dsh-asset-hub', scopes = ['assets:write'], expiresIn = '180d' } = {}) {
    const client = new HubClient({ baseUrl: this.baseUrl, token: accessToken, insecureTLS: this.insecureTLS, timeoutMs: this.timeoutMs })
    const { data } = await client.json('/api/v1/tokens', {
      method: 'POST',
      body: Buffer.from(JSON.stringify({ name, scopes, expires_in: expiresIn }), 'utf8'),
      contentType: 'application/json',
    })
    const token = typeof data?.token === 'string' ? data.token : ''
    if (!token) throw new HubError({ code: 'AUTH_INVALID_RESPONSE', message: 'PAT 创建响应缺少 token' })
    if (!token.startsWith('ops_pat_')) {
      throw new HubError({
        code: 'AUTH_INVALID_RESPONSE',
        message: 'PAT 创建响应不是 ops_pat_ 令牌；access token / JWT 不能当作 PAT 保存',
      })
    }
    return {
      token,
      id: data.id ?? null,
      scopes: Array.isArray(data.scopes) ? data.scopes : scopes,
      expiresAt: data.expires_at ?? null,
    }
  }

  async list({ kinds, q, category, language, owner, sort, page, pageSize } = {}) {
    const { data, meta } = await this.json('/api/v1/assets', {
      query: { kind: kinds, q, category, language, owner, sort, page, page_size: pageSize },
    })
    return {
      items: Array.isArray(data) ? data : Array.isArray(data?.items) ? data.items : Array.isArray(data?.list) ? data.list : [],
      page: meta?.page ?? page ?? 1,
      pageSize: meta?.page_size ?? pageSize ?? 20,
      total: meta?.total ?? 0,
      hasMore: meta?.has_more ?? false,
    }
  }

  async lookup(kind, owner, slug) {
    assertKind(kind)
    const { data } = await this.json(`/api/v1/assets/${kind}/lookup`, { query: { owner, slug } })
    return data
  }

  async get(kind, id) {
    assertKind(kind)
    const { data } = await this.json(`/api/v1/assets/${kind}/${encodeURIComponent(id)}`)
    return data
  }

  async versions(kind, id) {
    assertKind(kind)
    const { data } = await this.json(`/api/v1/assets/${kind}/${encodeURIComponent(id)}/versions`)
    return Array.isArray(data) ? data : Array.isArray(data?.items) ? data.items : Array.isArray(data?.versions) ? data.versions : []
  }

  async manifest(kind, id, version) {
    assertKind(kind)
    return this.text(`/api/v1/assets/${kind}/${encodeURIComponent(id)}/manifest`, { query: { version } })
  }

  async files(kind, id, version) {
    assertKind(kind)
    const { data } = await this.json(`/api/v1/assets/${kind}/${encodeURIComponent(id)}/files`, { query: { version } })
    return data
  }

  async file(kind, id, path, version) {
    assertKind(kind)
    const encoded = String(path)
      .split('/')
      .map((segment) => encodeURIComponent(segment))
      .join('/')
    return this.text(`/api/v1/assets/${kind}/${encodeURIComponent(id)}/files/${encoded}`, { query: { version, format: 'json' } })
  }

  async me({ page, pageSize } = {}) {
    const { data, meta } = await this.json('/api/v1/me/assets', { query: { page, page_size: pageSize } })
    return {
      items: Array.isArray(data) ? data : Array.isArray(data?.items) ? data.items : [],
      total: meta?.total ?? 0,
      page: meta?.page ?? page ?? 1,
      pageSize: meta?.page_size ?? pageSize ?? 20,
      hasMore: meta?.has_more ?? false,
    }
  }

  async admin({ kinds, status, q, owner, includeDeleted, page, pageSize } = {}) {
    const { data, meta } = await this.json('/api/v1/admin/assets', {
      query: {
        kind: kinds,
        status,
        q,
        owner,
        include_deleted: includeDeleted ? 'true' : undefined,
        page,
        page_size: pageSize,
      },
    })
    return {
      items: Array.isArray(data) ? data : Array.isArray(data?.items) ? data.items : [],
      total: meta?.total ?? 0,
      page: meta?.page ?? page ?? 1,
      pageSize: meta?.page_size ?? pageSize ?? 20,
      hasMore: meta?.has_more ?? false,
    }
  }

  async publish({ kind, file, fields = {}, ifMatch }) {
    assertKind(kind)
    const { body, contentType } = buildMultipart({ kind, ...fields }, file)
    const { data } = await this.json('/api/v1/assets', {
      method: 'POST',
      body,
      contentType,
      headers: ifMatch ? { 'if-match': ifMatch } : {},
      timeoutMs: 180000,
    })
    return data
  }

  async publishVersion({ kind, id, file, version, changelog, ifMatch }) {
    assertKind(kind)
    const { body, contentType } = buildMultipart({ version, changelog }, file)
    const { data } = await this.json(`/api/v1/assets/${kind}/${encodeURIComponent(id)}/versions`, {
      method: 'POST',
      body,
      contentType,
      headers: ifMatch ? { 'if-match': ifMatch } : {},
      timeoutMs: 180000,
    })
    return data
  }

  async replace({ kind, id, file, fields = {}, ifMatch }) {
    assertKind(kind)
    const { body, contentType } = buildMultipart(fields, file)
    const { data } = await this.json(`/api/v1/assets/${kind}/${encodeURIComponent(id)}`, {
      method: 'PUT',
      body,
      contentType,
      headers: ifMatch ? { 'if-match': ifMatch } : {},
      timeoutMs: 180000,
    })
    return data
  }

  async updateMeta(kind, id, patch, ifMatch) {
    assertKind(kind)
    const body = Buffer.from(JSON.stringify(patch), 'utf8')
    const { data } = await this.json(`/api/v1/assets/${kind}/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body,
      contentType: 'application/json',
      headers: ifMatch ? { 'if-match': ifMatch } : {},
    })
    return data
  }

  async remove(kind, id, { hard = false } = {}) {
    assertKind(kind)
    const res = await this.raw(`/api/v1/assets/${kind}/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      query: { hard: hard ? '1' : undefined },
    })
    const { text, payload } = decodePayload(res)
    throwIfFailed(res, payload, text)
    return true
  }

  async suspend(kind, id) {
    assertKind(kind)
    const { data } = await this.json(`/api/v1/assets/${kind}/${encodeURIComponent(id)}/suspend`, { method: 'POST' })
    return data
  }

  async restore(kind, id) {
    assertKind(kind)
    const { data } = await this.json(`/api/v1/assets/${kind}/${encodeURIComponent(id)}/restore`, { method: 'POST' })
    return data
  }

  async download(kind, id, version) {
    assertKind(kind)
    const res = await this.raw(`/api/v1/assets/${kind}/${encodeURIComponent(id)}/download`, {
      query: { version },
      timeoutMs: 180000,
    })
    if (res.status < 200 || res.status >= 300) {
      const { text, payload } = decodePayload(res)
      throwIfFailed(res, payload, text)
    }
    const disposition = String(headerValue(res.headers, 'content-disposition') || '')
    let filename = ''
    const utf8 = /filename\*=UTF-8''([^;]+)/i.exec(disposition)
    const plain = /filename="?([^";]+)"?/i.exec(disposition)
    if (utf8) {
      try {
        filename = decodeURIComponent(utf8[1])
      } catch {
        filename = utf8[1]
      }
    } else if (plain) {
      filename = plain[1]
    }
    if (!filename) {
      const ext = kind === 'plugin' ? 'tgz' : 'zip'
      filename = `${kind}-${id}${version ? `-${version}` : ''}.${ext}`
    }
    return {
      buffer: res.body,
      filename,
      contentType: headerValue(res.headers, 'content-type') || 'application/octet-stream',
    }
  }
}
