/**
 * Client half of the Ops Workshop Repository plugin.
 *
 * A full management page for the MCP / Skill / Plugin registry. All hub traffic
 * goes through the Host half at /assets-hub, so the page only needs same-origin
 * fetch. Written as plain JavaScript + React.createElement: no JSX, no imports.
 */

window.__ModuleLoader__.load({
  id: 'dsh-asset-hub',
  factory(require) {
    const React = require('react')
    const h = React.createElement
    const { useState, useEffect, useRef, useMemo, useCallback, useContext, createContext } = React

    const NS = 'assetHub'
    const PANEL_ID = 'asset-hub'
    const RPC_URL = '/assets-hub/rpc'
    const UPLOAD_URL = '/assets-hub/upload'
    const DOWNLOAD_URL = '/assets-hub/download'
    const PAGE_SIZE = 12
    const KINDS = ['skill', 'mcp', 'plugin']
    const PLUGIN_MAX_BYTES = 20 * 1024 * 1024
    const ASSET_MAX_BYTES = 50 * 1024 * 1024

    // ------------------------------------------------------------------ i18n

    const zh = {
      panel: '工坊插件',
      title: '工坊插件',
      subtitle: '浏览、发布与维护 25.75.3.1 能力资产中心的 MCP · Skill · 插件',
      publish: '发布资产',
      settings: '设置',
      refresh: '刷新',
      searchPlaceholder: '搜索名称、简介或关键词…',
      all: '全部',
      mine: '我的资产',
      sortRecent: '最近更新',
      sortPopular: '最受欢迎',
      sortName: '名称',
      categoryAll: '全部分类',
      loading: '正在加载…',
      retry: '重试',
      emptyTitle: '仓库还是空的',
      emptyHint: '发布第一个 Skill、MCP 或插件包，团队就可以在这里发现它。',
      emptyAction: '发布第一个资产',
      noResultTitle: '没有匹配的资产',
      noResultHint: '换一个关键词或筛选条件试试。',
      clearFilters: '清除筛选',
      totalCount: '共 {n} 个资产',
      pageOf: '第 {page} / {pages} 页',
      prev: '上一页',
      next: '下一页',
      download: '下载',
      publishVersion: '发新版本',
      edit: '编辑',
      delete: '删除',
      back: '返回列表',
      overview: '概览',
      versions: '版本',
      files: '文件',
      manifest: '原生清单',
      install: '安装',
      installToDsh: '安装到 DSH',
      updateAvailable: '可更新',
      updatesAvailable: '有 {count} 个已安装资产可更新',
      installedCount: '已安装 {n}',
      updatesHint: '点击条目查看详情，在详情页完成更新。',
      updateTo: '更新到 v{version}',
      updating: '正在更新…',
      updateTitle: '更新资产',
      updatePluginConfirm: '更新会先卸载 v{from}，再安装 v{to}。',
      updateSelfConfirm: '更新会先卸载当前的运维工坊仓库 v{from}，再安装 v{to}；页面会短暂断开，完成后请刷新。',
      updateSkillConfirm: '会用 v{to} 覆盖本地技能目录并重新注册（当前 v{from}）。',
      updateMcpConfirm: '会把 MCP 连接从 v{from} 更新到 v{to}。',
      updateSuccess: '已更新',
      selfUpdateNotice: '正在更新，页面会短暂断开；完成后请刷新页面。',
      installNow: '安装到 DSH',
      installing: '正在安装…',
      installed: '已安装',
      uninstall: '卸载',
      uninstalling: '正在卸载…',
      installHintPlugin: '把插件安装到当前 DSH profile，安装后出现在插件列表。',
      installWarnPlugin: '安装会执行包内代码，请只安装可信来源的插件。',
      installWarnMcp: 'MCP 服务器会按配置访问网络或启动本地进程，请确认来源可信。',
      installHintSkill: '写入本地技能目录并注册到 skill 目录，下一轮对话即可使用。',
      installHintMcp: '生成 MCP 连接并安装到当前 profile，工具以 mcp__<server>__<tool> 出现。',
      installUnavailable: '当前部署没有可用的安装通道。',
      installSuccess: '安装完成',
      installAlready: '已安装，无需重复安装',
      uninstallSuccess: '已卸载',
      uninstallTitle: '卸载资产',
      uninstallConfirm: '确定要从 DSH 卸载「{name}」吗？',
      restartRequired: '安装完成，但需要重启 DSH 才能生效。',
      installSkipped: '已跳过 {n} 个二进制或超限文件。',
      installResult: '安装结果',
      managedElsewhere: '已安装（非本页面安装）',
      installHint: '把下面的 spec 交给 Harness 的插件安装入口即可。',
      copy: '复制',
      copied: '已复制',
      copyFailed: '复制失败，请手动选择',
      description: '说明',
      details: '元数据',
      category: '分类',
      language: '语言',
      visibility: '可见性',
      owner: '发布者',
      updated: '更新时间',
      downloads: '下载量',
      tags: '标签',
      noDescription: '这个资产还没有填写说明。',
      noVersions: '暂无版本记录。',
      noFiles: '没有可浏览的文件。',
      preview: '预览',
      fileTooLarge: '文件超过 2MB，请下载整包查看。',
      binaryFile: '二进制文件不支持在线预览。',
      deleteTitle: '删除资产',
      deleteConfirm: '确定要删除「{name}」吗？删除后会立即从列表、市场索引和安装入口消失。',
      cancel: '取消',
      confirmDelete: '删除',
      deleting: '正在删除…',
      publishTitle: '发布新资产',
      versionTitle: '发布新版本',
      publishSubtitle: '上传 Skill / MCP 的 .zip 包，或 Harness 插件的 .tgz 包。',
      kind: '类型',
      file: '包文件',
      chooseFile: '选择文件',
      dropHint: '把包拖到这里，或点击选择文件',
      changeFile: '更换文件',
      slug: 'Slug',
      slugHint: '留空则按名称自动生成，kebab-case',
      name: '名称',
      summary: '一句话简介',
      version: '版本',
      changelog: '更新说明',
      visibilityPublic: '公开',
      visibilityUnlisted: '不列出（有链接可访问）',
      visibilityPrivate: '私有',
      submit: '发布',
      publishing: '正在上传…',
      publishSuccess: '发布成功',
      versionSuccess: '新版本已发布',
      updateSuccess: '元数据已更新',
      deleteSuccess: '资产已删除',
      downloadSuccess: '开始下载',
      settingsTitle: '工坊插件设置',
      baseUrl: '服务地址',
      baseUrlHint: '例如 https://25.75.3.1，自签证书环境可开启下方选项。',
      account: '账号',
      authMode: '获取方式',
      authModeAccount: '账号密码换 PAT',
      authModePat: '直接填写 PAT',
      pat: '访问令牌（PAT）',
      patHint: '在运维工坊用户名下拉「访问令牌」页面创建；只读场景用 assets:read，发布/发版/删除用 assets:write（写权限隐含读），写权限最长 180 天。',
      patPlaceholder: 'ops_pat_...',
      savePat: '保存并验证',
      verifyingPat: '正在验证…',
      patSaved: 'PAT 已保存',
      patRequired: '请输入访问令牌',
      patInvalid: 'PAT 无效或已过期',
      patLogin: '已保存 PAT（末尾 {tail}）',
      patSession: '当前使用 PAT；过期后重新填写，或用账号重新签发。',
      patBadge: 'PAT',
      createPat: '创建访问令牌',
      patReadOnly: '只读令牌只能浏览和下载；发布/编辑/删除需要 assets:write。',
      email: '邮箱/手机/用户名',
      emailPlaceholder: '邮箱 / 手机号 / 用户名',
      emailRequired: '请输入邮箱/手机号/用户名',
      passwordRequired: '请输入密码',
      password: '密码',
      passwordPlaceholder: '账号密码',
      login: '登录并保存 PAT',
      loggingIn: '正在登录…',
      loginSuccess: '登录成功，已创建并保存 PAT',
      loginHint: '用运维工坊账号登录，插件会创建含 assets:write 的 PAT 并保存（写权限隐含读）；密码不保存，之后只用 PAT。',
      httpWarning: '当前是 http 地址，账号密码会以明文经过网络；建议改用 https。',
      expires: 'PAT 有效期',
      scopes: '权限',
      scopeMissing: '当前 PAT 缺少 {scope}；浏览/下载仍可用，但发布、发版、删除会失败。请用账号重新登录签发写权限 PAT，或填写含 assets:write 的 PAT（写权限隐含读）。',
      legacyHint: '检测到旧版账号会话（JWT），该方式已停用；请重新登录或填写 PAT。',
      logout: '清除 PAT',
      loggedOut: '已清除 PAT',
      notLoggedIn: '尚未配置 PAT',
      loggedInAs: '账号：{email}',
      sessionExpires: 'PAT 有效期至 {time}',
      saveAddress: '保存地址',
      addressSaved: '服务地址已保存',
      authExpired: 'PAT 无效或已过期，请重新登录或填写 PAT',
      loginRequired: '需要 PAT 才能执行这个操作',
      switchAccount: '切换账号',
      insecureTLS: '忽略 TLS 证书校验',
      insecureTLHint: '仅用于自签证书的内网环境。',
      test: '测试连接',
      testing: '正在连接…',
      testOk: '连接成功：{kinds}',
      save: '保存',
      saving: '正在保存…',
      saved: '设置已保存',
      reauthHint: '修改服务地址会退出当前登录。',
      required: '必填',
      fileRequired: '请选择要上传的包文件',
      versionRequired: '请填写版本号',
      invalidSlug: 'Slug 只能包含小写字母、数字和连字符',
      tooBig: '包体超过大小上限（插件 20MB，其他 50MB）',
      wrongExtension: '这个类型需要 {ext} 包',
      errorTitle: '操作失败',
      close: '关闭',
      editTitle: '编辑元数据',
      saveChanges: '保存修改',
      loginMissing: '尚未配置 PAT，目前只能浏览公开资产。',
      configureNow: '去设置',
      publicBadge: '公开',
      unlistedBadge: '不列出',
      privateBadge: '私有',
      latest: '最新',
      publishedAt: '发布于',
      size: '大小',
      detailLoading: '正在读取资产详情…',
      detailFailed: '读取详情失败',
      readFailed: '读取文件失败',
      manifestEmpty: '清单为空',
      noTokenAction: '请先在设置里登录或填写 PAT，再发布、编辑或删除。',
      versionOptional: '插件版本从 package.json 读取，可留空',
      loadingMore: '正在加载更多…',
      kindSkill: 'Skill',
      kindMcp: 'MCP',
      kindPlugin: '插件',
      installMethod: '方式',
      installSpec: 'spec',
      installRegistry: 'registry',
      hostCompat: '宿主兼容',
      none: '—',
      status: '状态',
      statusSuspended: '已下架',
      healthOk: '服务正常',
      copySpec: '复制安装命令',
    }

    const en = {
      panel: 'Workshop Plugin',
      title: 'Workshop Plugin',
      subtitle: 'Browse, publish, and maintain MCP · Skill · plugin assets in the 25.75.3.1 capability asset center',
      publish: 'Publish asset',
      settings: 'Settings',
      refresh: 'Refresh',
      searchPlaceholder: 'Search name, summary, or keywords…',
      all: 'All',
      mine: 'My assets',
      sortRecent: 'Recently updated',
      sortPopular: 'Most downloaded',
      sortName: 'Name',
      categoryAll: 'All categories',
      loading: 'Loading…',
      retry: 'Retry',
      emptyTitle: 'The hub is empty',
      emptyHint: 'Publish the first Skill, MCP, or plugin package so the team can discover it here.',
      emptyAction: 'Publish the first asset',
      noResultTitle: 'No matching assets',
      noResultHint: 'Try another keyword or clear the filters.',
      clearFilters: 'Clear filters',
      totalCount: '{n} assets',
      pageOf: 'Page {page} of {pages}',
      prev: 'Previous',
      next: 'Next',
      download: 'Download',
      publishVersion: 'New version',
      edit: 'Edit',
      delete: 'Delete',
      back: 'Back',
      overview: 'Overview',
      versions: 'Versions',
      files: 'Files',
      manifest: 'Manifest',
      install: 'Install',
      installToDsh: 'Install into DSH',
      updateAvailable: 'Update available',
      updatesAvailable: 'Updates available for {count} installed assets',
      installedCount: '{n} installed',
      updatesHint: 'Open an item to review it and update from its detail page.',
      updateTo: 'Update to v{version}',
      updating: 'Updating…',
      updateTitle: 'Update asset',
      updatePluginConfirm: 'Updating uninstalls v{from}, then installs v{to}.',
      updateSelfConfirm: 'Updating uninstalls the Ops workshop repository v{from} and installs v{to}; the page disconnects briefly, so refresh when it finishes.',
      updateSkillConfirm: 'Update overwrites the local skill directory with v{to} and registers it again (currently v{from}).',
      updateMcpConfirm: 'Update replaces the MCP connection v{from} with v{to}.',
      updateSuccess: 'Updated',
      selfUpdateNotice: 'Updating; the page disconnects briefly. Refresh when it finishes.',
      installNow: 'Install into DSH',
      installing: 'Installing…',
      installed: 'Installed',
      uninstall: 'Uninstall',
      uninstalling: 'Uninstalling…',
      installHintPlugin: 'Install the plugin into the current DSH profile; it appears in the plugin list.',
      installWarnPlugin: 'Installing runs the package code; only install plugins from sources you trust.',
      installWarnMcp: 'An MCP server may access the network or start a local process; make sure you trust its source.',
      installHintSkill: 'Write it into the local skills directory and register it; available from the next turn.',
      installHintMcp: 'Create an MCP connection in the current profile; tools appear as mcp__<server>__<tool>.',
      installUnavailable: 'This deployment has no installation channel available.',
      installSuccess: 'Installed',
      installAlready: 'Already installed',
      uninstallSuccess: 'Uninstalled',
      uninstallTitle: 'Uninstall asset',
      uninstallConfirm: 'Uninstall “{name}” from DSH?',
      restartRequired: 'Installed, but DSH must restart before it takes effect.',
      installSkipped: '{n} binary or oversized files were skipped.',
      installResult: 'Install result',
      managedElsewhere: 'Installed outside this page',
      installHint: 'Hand the spec below to the Harness plugin installer.',
      copy: 'Copy',
      copied: 'Copied',
      copyFailed: 'Copy failed; select the text manually',
      description: 'Description',
      details: 'Metadata',
      category: 'Category',
      language: 'Language',
      visibility: 'Visibility',
      owner: 'Publisher',
      updated: 'Updated',
      downloads: 'Downloads',
      tags: 'Tags',
      noDescription: 'No description yet.',
      noVersions: 'No versions recorded.',
      noFiles: 'No files to browse.',
      preview: 'Preview',
      fileTooLarge: 'Larger than 2MB; download the package instead.',
      binaryFile: 'Binary files cannot be previewed.',
      deleteTitle: 'Delete asset',
      deleteConfirm: 'Delete “{name}”? It disappears from listings, the market index, and installers immediately.',
      cancel: 'Cancel',
      confirmDelete: 'Delete',
      deleting: 'Deleting…',
      publishTitle: 'Publish a new asset',
      versionTitle: 'Publish a new version',
      publishSubtitle: 'Upload a Skill / MCP .zip package or a Harness plugin .tgz package.',
      kind: 'Kind',
      file: 'Package',
      chooseFile: 'Choose file',
      dropHint: 'Drop the package here, or choose a file',
      changeFile: 'Change file',
      slug: 'Slug',
      slugHint: 'Leave blank to derive it from the name; kebab-case',
      name: 'Name',
      summary: 'One-line summary',
      version: 'Version',
      changelog: 'Changelog',
      visibilityPublic: 'Public',
      visibilityUnlisted: 'Unlisted',
      visibilityPrivate: 'Private',
      submit: 'Publish',
      publishing: 'Uploading…',
      publishSuccess: 'Published',
      versionSuccess: 'New version published',
      updateSuccess: 'Metadata updated',
      deleteSuccess: 'Asset deleted',
      downloadSuccess: 'Download started',
      settingsTitle: 'Workshop plugin settings',
      baseUrl: 'Service URL',
      baseUrlHint: 'For example https://25.75.3.1. Enable the option below for a self-signed certificate.',
      account: 'Account',
      authMode: 'Credential',
      authModeAccount: 'Password → PAT',
      authModePat: 'Paste PAT',
      pat: 'Access token (PAT)',
      patHint: 'Create one from the username menu → Access tokens on the portal; assets:read for read-only use, assets:write for publishing (write implies read), up to 180 days.',
      patPlaceholder: 'ops_pat_...',
      savePat: 'Save and verify',
      verifyingPat: 'Verifying…',
      patSaved: 'Access token saved',
      patRequired: 'Enter an access token',
      patInvalid: 'Invalid or expired access token',
      patLogin: 'PAT saved (ending {tail})',
      patSession: 'This session uses a PAT; enter a new one or mint another with your account when it expires.',
      patBadge: 'PAT',
      createPat: 'Create an access token',
      patReadOnly: 'Read-only tokens can browse and download; publishing, editing, and deleting need assets:write.',
      email: 'Email / phone / username',
      emailPlaceholder: 'Email / phone / username',
      emailRequired: 'Enter your email, phone, or username',
      passwordRequired: 'Enter your password',
      password: 'Password',
      passwordPlaceholder: 'Account password',
      login: 'Sign in and save PAT',
      loggingIn: 'Signing in…',
      loginSuccess: 'Signed in; a PAT was created and saved',
      loginHint: 'Sign in with your Ops workshop account; the plugin mints an assets:write PAT (write implies read) and stores it. Your password is not stored; only the PAT is used afterwards.',
      httpWarning: 'This is an http URL, so the account password crosses the network in clear text. Prefer https.',
      expires: 'PAT validity',
      scopes: 'Scopes',
      scopeMissing: 'The current PAT lacks {scope}; browsing and downloads still work, but publishing, versioning, and deleting will fail. Sign in again to mint a write PAT, or paste one with assets:write (write implies read).',
      legacyHint: 'A legacy account session (JWT) was found and is no longer supported; sign in again or paste a PAT.',
      logout: 'Clear PAT',
      loggedOut: 'PAT cleared',
      notLoggedIn: 'No PAT configured',
      loggedInAs: 'Account: {email}',
      sessionExpires: 'PAT valid until {time}',
      saveAddress: 'Save address',
      addressSaved: 'Service URL saved',
      authExpired: 'PAT is invalid or expired; sign in again or paste a new PAT',
      loginRequired: 'A PAT is required for this action',
      switchAccount: 'Switch account',
      insecureTLS: 'Skip TLS certificate verification',
      insecureTLHint: 'Only for an internal deployment with a self-signed certificate.',
      test: 'Test connection',
      testing: 'Connecting…',
      testOk: 'Connected: {kinds}',
      save: 'Save',
      saving: 'Saving…',
      saved: 'Settings saved',
      reauthHint: 'Changing the service URL signs you out.',
      required: 'Required',
      fileRequired: 'Choose a package file to upload',
      versionRequired: 'Enter a version',
      invalidSlug: 'The slug may contain only lowercase letters, digits, and hyphens',
      tooBig: 'Package exceeds the limit (20MB for plugins, 50MB otherwise)',
      wrongExtension: 'This kind needs a {ext} package',
      errorTitle: 'Operation failed',
      close: 'Close',
      editTitle: 'Edit metadata',
      saveChanges: 'Save changes',
      loginMissing: 'No PAT configured, so only public assets can be browsed.',
      configureNow: 'Open settings',
      publicBadge: 'Public',
      unlistedBadge: 'Unlisted',
      privateBadge: 'Private',
      latest: 'latest',
      publishedAt: 'Published',
      size: 'Size',
      detailLoading: 'Loading asset details…',
      detailFailed: 'Could not load the details',
      readFailed: 'Could not read the file',
      manifestEmpty: 'The manifest is empty',
      noTokenAction: 'Sign in or paste a PAT in settings before publishing, editing, or deleting.',
      versionOptional: 'The plugin version comes from package.json; leave blank to read it',
      loadingMore: 'Loading…',
      kindSkill: 'Skill',
      kindMcp: 'MCP',
      kindPlugin: 'Plugin',
      installMethod: 'Method',
      installSpec: 'spec',
      installRegistry: 'registry',
      hostCompat: 'Host compat',
      none: '—',
      status: 'Status',
      statusSuspended: 'Suspended',
      healthOk: 'Service is reachable',
      copySpec: 'Copy install spec',
    }

    const LocaleCtx = createContext((key) => key)
    const useT = () => useContext(LocaleCtx)

    // ------------------------------------------------------------------ icons

    const ICON_PATHS = {
      search: [['circle', { cx: 11, cy: 11, r: 7 }], ['path', { d: 'M20 20l-3.5-3.5' }]],
      plus: [['path', { d: 'M12 5v14M5 12h14' }]],
      refresh: [['path', { d: 'M20 11a8 8 0 1 0-.7 4.3' }], ['path', { d: 'M20 4v7h-7' }]],
      settings: [['path', { d: 'M4 7h10M18 7h2M4 17h2M10 17h10' }], ['circle', { cx: 16, cy: 7, r: 2 }], ['circle', { cx: 8, cy: 17, r: 2 }]],
      download: [['path', { d: 'M12 4v11' }], ['path', { d: 'M7 11l5 5 5-5' }], ['path', { d: 'M5 20h14' }]],
      trash: [['path', { d: 'M4 6h16' }], ['path', { d: 'M9 6V4h6v2' }], ['path', { d: 'M6 6l1 14h10l1-14' }]],
      edit: [['path', { d: 'M12 20h9' }], ['path', { d: 'M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z' }]],
      back: [['path', { d: 'M15 18l-6-6 6-6' }]],
      x: [['path', { d: 'M18 6L6 18M6 6l12 12' }]],
      copy: [['rect', { x: 9, y: 9, width: 11, height: 11, rx: 2 }], ['path', { d: 'M5 15V5a2 2 0 0 1 2-2h10' }]],
      file: [['path', { d: 'M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z' }], ['path', { d: 'M14 3v5h5' }]],
      folder: [['path', { d: 'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z' }]],
      box: [['path', { d: 'M21 8l-9-5-9 5 9 5 9-5z' }], ['path', { d: 'M3 8v8l9 5 9-5V8' }], ['path', { d: 'M12 13v8' }]],
      check: [['path', { d: 'M20 6L9 17l-5-5' }]],
      alert: [['circle', { cx: 12, cy: 12, r: 9 }], ['path', { d: 'M12 7v6M12 17h.01' }]],
      external: [['path', { d: 'M14 4h6v6' }], ['path', { d: 'M20 4l-9 9' }], ['path', { d: 'M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5' }]],
    }

    function Icon({ name, size = 16 }) {
      const shapes = ICON_PATHS[name] || []
      return h(
        'svg',
        {
          width: size,
          height: size,
          viewBox: '0 0 24 24',
          fill: 'none',
          stroke: 'currentColor',
          strokeWidth: 1.7,
          strokeLinecap: 'round',
          strokeLinejoin: 'round',
          'aria-hidden': true,
        },
        shapes.map(([tag, props], index) => h(tag, { key: index, ...props })),
      )
    }

    /** Sidebar mark: a crate with an upload arrow. */
    function AssetHubIcon({ size = 18 }) {
      return h(
        'svg',
        { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', 'aria-hidden': true },
        h('path', {
          d: 'M12 2.6 21 7.3v9.4L12 21.4 3 16.7V7.3z',
          stroke: 'currentColor',
          strokeWidth: 1.5,
          strokeLinejoin: 'round',
        }),
        h('path', { d: 'M12 8.4v6.2M9.2 11.2 12 8.4l2.8 2.8', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round' }),
        h('path', { d: 'M3.4 7.5 12 12l8.6-4.5' , stroke: 'currentColor', strokeWidth: 1.2, opacity: 0.5 }),
      )
    }

    // ----------------------------------------------------------------- utils

    async function rpc(method, params) {
      const response = await fetch(RPC_URL, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ method, params: params ?? {} }),
      })
      let body
      try {
        body = await response.json()
      } catch {
        throw Object.assign(new Error(`HTTP ${response.status}`), { code: `HTTP_${response.status}` })
      }
      if (!response.ok || !body || body.ok !== true) {
        const error = body && body.error ? body.error : {}
        const failure = new Error(error.message || `HTTP ${response.status}`)
        failure.code = error.code
        failure.status = error.status ?? response.status
        failure.details = error.details
        throw failure
      }
      return body.data
    }

    async function uploadPackage(meta, file) {
      const metaBytes = new TextEncoder().encode(JSON.stringify(meta))
      const head = new Uint8Array(4)
      new DataView(head.buffer).setUint32(0, metaBytes.length, false)
      const body = new Blob([head, metaBytes, file])
      const response = await fetch(UPLOAD_URL, {
        method: 'POST',
        headers: { 'content-type': 'application/octet-stream' },
        body,
      })
      let payload
      try {
        payload = await response.json()
      } catch {
        throw Object.assign(new Error(`HTTP ${response.status}`), { code: `HTTP_${response.status}` })
      }
      if (!response.ok || !payload || payload.ok !== true) {
        const error = payload && payload.error ? payload.error : {}
        const failure = new Error(error.message || `HTTP ${response.status}`)
        failure.code = error.code
        failure.status = error.status ?? response.status
        throw failure
      }
      return payload.data
    }

    function formatBytes(value) {
      const bytes = Number(value)
      if (!Number.isFinite(bytes) || bytes <= 0) return ''
      if (bytes < 1024) return `${bytes} B`
      if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
      return `${(bytes / 1024 / 1024).toFixed(1)} MB`
    }

    function parseTime(value) {
      if (value === undefined || value === null || value === '') return 0
      if (typeof value === 'number') return value < 1e12 ? value * 1000 : value
      const numeric = Number(value)
      if (Number.isFinite(numeric) && String(value).trim() !== '') return numeric < 1e12 ? numeric * 1000 : numeric
      const parsed = Date.parse(value)
      return Number.isFinite(parsed) ? parsed : 0
    }

    function formatDate(value) {
      const time = parseTime(value)
      if (!time) return '—'
      try {
        return new Date(time).toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })
      } catch {
        return '—'
      }
    }

    function toList(value) {
      if (Array.isArray(value)) return value
      if (typeof value === 'string') {
        return value
          .split(',')
          .map((item) => item.trim())
          .filter(Boolean)
      }
      return []
    }

    function assetId(asset) {
      return asset?.id ?? asset?.asset_id ?? asset?.assetId
    }

    function assetKind(asset) {
      return asset?.kind ?? asset?.type ?? ''
    }

    function assetVersion(asset) {
      const direct = asset?.version ?? asset?.latest_version ?? asset?.latestVersion ?? asset?.current_version
      if (direct) return String(direct)
      if (Array.isArray(asset?.versions) && asset.versions.length > 0) {
        const first = asset.versions[0]
        return typeof first === 'string' ? first : first?.version
      }
      return ''
    }

    function assetName(asset) {
      return asset?.name || asset?.display_name || asset?.slug || asset?.package_name || `#${assetId(asset)}`
    }

    function assetSlug(asset) {
      return asset?.slug || asset?.package_name || ''
    }

    function assetSummary(asset) {
      return asset?.summary || asset?.tagline || ''
    }

    function assetDescription(asset) {
      return asset?.description || asset?.readme || ''
    }

    function assetOwner(asset) {
      const owner = asset?.owner_name ?? asset?.owner ?? asset?.author_name ?? asset?.publisher
      if (owner && typeof owner === 'object') return owner.name || owner.display_name || owner.email || ''
      return owner ? String(owner) : ''
    }

    function assetUpdated(asset) {
      return asset?.updated_at ?? asset?.updatedAt ?? asset?.published_at ?? asset?.created_at ?? asset?.createdAt
    }

    function assetDownloads(asset) {
      const value = asset?.downloads ?? asset?.download_count ?? asset?.stats?.downloads
      return Number.isFinite(Number(value)) ? Number(value) : null
    }

    function assetVisibility(asset) {
      return asset?.visibility || 'public'
    }

    function assetStatusValue(asset) {
      return asset?.status || (asset?.suspended_at ? 'suspended' : 'published')
    }

    function kindKey(kind) {
      if (kind === 'mcp') return 'kindMcp'
      if (kind === 'plugin') return 'kindPlugin'
      return 'kindSkill'
    }

    function kindClass(kind) {
      return kind === 'mcp' ? 'mcp' : kind === 'plugin' ? 'plugin' : 'skill'
    }

    function visibilityKey(visibility) {
      if (visibility === 'private') return 'privateBadge'
      if (visibility === 'unlisted') return 'unlistedBadge'
      return 'publicBadge'
    }

    function normalizeCategories(meta) {
      const raw = meta?.categories
      const list = Array.isArray(raw) ? raw : raw && typeof raw === 'object' ? Object.keys(raw) : []
      return list
        .map((item) => (typeof item === 'string' ? item : item?.category || item?.name || item?.value))
        .filter((item) => typeof item === 'string' && item !== '')
    }

    function normalizeKinds(meta) {
      const raw = meta?.kinds
      const list = Array.isArray(raw) ? raw : raw && typeof raw === 'object' ? Object.keys(raw).map((kind) => ({ kind, count: raw[kind] })) : []
      return list
        .map((item) => (typeof item === 'string' ? { kind: item, count: null } : { kind: item?.kind, count: item?.count }))
        .filter((item) => KINDS.includes(item.kind))
    }

    function flattenFiles(input) {
      const out = []
      const seen = new Set()
      const walk = (node, prefix) => {
        if (node === undefined || node === null) return
        if (typeof node === 'string') {
          const path = prefix ? `${prefix}/${node}` : node
          if (!seen.has(path)) {
            seen.add(path)
            out.push({ path, type: 'file' })
          }
          return
        }
        if (Array.isArray(node)) {
          for (const child of node) walk(child, prefix)
          return
        }
        if (typeof node !== 'object') return
        for (const key of ['files', 'tree', 'entries', 'items', 'children']) {
          if (Array.isArray(node[key])) {
            walk(node[key], prefix)
            return
          }
        }
        const name = node.path || node.name || node.filename || node.file
        const isDir = node.type === 'dir' || node.type === 'directory' || node.is_dir === true || Array.isArray(node.children) || Array.isArray(node.items)
        const path = name ? (prefix && !String(name).includes('/') ? `${prefix}/${name}` : String(name)) : prefix
        if (isDir) {
          const children = node.children || node.items || []
          for (const child of children) walk(child, path)
          return
        }
        if (path && !seen.has(path)) {
          seen.add(path)
          out.push({ path, size: node.size ?? node.bytes, type: 'file' })
        }
      }
      walk(input, '')
      return out.sort((a, b) => a.path.localeCompare(b.path))
    }

    function isAuthError(error) {
      return Boolean(error) && (error.code === 'AUTH_REQUIRED' || error.code === 'UNAUTHORIZED' || error.code === 'PAT_INVALID')
    }

    function errorMessage(error) {
      if (!error) return ''
      let message = error.message || String(error)
      if (error.code && message.indexOf(error.code) === -1) message = `${message}（${error.code}）`
      return message
    }

    const updateStore = (() => {
      let state = { count: 0, updates: [], installed: [], loading: false, error: '', checkedAt: 0 }
      const listeners = new Set()
      let inFlight = null
      let timer = null
      const emit = (patch) => {
        state = { ...state, ...patch }
        for (const listener of listeners) listener(state)
      }
      const refresh = (force = false) => {
        if (inFlight) return inFlight
        if (!force && state.checkedAt && Date.now() - state.checkedAt < 60000) return Promise.resolve(state)
        emit({ loading: true })
        inFlight = rpc('updates', { force: Boolean(force) })
          .then((data) => {
            emit({
              count: Number(data?.count) || 0,
              updates: Array.isArray(data?.updates) ? data.updates : [],
              installed: Array.isArray(data?.installed) ? data.installed : [],
              error: data?.ok === false ? data?.error?.message || '' : '',
              checkedAt: Date.now(),
              loading: false,
            })
          })
          .catch((failure) => {
            emit({ error: errorMessage(failure), loading: false, checkedAt: Date.now() })
          })
          .finally(() => {
            inFlight = null
          })
        return inFlight
      }
      const ensure = () => {
        if (!state.checkedAt) void refresh(false)
      }
      const subscribe = (listener) => {
        listeners.add(listener)
        if (!timer) {
          timer = setInterval(() => {
            if (listeners.size > 0) void refresh(false)
          }, 5 * 60 * 1000)
        }
        return () => {
          listeners.delete(listener)
          if (listeners.size === 0 && timer) {
            clearInterval(timer)
            timer = null
          }
        }
      }
      return { get: () => state, subscribe, refresh, ensure }
    })()

    function useUpdates() {
      const [state, setState] = useState(updateStore.get())
      useEffect(() => {
        const unsubscribe = updateStore.subscribe(setState)
        updateStore.ensure()
        const onFocus = () => {
          void updateStore.refresh(false)
        }
        const onVisibility = () => {
          if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
            void updateStore.refresh(false)
          }
        }
        window.addEventListener('focus', onFocus)
        document.addEventListener('visibilitychange', onVisibility)
        return () => {
          window.removeEventListener('focus', onFocus)
          document.removeEventListener('visibilitychange', onVisibility)
          unsubscribe()
        }
      }, [])
      return state
    }

    function SidebarAssetHubIcon({ size = 18, active, t }) {
      const updates = useUpdates()
      const count = Number(updates.count) || 0
      return h(
        'span',
        { className: 'ah-sidebar-icon' },
        h(AssetHubIcon, { size, active }),
        count > 0
          ? h(
              'span',
              { className: 'ah-sidebar-badge', title: t('updatesAvailable').replace('{count}', String(count)) },
              count > 99 ? '99+' : String(count),
            )
          : null,
      )
    }

    async function copyText(text) {
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(text)
          return true
        }
      } catch {
        /* fall through */
      }
      try {
        const area = document.createElement('textarea')
        area.value = text
        area.style.position = 'fixed'
        area.style.opacity = '0'
        document.body.appendChild(area)
        area.select()
        const ok = document.execCommand('copy')
        area.remove()
        return ok
      } catch {
        return false
      }
    }

    function useDebounced(value, delay) {
      const [debounced, setDebounced] = useState(value)
      useEffect(() => {
        const timer = setTimeout(() => setDebounced(value), delay)
        return () => clearTimeout(timer)
      }, [value, delay])
      return debounced
    }

    // ------------------------------------------------------------ primitives

    function Button({ children, variant = 'default', size = 'md', onClick, disabled, title, type = 'button', busy = false }) {
      return h(
        'button',
        {
          className: `ah-btn ah-btn--${variant} ah-btn--${size}${busy ? ' is-busy' : ''}`,
          onClick,
          disabled: disabled || busy,
          title,
          type,
        },
        busy ? h('span', { className: 'ah-spinner ah-spinner--sm' }) : null,
        children,
      )
    }

    function IconButton({ icon, label, onClick, disabled, danger = false }) {
      return h(
        'button',
        {
          className: `ah-iconbtn${danger ? ' ah-iconbtn--danger' : ''}`,
          onClick,
          disabled,
          title: label,
          'aria-label': label,
          type: 'button',
        },
        h(Icon, { name: icon, size: 15 }),
      )
    }

    function Spinner({ label }) {
      return h('div', { className: 'ah-loading' }, h('span', { className: 'ah-spinner' }), label ? h('span', null, label) : null)
    }

    function KindBadge({ kind }) {
      const t = useT()
      return h('span', { className: `ah-badge ah-badge--${kindClass(kind)}` }, h('span', { className: 'ah-dot' }), t(kindKey(kind)))
    }

    function EmptyState({ title, hint, action }) {
      return h(
        'div',
        { className: 'ah-empty' },
        h('div', { className: 'ah-empty-icon' }, h(Icon, { name: 'box', size: 30 })),
        h('h3', null, title),
        hint ? h('p', null, hint) : null,
        action || null,
      )
    }

    function Modal({ title, onClose, children, width = 560, labelledBy = 'ah-modal-title' }) {
      const t = useT()
      const panelRef = useRef(null)
      const closeRef = useRef(onClose)
      closeRef.current = onClose

      useEffect(() => {
        const onKeyDown = (event) => {
          if (event.key === 'Escape') {
            event.stopPropagation()
            closeRef.current()
          }
        }
        document.addEventListener('keydown', onKeyDown, true)
        const timer = setTimeout(() => {
          const node = panelRef.current
          if (node && typeof node.focus === 'function') node.focus()
        }, 0)
        return () => {
          document.removeEventListener('keydown', onKeyDown, true)
          clearTimeout(timer)
        }
      }, [])

      return h(
        'div',
        {
          className: 'ah-backdrop',
          onMouseDown: (event) => {
            if (event.target === event.currentTarget) onClose()
          },
        },
        h(
          'div',
          {
            className: 'ah-modal',
            style: { maxWidth: width },
            role: 'dialog',
            'aria-modal': 'true',
            'aria-labelledby': labelledBy,
            ref: panelRef,
            tabIndex: -1,
          },
          h(
            'div',
            { className: 'ah-modal-head' },
            h('h2', { id: labelledBy }, title),
            h(IconButton, { icon: 'x', label: t('close'), onClick: onClose }),
          ),
          h('div', { className: 'ah-modal-body' }, children),
        ),
      )
    }

    function Field({ label, hint, children, error }) {
      return h(
        'label',
        { className: 'ah-field' },
        h('span', { className: 'ah-field-label' }, label),
        children,
        error ? h('span', { className: 'ah-field-error' }, error) : hint ? h('span', { className: 'ah-field-hint' }, hint) : null,
      )
    }

    function Toasts({ items }) {
      return h(
        'div',
        { className: 'ah-toasts', role: 'status', 'aria-live': 'polite' },
        items.map((item) =>
          h(
            'div',
            { key: item.id, className: `ah-toast ah-toast--${item.kind}` },
            h(Icon, { name: item.kind === 'error' ? 'alert' : 'check', size: 15 }),
            h('span', null, item.message),
          ),
        ),
      )
    }

    // ------------------------------------------------------------ list page

    function AssetCard({ asset, onOpen, updates, installedAssets }) {
      const t = useT()
      const tags = toList(asset.tags).slice(0, 3)
      const version = assetVersion(asset)
      const kind = assetKind(asset)
      const id = assetId(asset)
      const packageName = asset.package_name || asset.packageName || ''
      const update = Array.isArray(updates)
        ? updates.find((item) => item.kind === kind && String(item.id) === String(id))
        : null
      const installedEntry = Array.isArray(installedAssets)
        ? installedAssets.find(
            (item) =>
              (item.kind === kind && item.id !== null && item.id !== undefined && String(item.id) === String(id)) ||
              (kind === 'plugin' && item.packageName && packageName && item.packageName === packageName),
          )
        : null
      return h(
        'article',
        {
          className: `ah-card ah-card--${kindClass(kind)}${update ? ' ah-card--update' : ''}`,
          role: 'button',
          tabIndex: 0,
          onClick: () => onOpen(asset),
          onKeyDown: (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
              event.preventDefault()
              onOpen(asset)
            }
          },
        },
        h('span', { className: 'ah-card-glyph', 'aria-hidden': true }, h(Icon, { name: kind === 'plugin' ? 'box' : kind === 'mcp' ? 'external' : 'file', size: 64 })),
        h(
          'div',
          { className: 'ah-card-top' },
          h(KindBadge, { kind }),
          h(
            'div',
            { className: 'ah-card-flags' },
            version ? h('span', { className: 'ah-version' }, `v${version}`) : null,
            installedEntry
              ? h(
                  'span',
                  { className: 'ah-badge ah-badge--installed', title: installedEntry.version ? `v${installedEntry.version}` : '' },
                  t('installed'),
                )
              : null,
            update
              ? h(
                  'span',
                  { className: 'ah-badge ah-badge--warn', title: `${t('updateAvailable')} · v${update.latestVersion}` },
                  `${t('updateAvailable')} v${update.latestVersion}`,
                )
              : null,
          ),
        ),
        h('h3', { className: 'ah-card-title', title: assetName(asset) }, assetName(asset)),
        h('p', { className: 'ah-card-summary' }, assetSummary(asset) || assetSlug(asset) || t('noDescription')),
        tags.length > 0 ? h('div', { className: 'ah-tagrow' }, tags.map((tag) => h('span', { key: tag, className: 'ah-tag' }, tag))) : null,
        h(
          'div',
          { className: 'ah-card-foot' },
          h('span', { className: 'ah-card-owner' }, assetOwner(asset) || assetSlug(asset)),
          h('span', { className: 'ah-card-date' }, formatDate(assetUpdated(asset))),
        ),
      )
    }

    function SkeletonGrid() {
      return h(
        'div',
        { className: 'ah-grid' },
        Array.from({ length: PAGE_SIZE }, (_, index) => h('div', { key: index, className: 'ah-card ah-skeleton' })),
      )
    }

    // --------------------------------------------------------------- dialogs

    function UploadDialog({ mode, asset, onClose, onDone, pushToast, onAuthExpired }) {
      const t = useT()
      const [kind, setKind] = useState(mode === 'publish' ? 'skill' : assetKind(asset) || 'skill')
      const [file, setFile] = useState(null)
      const [form, setForm] = useState({
        slug: '',
        name: '',
        summary: '',
        description: '',
        version: '',
        changelog: '',
        category: '',
        tags: '',
        visibility: 'public',
      })
      const [error, setError] = useState('')
      const [busy, setBusy] = useState(false)
      const [dragging, setDragging] = useState(false)
      const fileInput = useRef(null)
      const allowAny = false

      const extension = kind === 'plugin' ? '.tgz' : '.zip'
      const limit = kind === 'plugin' ? PLUGIN_MAX_BYTES : ASSET_MAX_BYTES
      const needsVersion = kind !== 'plugin'
      const versionRequired = mode === 'version' ? true : needsVersion

      const update = (key) => (event) => setForm((current) => ({ ...current, [key]: event.target.value }))

      function acceptFile(next) {
        if (!next) return
        const lower = next.name.toLowerCase()
        const okExtension = kind === 'plugin' ? lower.endsWith('.tgz') || lower.endsWith('.tar.gz') : lower.endsWith('.zip')
        if (!okExtension && !allowAny) {
          setError(t('wrongExtension').replace('{ext}', extension))
          return
        }
        if (next.size > limit) {
          setError(t('tooBig'))
          return
        }
        setError('')
        setFile(next)
      }

      async function submit(event) {
        if (event) event.preventDefault()
        if (busy) return
        if (!file) {
          setError(t('fileRequired'))
          return
        }
        if (versionRequired && !form.version.trim()) {
          setError(t('versionRequired'))
          return
        }
        if (form.slug && !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(form.slug)) {
          setError(t('invalidSlug'))
          return
        }
        setBusy(true)
        setError('')
        try {
          const meta = {
            method: mode === 'publish' ? 'publish' : 'publishVersion',
            kind,
            id: mode === 'publish' ? undefined : assetId(asset),
            filename: file.name,
            version: form.version.trim() || undefined,
            changelog: form.changelog.trim() || undefined,
          }
          if (mode === 'publish') {
            meta.slug = form.slug.trim() || undefined
            meta.name = form.name.trim() || undefined
            meta.summary = form.summary.trim() || undefined
            meta.description = form.description.trim() || undefined
            meta.category = form.category.trim() || undefined
            meta.tags = form.tags.trim() || undefined
            meta.visibility = form.visibility
          }
          const result = await uploadPackage(meta, file)
          pushToast('success', mode === 'publish' ? t('publishSuccess') : t('versionSuccess'))
          onDone(result)
        } catch (failure) {
          if (isAuthError(failure) && onAuthExpired) {
            onAuthExpired()
            return
          }
          setError(errorMessage(failure))
        } finally {
          setBusy(false)
        }
      }

      return h(
        Modal,
        {
          title: mode === 'publish' ? t('publishTitle') : t('versionTitle'),
          onClose: busy ? () => {} : onClose,
          width: 640,
        },
        h(
          'form',
          { className: 'ah-form', onSubmit: submit },
          mode === 'publish' ? h('p', { className: 'ah-form-note' }, t('publishSubtitle')) : null,
          mode === 'publish'
            ? h(
                'div',
                { className: 'ah-field' },
                h('span', { className: 'ah-field-label' }, t('kind')),
                h(
                  'div',
                  { className: 'ah-seg ah-seg--full' },
                  KINDS.map((item) =>
                    h(
                      'button',
                      {
                        key: item,
                        type: 'button',
                        className: `ah-seg-btn${kind === item ? ' is-active' : ''}`,
                        onClick: () => {
                          setKind(item)
                          setFile(null)
                          setError('')
                        },
                      },
                      t(kindKey(item)),
                    ),
                  ),
                ),
              )
            : h(
                'div',
                { className: 'ah-form-note' },
                `${t('kind')}: ${t(kindKey(kind))} · ${assetName(asset)}`,
              ),
          h(
            'div',
            { className: 'ah-field' },
            h('span', { className: 'ah-field-label' }, t('file')),
            h('input', {
              ref: fileInput,
              type: 'file',
              accept: kind === 'plugin' ? '.tgz,application/gzip' : '.zip,application/zip',
              style: { display: 'none' },
              onChange: (event) => acceptFile(event.target.files && event.target.files[0]),
            }),
            h(
              'div',
              {
                className: `ah-drop${dragging ? ' is-dragging' : ''}${file ? ' has-file' : ''}`,
                onClick: () => fileInput.current && fileInput.current.click(),
                onDragOver: (event) => {
                  event.preventDefault()
                  setDragging(true)
                },
                onDragLeave: () => setDragging(false),
                onDrop: (event) => {
                  event.preventDefault()
                  setDragging(false)
                  acceptFile(event.dataTransfer.files && event.dataTransfer.files[0])
                },
                role: 'button',
                tabIndex: 0,
                onKeyDown: (event) => {
                  if (event.key === 'Enter' || event.key === ' ') fileInput.current && fileInput.current.click()
                },
              },
              h(Icon, { name: file ? 'file' : 'box', size: 22 }),
              file
                ? h(
                    'div',
                    { className: 'ah-drop-text' },
                    h('strong', null, file.name),
                    h('span', null, `${formatBytes(file.size)} · ${t('changeFile')}`),
                  )
                : h(
                    'div',
                    { className: 'ah-drop-text' },
                    h('strong', null, t('chooseFile')),
                    h('span', null, t('dropHint')),
                  ),
            ),
          ),
          h(
            'div',
            { className: 'ah-form-grid' },
            mode === 'publish'
              ? h(
                  Field,
                  { label: t('slug'), hint: t('slugHint') },
                  h('input', { className: 'ah-input', value: form.slug, onChange: update('slug'), placeholder: 'k8s-triage', autoComplete: 'off' }),
                )
              : null,
            h(
              Field,
              { label: t('version'), hint: versionRequired ? null : t('versionOptional') },
              h('input', {
                className: 'ah-input',
                value: form.version,
                onChange: update('version'),
                placeholder: needsVersion ? '1.0.0' : '0.2.0',
                autoComplete: 'off',
              }),
            ),
          ),
          mode === 'publish'
            ? h(
                'div',
                { className: 'ah-form-grid' },
                h(
                  Field,
                  { label: t('name') },
                  h('input', { className: 'ah-input', value: form.name, onChange: update('name'), placeholder: 'K8s 排障', autoComplete: 'off' }),
                ),
                h(
                  Field,
                  { label: t('visibility') },
                  h(
                    'select',
                    { className: 'ah-input', value: form.visibility, onChange: update('visibility') },
                    h('option', { value: 'public' }, t('visibilityPublic')),
                    h('option', { value: 'unlisted' }, t('visibilityUnlisted')),
                    h('option', { value: 'private' }, t('visibilityPrivate')),
                  ),
                ),
              )
            : null,
          mode === 'publish'
            ? h(
                Field,
                { label: t('summary') },
                h('input', { className: 'ah-input', value: form.summary, onChange: update('summary'), autoComplete: 'off' }),
              )
            : null,
          mode === 'publish'
            ? h(
                'div',
                { className: 'ah-form-grid' },
                h(
                  Field,
                  { label: t('category') },
                  h('input', { className: 'ah-input', value: form.category, onChange: update('category'), placeholder: 'ops', autoComplete: 'off' }),
                ),
                h(
                  Field,
                  { label: t('tags') },
                  h('input', { className: 'ah-input', value: form.tags, onChange: update('tags'), placeholder: 'kubernetes,ops', autoComplete: 'off' }),
                ),
              )
            : null,
          mode === 'publish'
            ? h(
                Field,
                { label: t('description') },
                h('textarea', { className: 'ah-input ah-textarea', value: form.description, onChange: update('description'), rows: 3 }),
              )
            : h(
                Field,
                { label: t('changelog') },
                h('textarea', { className: 'ah-input ah-textarea', value: form.changelog, onChange: update('changelog'), rows: 3 }),
              ),
          error ? h('div', { className: 'ah-alert' }, h(Icon, { name: 'alert', size: 15 }), h('span', null, error)) : null,
          h(
            'div',
            { className: 'ah-actions' },
            h(Button, { onClick: busy ? undefined : onClose, disabled: busy }, t('cancel')),
            h('button', { className: 'ah-btn ah-btn--primary', type: 'submit', disabled: busy }, busy ? h('span', { className: 'ah-spinner ah-spinner--sm' }) : null, busy ? t('publishing') : t('submit')),
          ),
        ),
      )
    }

    function EditDialog({ asset, onClose, onDone, pushToast, onAuthExpired }) {
      const t = useT()
      const [form, setForm] = useState({
        name: asset?.name || '',
        summary: asset?.summary || '',
        description: asset?.description || '',
        category: asset?.category || '',
        language: asset?.language || '',
        tags: toList(asset?.tags).join(','),
        visibility: assetVisibility(asset),
      })
      const [error, setError] = useState('')
      const [busy, setBusy] = useState(false)
      const update = (key) => (event) => setForm((current) => ({ ...current, [key]: event.target.value }))

      async function submit(event) {
        if (event) event.preventDefault()
        setBusy(true)
        setError('')
        try {
          const patch = {
            name: form.name.trim(),
            summary: form.summary.trim(),
            description: form.description.trim(),
            category: form.category.trim(),
            language: form.language.trim(),
            tags: toList(form.tags),
            visibility: form.visibility,
          }
          const result = await rpc('updateMeta', { kind: assetKind(asset), id: assetId(asset), patch })
          pushToast('success', t('updateSuccess'))
          onDone(result)
        } catch (failure) {
          if (isAuthError(failure) && onAuthExpired) {
            onAuthExpired()
            return
          }
          setError(errorMessage(failure))
        } finally {
          setBusy(false)
        }
      }

      return h(
        Modal,
        { title: t('editTitle'), onClose: busy ? () => {} : onClose },
        h(
          'form',
          { className: 'ah-form', onSubmit: submit },
          h(
            'div',
            { className: 'ah-form-grid' },
            h(Field, { label: t('name') }, h('input', { className: 'ah-input', value: form.name, onChange: update('name') })),
            h(Field, { label: t('visibility') }, h(
              'select',
              { className: 'ah-input', value: form.visibility, onChange: update('visibility') },
              h('option', { value: 'public' }, t('visibilityPublic')),
              h('option', { value: 'unlisted' }, t('visibilityUnlisted')),
              h('option', { value: 'private' }, t('visibilityPrivate')),
            )),
          ),
          h(Field, { label: t('summary') }, h('input', { className: 'ah-input', value: form.summary, onChange: update('summary') })),
          h(
            'div',
            { className: 'ah-form-grid' },
            h(Field, { label: t('category') }, h('input', { className: 'ah-input', value: form.category, onChange: update('category') })),
            h(Field, { label: t('language') }, h('input', { className: 'ah-input', value: form.language, onChange: update('language'), placeholder: 'zh-CN' })),
          ),
          h(Field, { label: t('tags') }, h('input', { className: 'ah-input', value: form.tags, onChange: update('tags') })),
          h(Field, { label: t('description') }, h('textarea', { className: 'ah-input ah-textarea', rows: 4, value: form.description, onChange: update('description') })),
          error ? h('div', { className: 'ah-alert' }, h(Icon, { name: 'alert', size: 15 }), h('span', null, error)) : null,
          h(
            'div',
            { className: 'ah-actions' },
            h(Button, { onClick: busy ? undefined : onClose, disabled: busy }, t('cancel')),
            h('button', { className: 'ah-btn ah-btn--primary', type: 'submit', disabled: busy }, busy ? t('saving') : t('saveChanges')),
          ),
        ),
      )
    }

    function SettingsDialog({ status, onClose, onSaved, onStatus, pushToast }) {
      const t = useT()
      const [baseUrl, setBaseUrl] = useState(status?.baseUrl || '')
      const [email, setEmail] = useState(status?.loginId || '')
      const [password, setPassword] = useState('')
      const [pat, setPat] = useState('')
      const [expires, setExpires] = useState('180d')
      const [mode, setMode] = useState(status?.authenticated && status?.authMode === 'pat' ? 'pat' : 'account')
      const [insecureTLS, setInsecureTLS] = useState(Boolean(status?.insecureTLS))
      const [busy, setBusy] = useState('')
      const [error, setError] = useState('')
      const [notice, setNotice] = useState('')
      const authenticated = Boolean(status?.authenticated)
      const expiresText = status?.tokenExpiresAt ? formatDate(status.tokenExpiresAt) : ''
      const patUrl = (() => {
        const base = String(baseUrl || status?.baseUrl || '').trim().replace(/\/+$/, '')
        return /^https?:\/\//i.test(base) ? `${base}/my-tokens` : ''
      })()

      async function signIn(event) {
        if (event) event.preventDefault()
        if (!email.trim()) {
          setError(t('emailRequired'))
          return
        }
        if (!password) {
          setError(t('passwordRequired'))
          return
        }
        setBusy('login')
        setError('')
        setNotice('')
        try {
          const next = await rpc('login', { baseUrl, email: email.trim(), password, insecureTLS, expiresIn: expires })
          setPassword('')
          pushToast('success', t('loginSuccess'))
          onSaved(next)
        } catch (failure) {
          setError(errorMessage(failure))
        } finally {
          setBusy('')
        }
      }

      async function savePat(event) {
        if (event) event.preventDefault()
        if (!pat.trim()) {
          setError(t('patRequired'))
          return
        }
        setBusy('pat')
        setError('')
        setNotice('')
        try {
          const next = await rpc('savePat', { baseUrl, token: pat.trim(), insecureTLS })
          setPat('')
          pushToast('success', t('patSaved'))
          onSaved(next)
        } catch (failure) {
          setError(isAuthError(failure) ? t('patInvalid') : errorMessage(failure))
        } finally {
          setBusy('')
        }
      }

      async function saveAddress() {
        setBusy('save')
        setError('')
        setNotice('')
        try {
          const next = await rpc('saveSettings', { baseUrl, insecureTLS })
          pushToast('success', t('addressSaved'))
          if (onStatus) onStatus(next)
        } catch (failure) {
          setError(errorMessage(failure))
        } finally {
          setBusy('')
        }
      }

      async function signOut() {
        setBusy('logout')
        setError('')
        setNotice('')
        try {
          const next = await rpc('logout')
          setPassword('')
          setPat('')
          pushToast('success', t('loggedOut'))
          if (onStatus) onStatus(next)
        } catch (failure) {
          setError(errorMessage(failure))
        } finally {
          setBusy('')
        }
      }

      async function test() {
        setBusy('test')
        setError('')
        setNotice('')
        try {
          const result = await rpc('testConnection', { baseUrl, insecureTLS })
          const kinds = Array.isArray(result?.meta?.kinds)
            ? result.meta.kinds.map((item) => `${item.kind}: ${item.count}`).join(' · ')
            : t('healthOk')
          const suffix = result?.authenticated
            ? ` · ${t('patBadge')}${result.loginId ? ` · ${result.loginId}` : ''}`
            : ''
          setNotice(t('testOk').replace('{kinds}', kinds) + suffix)
        } catch (failure) {
          setError(errorMessage(failure))
        } finally {
          setBusy('')
        }
      }

      function submit(event) {
        event.preventDefault()
        if (mode === 'pat') savePat(event)
        else signIn(event)
      }

      const statusTitle = authenticated
        ? t('patLogin').replace('{tail}', status?.tokenTail || '****')
        : status?.tokenTail
          ? t('patInvalid')
          : t('notLoggedIn')
      const statusHint = authenticated
        ? [
            status?.loginId ? t('loggedInAs').replace('{email}', status.loginId) : '',
            expiresText ? t('sessionExpires').replace('{time}', expiresText) : t('patSession'),
          ]
            .filter(Boolean)
            .join(' · ')
        : status?.tokenTail
          ? t('authExpired')
          : status?.legacySession
            ? t('legacyHint')
            : t('loginHint')
      const primaryLabel =
        mode === 'pat'
          ? busy === 'pat'
            ? t('verifyingPat')
            : t('savePat')
          : busy === 'login'
            ? t('loggingIn')
            : t('login')

      return h(
        Modal,
        { title: t('settingsTitle'), onClose: busy ? () => {} : onClose },
        h(
          'form',
          { className: 'ah-form', onSubmit: submit },
          h(
            Field,
            { label: t('baseUrl'), hint: t('baseUrlHint') },
            h('input', {
              className: 'ah-input',
              value: baseUrl,
              onChange: (event) => setBaseUrl(event.target.value),
              placeholder: 'https://25.75.3.1',
              autoComplete: 'off',
              spellCheck: false,
            }),
          ),
          baseUrl.trim().toLowerCase().startsWith('http://')
            ? h('div', { className: 'ah-field-hint ah-warn' }, t('httpWarning'))
            : null,
          h(
            'label',
            { className: 'ah-check ah-check--block' },
            h('input', { type: 'checkbox', checked: insecureTLS, onChange: (event) => setInsecureTLS(event.target.checked) }),
            h('span', null, t('insecureTLS'), h('small', null, t('insecureTLHint'))),
          ),
          h(
            'div',
            { className: 'ah-auth-status' },
            h('span', { className: `ah-auth-dot${authenticated ? ' is-on' : ''}` }),
            h('div', { className: 'ah-auth-text' }, h('strong', null, statusTitle), h('span', null, statusHint)),
            authenticated || status?.tokenTail
              ? h(Button, { size: 'sm', variant: 'danger', onClick: signOut, busy: busy === 'logout', disabled: Boolean(busy) }, t('logout'))
              : null,
          ),
          status?.scopeStatus === 'missing'
            ? h(
                'div',
                { className: 'ah-alert' },
                h(Icon, { name: 'alert', size: 15 }),
                h('span', null, t('scopeMissing').replace('{scope}', status?.scopeRequired || 'assets:write')),
              )
            : null,
          h(
            'div',
            { className: 'ah-field' },
            h('span', { className: 'ah-field-label' }, t('authMode')),
            h(
              'div',
              { className: 'ah-seg ah-seg--full' },
              h(
                'button',
                {
                  type: 'button',
                  className: `ah-seg-btn${mode === 'account' ? ' is-active' : ''}`,
                  onClick: () => {
                    setMode('account')
                    setError('')
                  },
                },
                t('authModeAccount'),
              ),
              h(
                'button',
                {
                  type: 'button',
                  className: `ah-seg-btn${mode === 'pat' ? ' is-active' : ''}`,
                  onClick: () => {
                    setMode('pat')
                    setError('')
                  },
                },
                t('authModePat'),
              ),
            ),
          ),
          mode === 'account'
            ? h(
                React.Fragment,
                null,
                h(
                  Field,
                  { label: t('email') },
                  h('input', {
                    className: 'ah-input',
                    value: email,
                    onChange: (event) => setEmail(event.target.value),
                    placeholder: t('emailPlaceholder'),
                    autoComplete: 'username',
                    spellCheck: false,
                  }),
                ),
                h(
                  Field,
                  { label: t('password'), hint: t('loginHint') },
                  h('input', {
                    className: 'ah-input',
                    type: 'password',
                    value: password,
                    onChange: (event) => setPassword(event.target.value),
                    placeholder: t('passwordPlaceholder'),
                    autoComplete: 'current-password',
                  }),
                ),
                h(
                  Field,
                  { label: t('expires') },
                  h(
                    'select',
                    { className: 'ah-input', value: expires, onChange: (event) => setExpires(event.target.value) },
                    ['7d', '30d', '90d', '180d'].map((value) => h('option', { key: value, value }, value)),
                  ),
                ),
              )
            : h(
                React.Fragment,
                null,
                h(
                  Field,
                  {
                    label: t('pat'),
                    hint: authenticated && status?.tokenTail ? t('patLogin').replace('{tail}', status.tokenTail) : t('patHint'),
                  },
                  h('input', {
                    className: 'ah-input',
                    type: 'password',
                    value: pat,
                    onChange: (event) => setPat(event.target.value),
                    placeholder: t('patPlaceholder'),
                    autoComplete: 'off',
                    spellCheck: false,
                  }),
                ),
                h(
                  'div',
                  { className: 'ah-actions' },
                  patUrl
                    ? h(
                        'button',
                        {
                          type: 'button',
                          className: 'ah-link',
                          onClick: () => window.open(patUrl, '_blank', 'noopener,noreferrer'),
                        },
                        t('createPat'),
                      )
                    : null,
                  h('span', { className: 'ah-field-hint' }, t('patReadOnly')),
                ),
              ),
          baseUrl && authenticated && baseUrl !== status?.baseUrl
            ? h('div', { className: 'ah-field-hint' }, t('reauthHint'))
            : null,
          notice ? h('div', { className: 'ah-alert ah-alert--ok' }, h(Icon, { name: 'check', size: 15 }), h('span', null, notice)) : null,
          error ? h('div', { className: 'ah-alert' }, h(Icon, { name: 'alert', size: 15 }), h('span', null, error)) : null,
          h(
            'div',
            { className: 'ah-actions ah-actions--between' },
            h(
              'div',
              { className: 'ah-actions' },
              h(Button, { onClick: test, busy: busy === 'test', disabled: Boolean(busy) }, busy === 'test' ? t('testing') : t('test')),
              h(Button, { onClick: saveAddress, busy: busy === 'save', disabled: Boolean(busy) }, t('saveAddress')),
            ),
            h(
              'div',
              { className: 'ah-actions' },
              h(Button, { onClick: busy ? undefined : onClose, disabled: Boolean(busy) }, t('cancel')),
              h(
                'button',
                { className: 'ah-btn ah-btn--primary', type: 'submit', disabled: Boolean(busy) },
                busy === 'login' || busy === 'pat' || busy === 'save' ? h('span', { className: 'ah-spinner ah-spinner--sm' }) : null,
                primaryLabel,
              ),
            ),
          ),
        ),
      )
    }

    function ConfirmDeleteDialog({ asset, onClose, onDone, pushToast, onAuthExpired }) {
      const t = useT()
      const [busy, setBusy] = useState(false)
      const [error, setError] = useState('')

      async function confirm() {
        setBusy(true)
        setError('')
        try {
          await rpc('remove', { kind: assetKind(asset), id: assetId(asset) })
          pushToast('success', t('deleteSuccess'))
          onDone()
        } catch (failure) {
          if (isAuthError(failure) && onAuthExpired) {
            onAuthExpired()
            return
          }
          setError(errorMessage(failure))
        } finally {
          setBusy(false)
        }
      }

      return h(
        Modal,
        { title: t('deleteTitle'), onClose: busy ? () => {} : onClose, width: 460 },
        h('p', { className: 'ah-confirm-text' }, t('deleteConfirm').replace('{name}', assetName(asset))),
        error ? h('div', { className: 'ah-alert' }, h(Icon, { name: 'alert', size: 15 }), h('span', null, error)) : null,
        h(
          'div',
          { className: 'ah-actions ah-actions--end' },
          h(Button, { onClick: busy ? undefined : onClose, disabled: busy }, t('cancel')),
          h(Button, { variant: 'danger', onClick: confirm, busy, disabled: busy }, busy ? t('deleting') : t('confirmDelete')),
        ),
      )
    }

    function ConfirmUninstallDialog({ asset, onClose, onDone, pushToast }) {
      const t = useT()
      const [busy, setBusy] = useState(false)
      const [error, setError] = useState('')

      async function confirm() {
        setBusy(true)
        setError('')
        try {
          await rpc('uninstall', { kind: assetKind(asset), id: assetId(asset) })
          pushToast('success', t('uninstallSuccess'))
          onDone()
        } catch (failure) {
          setError(errorMessage(failure))
        } finally {
          setBusy(false)
        }
      }

      return h(
        Modal,
        { title: t('uninstallTitle'), onClose: busy ? () => {} : onClose, width: 460 },
        h('p', { className: 'ah-confirm-text' }, t('uninstallConfirm').replace('{name}', assetName(asset))),
        error ? h('div', { className: 'ah-alert' }, h(Icon, { name: 'alert', size: 15 }), h('span', null, error)) : null,
        h(
          'div',
          { className: 'ah-actions ah-actions--end' },
          h(Button, { onClick: busy ? undefined : onClose, disabled: busy }, t('cancel')),
          h(Button, { variant: 'danger', onClick: confirm, busy, disabled: busy }, busy ? t('uninstalling') : t('uninstall')),
        ),
      )
    }

    function ConfirmUpgradeDialog({ asset, install, onClose, onConfirm }) {
      const t = useT()
      const kind = assetKind(asset)
      const from = install?.version || ''
      const to = assetVersion(asset)
      const self = kind === 'plugin' && asset?.package_name === 'dsh-asset-hub'
      const key = self
        ? 'updateSelfConfirm'
        : kind === 'skill'
          ? 'updateSkillConfirm'
          : kind === 'mcp'
            ? 'updateMcpConfirm'
            : 'updatePluginConfirm'
      const text = t(key).replace('{from}', from || '—').replace('{to}', to || '—')
      return h(
        Modal,
        { title: t('updateTitle'), onClose, width: 500 },
        h('p', { className: 'ah-confirm-text' }, text),
        h(
          'div',
          { className: 'ah-actions ah-actions--end' },
          h(Button, { onClick: onClose }, t('cancel')),
          h(Button, { variant: 'primary', onClick: onConfirm }, t('updateTo').replace('{version}', to || '')),
        ),
      )
    }

    function TextDialog({ title, text, onClose }) {
      const t = useT()
      return h(
        Modal,
        { title, onClose, width: 760 },
        h('pre', { className: 'ah-code' }, text || t('none')),
      )
    }

    // --------------------------------------------------------------- detail

    function summarizeInstall(result, t) {
      if (!result) return ''
      if (result.kind === 'skill') {
        const base = String(result.name || '')
        return result.skipped && result.skipped.length > 0 ? `${base} · ${t('installSkipped').replace('{n}', String(result.skipped.length))}` : base
      }
      if (result.kind === 'mcp') return `${result.serverName || ''} · ${result.transport || ''}`
      return `${result.packageName || ''}${result.version ? `@${result.version}` : ''}`
    }

    function DetailView({ state, onBack, onReload, onUpload, onEdit, onDelete, onDownload, onPreview, onInstall, onUninstall, onUpgrade, pushToast }) {
      const t = useT()
      const asset = state.asset
      const [tab, setTab] = useState('overview')
      const [manifestBusy, setManifestBusy] = useState(false)
      const kind = assetKind(asset)
      const id = assetId(asset)
      const version = assetVersion(asset)
      const install = asset && typeof asset.install === 'object' && asset.install ? asset.install : null
      const description = assetDescription(asset)
      const versions = state.versions || []
      const files = state.files || []
      const installState = state.install || null
      const installable = kind === 'skill' || kind === 'mcp' || kind === 'plugin'
      const installAvailable = installState?.available !== false
      const installedVersion = installState?.version || ''
      const canUpgrade = Boolean(installState?.installed && version && installedVersion && installedVersion !== version)
      const installHint = kind === 'skill' ? t('installHintSkill') : kind === 'mcp' ? t('installHintMcp') : t('installHintPlugin')

      useEffect(() => {
        if (tab === 'files' && state.files === null && !state.filesLoading) onReload('files')
      }, [tab, state.files, state.filesLoading, onReload])

      async function showManifest() {
        setManifestBusy(true)
        try {
          const text = await rpc('manifest', { kind, id, version: version || undefined })
          onPreview(t('manifest'), text)
        } catch (failure) {
          pushToast('error', errorMessage(failure))
        } finally {
          setManifestBusy(false)
        }
      }

      return h(
        'div',
        { className: 'ah-detail' },
        h(
          'div',
          { className: 'ah-detail-bar' },
          h(Button, { onClick: onBack }, h(Icon, { name: 'back', size: 14 }), t('back')),
        ),
        state.loading && !asset
          ? h(Spinner, { label: t('detailLoading') })
          : h(
              React.Fragment,
              null,
              h(
                'header',
                { className: `ah-detail-head ah-detail-head--${kindClass(kind)}` },
                h(
                  'div',
                  { className: 'ah-detail-titlewrap' },
                  h('div', { className: 'ah-detail-kicker' }, h(KindBadge, { kind }), version ? h('span', { className: 'ah-version' }, `v${version}`) : null, installState?.installed ? h('span', { className: 'ah-badge ah-badge--installed' }, h('span', { className: 'ah-dot' }), t('installed')) : null,
                  canUpgrade ? h('span', { className: 'ah-badge ah-badge--warn' }, t('updateAvailable')) : null, assetStatusValue(asset) === 'suspended' ? h('span', { className: 'ah-badge ah-badge--warn' }, t('statusSuspended')) : null),
                  h('h1', { className: 'ah-detail-title' }, assetName(asset)),
                  assetSummary(asset) ? h('p', { className: 'ah-detail-summary' }, assetSummary(asset)) : null,
                  h(
                    'div',
                    { className: 'ah-detail-sub' },
                    assetSlug(asset) ? h('span', null, assetSlug(asset)) : null,
                    assetOwner(asset) ? h('span', null, `${t('owner')}: ${assetOwner(asset)}`) : null,
                    assetUpdated(asset) ? h('span', null, `${t('updated')}: ${formatDate(assetUpdated(asset))}`) : null,
                  ),
                ),
                h(
                  'div',
                  { className: 'ah-detail-actions' },
                  h(Button, { onClick: () => onDownload(asset, version || undefined) }, h(Icon, { name: 'download', size: 14 }), t('download')),
                  h(Button, { onClick: () => onUpload('version', asset) }, h(Icon, { name: 'plus', size: 14 }), t('publishVersion')),
                  h(Button, { onClick: () => onEdit(asset) }, h(Icon, { name: 'edit', size: 14 }), t('edit')),
                  h(IconButton, { icon: 'trash', label: t('delete'), danger: true, onClick: () => onDelete(asset) }),
                ),
              ),
              state.error ? h('div', { className: 'ah-alert' }, h(Icon, { name: 'alert', size: 15 }), h('span', null, state.error)) : null,
              h(
                'div',
                { className: 'ah-tabs', role: 'tablist' },
                [
                  ['overview', t('overview')],
                  ['versions', `${t('versions')}${versions.length ? ` (${versions.length})` : ''}`],
                  ['files', t('files')],
                ].map(([key, label]) =>
                  h(
                    'button',
                    {
                      key,
                      role: 'tab',
                      'aria-selected': tab === key,
                      className: `ah-tab${tab === key ? ' is-active' : ''}`,
                      onClick: () => setTab(key),
                    },
                    label,
                  ),
                ),
                h('div', { className: 'ah-tabs-spacer' }),
                h(Button, { onClick: showManifest, busy: manifestBusy }, h(Icon, { name: 'file', size: 14 }), t('manifest')),
              ),
              state.loading ? h(Spinner, { label: t('detailLoading') }) : null,
              tab === 'overview'
                ? h(
                    'div',
                    { className: 'ah-detail-grid' },
                    h(
                      'section',
                      { className: 'ah-panel' },
                      h('h2', null, t('description')),
                      description ? h('p', { className: 'ah-prose' }, description) : h('p', { className: 'ah-muted' }, t('noDescription')),
                    ),
                    h(
                      'aside',
                      { className: 'ah-side' },
                      installable
                        ? h(
                            'section',
                            { className: 'ah-panel ah-install' },
                            h(
                              'div',
                              { className: 'ah-panel-head' },
                              h('h2', null, t('installToDsh')),
                              state.installBusy ? h('span', { className: 'ah-spinner ah-spinner--sm' }) : null,
                            ),
                            h('p', { className: 'ah-muted' }, installHint),
                            kind === 'plugin'
                              ? h('p', { className: 'ah-field-hint ah-warn' }, t('installWarnPlugin'))
                              : kind === 'mcp'
                                ? h('p', { className: 'ah-field-hint ah-warn' }, t('installWarnMcp'))
                                : null,
                            installState?.installed
                              ? h(
                                  React.Fragment,
                                  null,
                                  h(
                                    'div',
                                    { className: 'ah-install-row' },
                                    h('span', { className: 'ah-install-ok' }, h(Icon, { name: 'check', size: 14 }), `${t('installed')}${installState.version ? ` v${installState.version}` : ''}`),
                                    installState.canUninstall
                                      ? h(Button, { size: 'sm', variant: 'danger', onClick: () => onUninstall(asset) }, t('uninstall'))
                                      : h('span', { className: 'ah-field-hint' }, t('managedElsewhere')),
                                  ),
                                  canUpgrade
                                    ? h(
                                        Button,
                                        {
                                          variant: 'primary',
                                          onClick: () => onUpgrade(asset),
                                          disabled: state.installBusy || !installAvailable,
                                          busy: state.installBusy,
                                        },
                                        state.installBusy ? t('updating') : t('updateTo').replace('{version}', version),
                                      )
                                    : null,
                                )
                              : h(
                                  Button,
                                  {
                                    variant: 'primary',
                                    onClick: () => onInstall(asset),
                                    disabled: state.installBusy || !installAvailable,
                                    busy: state.installBusy,
                                  },
                                  state.installBusy ? t('installing') : t('installNow'),
                                ),
                            !installAvailable ? h('p', { className: 'ah-field-hint' }, t('installUnavailable')) : null,
                            state.installResult
                              ? h('p', { className: 'ah-field-hint' }, `${t('installResult')}: ${summarizeInstall(state.installResult, t)}`)
                              : null,
                            state.installError
                              ? h('div', { className: 'ah-alert' }, h(Icon, { name: 'alert', size: 14 }), h('span', null, state.installError))
                              : null,
                          )
                        : null,
                      install
                        ? h(
                            'section',
                            { className: 'ah-panel' },
                            h('div', { className: 'ah-panel-head' }, h('h2', null, t('install')), h(IconButton, {
                              icon: 'copy',
                              label: t('copySpec'),
                              onClick: async () => {
                                const text = install.spec || JSON.stringify(install)
                                const ok = await copyText(text)
                                pushToast(ok ? 'success' : 'error', ok ? t('copied') : t('copyFailed'))
                              },
                            })),
                            h('p', { className: 'ah-muted' }, t('installHint')),
                            h(
                              'dl',
                              { className: 'ah-kv' },
                              install.method ? [h('dt', { key: 'm' }, t('installMethod')), h('dd', { key: 'mv' }, String(install.method))] : null,
                              install.spec ? [h('dt', { key: 's' }, t('installSpec')), h('dd', { key: 'sv' }, h('code', null, String(install.spec)))] : null,
                              install.registry ? [h('dt', { key: 'r' }, t('installRegistry')), h('dd', { key: 'rv' }, h('code', null, String(install.registry)))] : null,
                              install.host_compat ? [h('dt', { key: 'h' }, t('hostCompat')), h('dd', { key: 'hv' }, String(install.host_compat))] : null,
                              install.target ? [h('dt', { key: 't' }, 'target'), h('dd', { key: 'tv' }, h('code', null, String(install.target)))] : null,
                            ),
                          )
                        : null,
                      h(
                        'section',
                        { className: 'ah-panel' },
                        h('h2', null, t('details')),
                        h(
                          'dl',
                          { className: 'ah-kv' },
                          h('dt', null, t('category')),
                          h('dd', null, asset.category || t('none')),
                          h('dt', null, t('language')),
                          h('dd', null, asset.language || t('none')),
                          h('dt', null, t('visibility')),
                          h('dd', null, t(visibilityKey(assetVisibility(asset)))),
                          h('dt', null, t('downloads')),
                          h('dd', null, assetDownloads(asset) === null ? t('none') : String(assetDownloads(asset))),
                          h('dt', null, 'ID'),
                          h('dd', null, String(id)),
                        ),
                      ),
                      toList(asset.tags).length > 0
                        ? h('section', { className: 'ah-panel' }, h('h2', null, t('tags')), h('div', { className: 'ah-tagrow' }, toList(asset.tags).map((tag) => h('span', { key: tag, className: 'ah-tag' }, tag))))
                        : null,
                    ),
                  )
                : null,
              tab === 'versions'
                ? h(
                    'section',
                    { className: 'ah-panel' },
                    versions.length === 0
                      ? h('p', { className: 'ah-muted' }, t('noVersions'))
                      : h(
                          'table',
                          { className: 'ah-table' },
                          h('thead', null, h('tr', null, h('th', null, t('version')), h('th', null, t('publishedAt')), h('th', null, t('changelog')), h('th', null, ''))),
                          h(
                            'tbody',
                            null,
                            versions.map((item, index) => {
                              const itemVersion = typeof item === 'string' ? item : item.version || item.name
                              const changelog = typeof item === 'string' ? '' : item.changelog || item.notes || ''
                              const date = typeof item === 'string' ? '' : item.created_at || item.published_at || item.updated_at
                              return h(
                                'tr',
                                { key: `${itemVersion}-${index}` },
                                h('td', null, h('code', null, itemVersion), index === 0 ? h('span', { className: 'ah-mini' }, t('latest')) : null),
                                h('td', { className: 'ah-muted' }, formatDate(date)),
                                h('td', { className: 'ah-muted ah-wrap' }, changelog || t('none')),
                                h('td', { className: 'ah-right' }, h(IconButton, { icon: 'download', label: t('download'), onClick: () => onDownload(asset, itemVersion) })),
                              )
                            }),
                          ),
                        ),
                  )
                : null,
              tab === 'files'
                ? h(
                    'section',
                    { className: 'ah-panel' },
                    state.filesLoading ? h(Spinner, { label: t('loading') }) : null,
                    !state.filesLoading && files.length === 0 ? h('p', { className: 'ah-muted' }, t('noFiles')) : null,
                    files.length > 0
                      ? h(
                          'ul',
                          { className: 'ah-files' },
                          files.map((file) =>
                            h(
                              'li',
                              { key: file.path, className: 'ah-file' },
                              h(Icon, { name: 'file', size: 14 }),
                              h('span', { className: 'ah-file-path' }, file.path),
                              h('span', { className: 'ah-file-size' }, formatBytes(file.size)),
                              h(Button, { size: 'sm', onClick: () => onPreview(asset, file.path) }, t('preview')),
                            ),
                          ),
                        )
                      : null,
                  )
                : null,
            ),
      )
    }

    // ----------------------------------------------------------------- page

    function AssetHubPage(props) {
      const t = props.t || ((key) => key)
      const updates = useUpdates()
      const [status, setStatus] = useState(null)
      const tRef = useRef(t)
      tRef.current = t
      const [meta, setMeta] = useState(null)
      const [filters, setFilters] = useState({ kind: '', q: '', category: '', sort: 'recent', mine: false, page: 1 })
      const debouncedQuery = useDebounced(filters.q, 300)
      const [list, setList] = useState({ items: [], total: 0, page: 1, hasMore: false, loading: true, error: '' })
      const [detail, setDetail] = useState(null)
      const [dialog, setDialog] = useState(null)
      const [toasts, setToasts] = useState([])
      const [reloadToken, setReloadToken] = useState(0)
      const requestSeq = useRef(0)
      const toastSeq = useRef(0)
      const listSeq = useRef(0)

      const pushToast = useCallback((kind, message) => {
        const id = ++toastSeq.current
        setToasts((current) => [...current, { id, kind, message }])
        setTimeout(() => {
          setToasts((current) => current.filter((item) => item.id !== id))
        }, 4200)
      }, [])

      const refreshStatus = useCallback(async () => {
        try {
          const next = await rpc('status')
          setStatus(next)
          return next
        } catch (failure) {
          pushToast('error', errorMessage(failure))
          return null
        }
      }, [pushToast])

      const handleAuthExpired = useCallback(() => {
        pushToast('error', tRef.current('authExpired'))
        setDialog({ type: 'settings' })
        refreshStatus()
      }, [pushToast, refreshStatus])

      useEffect(() => {
        refreshStatus()
        rpc('meta')
          .then(setMeta)
          .catch(() => {})
      }, [refreshStatus])

      const loadList = useCallback(async () => {
        const seq = ++listSeq.current
        setList((current) => ({ ...current, loading: true, error: '' }))
        try {
          if (filters.mine) {
            const result = await rpc('me', { page: filters.page, pageSize: PAGE_SIZE })
            if (seq !== listSeq.current) return
            setList({ items: result.items, total: result.total, page: result.page, pageSize: result.pageSize || PAGE_SIZE, hasMore: result.hasMore, loading: false, error: '' })
            return
          }
          const result = await rpc('list', {
            kinds: filters.kind ? [filters.kind] : undefined,
            q: debouncedQuery.trim() || undefined,
            category: filters.category || undefined,
            sort: filters.sort || undefined,
            page: filters.page,
            pageSize: PAGE_SIZE,
          })
          if (seq !== listSeq.current) return
          setList({ items: result.items, total: result.total, page: result.page, pageSize: result.pageSize || PAGE_SIZE, hasMore: result.hasMore, loading: false, error: '' })
        } catch (failure) {
          if (seq !== listSeq.current) return
          if (isAuthError(failure)) handleAuthExpired()
          setList((current) => ({ ...current, loading: false, error: errorMessage(failure) }))
        }
      }, [filters.kind, filters.category, filters.sort, filters.mine, filters.page, debouncedQuery, handleAuthExpired])

      useEffect(() => {
        loadList()
      }, [loadList, reloadToken])

      function patchFilters(patch) {
        setFilters((current) => ({ ...current, page: 1, ...patch }))
      }

      async function refreshAll() {
        setReloadToken((value) => value + 1)
        refreshStatus()
        void updateStore.refresh(true)
        try {
          setMeta(await rpc('meta'))
        } catch {
          /* keep previous metadata */
        }
      }

      async function openDetail(asset) {
        const seq = ++requestSeq.current
        setDetail({ asset, loading: true, versions: [], files: null, filesLoading: false, install: null, installBusy: false, installResult: null, installError: '', error: '' })
        try {
          const kind = assetKind(asset)
          const id = assetId(asset)
          const [full, versions, install] = await Promise.all([
            rpc('get', { kind, id }).catch(() => asset),
            rpc('versions', { kind, id }).catch(() => []),
            rpc('installStatus', { kind, id }).catch(() => null),
          ])
          if (seq !== requestSeq.current) return
          setDetail({
            asset: full && typeof full === 'object' ? full : asset,
            loading: false,
            versions: Array.isArray(versions) ? versions : [],
            files: null,
            filesLoading: false,
            install,
            installBusy: false,
            installResult: null,
            installError: '',
            error: '',
          })
        } catch (failure) {
          if (seq !== requestSeq.current) return
          setDetail({ asset, loading: false, versions: [], files: null, filesLoading: false, install: null, installBusy: false, installResult: null, installError: '', error: errorMessage(failure) })
        }
      }

      async function installAsset(asset) {
        const kind = assetKind(asset)
        const id = assetId(asset)
        setDetail((value) => (value ? { ...value, installBusy: true, installError: '', installResult: null } : value))
        try {
          const result = await rpc('install', { kind, id, version: assetVersion(asset) || undefined })
          let install = null
          try {
            install = await rpc('installStatus', { kind, id })
          } catch {
            install = null
          }
          setDetail((value) => (value ? { ...value, install, installBusy: false, installResult: result } : value))
          if (result?.updating) {
            pushToast('success', t('selfUpdateNotice'))
            return
          }
          pushToast('success', result?.upgraded ? t('updateSuccess') : result?.already ? t('installAlready') : t('installSuccess'))
          if (result?.restartRequired) pushToast('error', t('restartRequired'))
          refreshAll()
        } catch (failure) {
          if (isAuthError(failure)) {
            setDetail((value) => (value ? { ...value, installBusy: false } : value))
            handleAuthExpired()
            return
          }
          setDetail((value) => (value ? { ...value, installBusy: false, installError: errorMessage(failure) } : value))
          pushToast('error', errorMessage(failure))
        }
      }

      async function reloadDetail(part) {
        const current = detail
        if (!current || !current.asset) return
        const kind = assetKind(current.asset)
        const id = assetId(current.asset)
        if (part === 'files') {
          setDetail((value) => (value ? { ...value, filesLoading: true } : value))
          try {
            const data = await rpc('files', { kind, id, version: assetVersion(current.asset) || undefined })
            setDetail((value) => (value ? { ...value, files: flattenFiles(data), filesLoading: false } : value))
          } catch (failure) {
            setDetail((value) => (value ? { ...value, files: [], filesLoading: false } : value))
            pushToast('error', errorMessage(failure))
          }
          return
        }
        try {
          const [full, versions] = await Promise.all([rpc('get', { kind, id }), rpc('versions', { kind, id }).catch(() => [])])
          setDetail((value) => (value ? { ...value, asset: full, versions: Array.isArray(versions) ? versions : [], files: null, error: '', loading: false } : value))
        } catch (failure) {
          pushToast('error', errorMessage(failure))
        }
      }

      async function downloadAsset(asset, version) {
        try {
          const params = new URLSearchParams({ kind: assetKind(asset), id: String(assetId(asset)) })
          if (version) params.set('version', version)
          const response = await fetch(`${DOWNLOAD_URL}?${params.toString()}`)
          if (!response.ok) {
            let message = `HTTP ${response.status}`
            try {
              const body = await response.json()
              if (body && body.error && body.error.message) message = body.error.message
            } catch {
              /* keep status message */
            }
            throw new Error(message)
          }
          const blob = await response.blob()
          const disposition = response.headers.get('content-disposition') || ''
          let filename = `${assetKind(asset)}-${assetId(asset)}${version ? `-${version}` : ''}`
          const utf8 = /filename\*=UTF-8''([^;]+)/i.exec(disposition)
          const plain = /filename="?([^";]+)"?/i.exec(disposition)
          if (utf8) {
            try {
              filename = decodeURIComponent(utf8[1])
            } catch {
              /* keep default */
            }
          } else if (plain) {
            filename = plain[1]
          }
          const url = URL.createObjectURL(blob)
          const anchor = document.createElement('a')
          anchor.href = url
          anchor.download = filename
          document.body.appendChild(anchor)
          anchor.click()
          anchor.remove()
          setTimeout(() => URL.revokeObjectURL(url), 30000)
          pushToast('success', t('downloadSuccess'))
        } catch (failure) {
          pushToast('error', isAuthError(failure) ? t('authExpired') : errorMessage(failure))
          if (isAuthError(failure)) handleAuthExpired()
        }
      }

      async function previewFile(asset, path) {
        try {
          const text = await rpc('file', { kind: assetKind(asset), id: assetId(asset), path, version: assetVersion(asset) || undefined })
          setDialog({ type: 'text', title: path, text })
        } catch (failure) {
          if (isAuthError(failure)) {
            handleAuthExpired()
          } else if (failure.code === 'FILE_TOO_LARGE') pushToast('error', t('fileTooLarge'))
          else if (failure.code === 'FILE_NOT_TEXT') pushToast('error', t('binaryFile'))
          else pushToast('error', errorMessage(failure))
        }
      }

      function openUpload(mode, asset) {
        if (!status?.authenticated) {
          pushToast('error', t('noTokenAction'))
          setDialog({ type: 'settings' })
          return
        }
        setDialog({ type: 'upload', mode, asset })
      }

      const categories = normalizeCategories(meta)
      const kinds = normalizeKinds(meta)
      const busy = list.loading
      const pages = Math.max(1, Math.ceil((list.total || 0) / (list.pageSize || PAGE_SIZE)))

      let content
      if (detail) {
        content = h(DetailView, {
          state: detail,
          onBack: () => setDetail(null),
          onReload: reloadDetail,
          onUpload: openUpload,
          onEdit: (asset) => setDialog({ type: 'edit', asset }),
          onDelete: (asset) => setDialog({ type: 'delete', asset }),
          onDownload: downloadAsset,
          onPreview: previewFile,
          onInstall: installAsset,
          onUninstall: (asset) => setDialog({ type: 'uninstall', asset }),
          onUpgrade: (asset) => setDialog({ type: 'upgrade', asset }),
          pushToast,
        })
      } else {
        content = h(
          React.Fragment,
          null,
          h(
            'div',
            { className: 'ah-toolbar' },
            h(
              'div',
              { className: 'ah-seg', role: 'tablist', 'aria-label': t('kind') },
              [['', t('all')], ...KINDS.map((kind) => [kind, t(kindKey(kind))])].map(([value, label]) =>
                h(
                  'button',
                  {
                    key: value || 'all',
                    type: 'button',
                    className: `ah-seg-btn${filters.kind === value ? ' is-active' : ''}`,
                    onClick: () => patchFilters({ kind: value }),
                  },
                  label,
                  value && kinds.find((item) => item.kind === value && item.count !== null) ? h('span', { className: 'ah-seg-count' }, kinds.find((item) => item.kind === value).count) : null,
                ),
              ),
            ),
            h(
              'div',
              { className: 'ah-search' },
              h(Icon, { name: 'search', size: 15 }),
              h('input', {
                className: 'ah-search-input',
                value: filters.q,
                placeholder: t('searchPlaceholder'),
                onChange: (event) => patchFilters({ q: event.target.value }),
                'aria-label': t('searchPlaceholder'),
              }),
              filters.q ? h(IconButton, { icon: 'x', label: t('clearFilters'), onClick: () => patchFilters({ q: '' }) }) : null,
            ),
            categories.length > 0
              ? h(
                  'select',
                  { className: 'ah-input ah-select', value: filters.category, onChange: (event) => patchFilters({ category: event.target.value }), 'aria-label': t('category') },
                  h('option', { value: '' }, t('categoryAll')),
                  categories.map((category) => h('option', { key: category, value: category }, category)),
                )
              : null,
            h(
              'select',
              { className: 'ah-input ah-select', value: filters.sort, onChange: (event) => patchFilters({ sort: event.target.value }), 'aria-label': t('sortRecent') },
              h('option', { value: 'recent' }, t('sortRecent')),
              h('option', { value: 'popular' }, t('sortPopular')),
              h('option', { value: 'name' }, t('sortName')),
            ),
            h(
              'label',
              { className: 'ah-check' },
              h('input', {
                type: 'checkbox',
                checked: filters.mine,
                onChange: (event) => {
                  if (event.target.checked && !status?.authenticated) {
                    pushToast('error', t('noTokenAction'))
                    setDialog({ type: 'settings' })
                    return
                  }
                  patchFilters({ mine: event.target.checked })
                },
              }),
              h('span', null, t('mine')),
            ),
            updates.installed.length > 0
              ? h('span', { className: 'ah-muted ah-installed-count' }, t('installedCount').replace('{n}', String(updates.installed.length)))
              : null,
            h(IconButton, { icon: 'refresh', label: t('refresh'), onClick: refreshAll }),
          ),
          updates.count > 0
            ? h(
                'div',
                { className: 'ah-update-banner' },
                h(Icon, { name: 'refresh', size: 16 }),
                h(
                  'div',
                  { className: 'ah-update-main' },
                  h('strong', null, t('updatesAvailable').replace('{count}', String(updates.count))),
                  h('span', { className: 'ah-update-hint' }, t('updatesHint')),
                  h(
                    'div',
                    { className: 'ah-update-list' },
                    updates.updates.slice(0, 4).map((item) =>
                      h(
                        'button',
                        {
                          key: `${item.kind}:${item.id}`,
                          type: 'button',
                          className: 'ah-update-item',
                          onClick: () => openDetail(item),
                        },
                        h('span', { className: 'ah-update-name' }, item.name),
                        h('span', { className: 'ah-update-ver' }, `v${item.installedVersion} → v${item.latestVersion}`),
                      ),
                    ),
                    updates.updates.length > 4 ? h('span', { className: 'ah-muted' }, `+${updates.updates.length - 4}`) : null,
                  ),
                ),
                h(Button, { size: 'sm', onClick: () => updateStore.refresh(true), busy: updates.loading }, t('refresh')),
              )
            : null,
          status && !status.authenticated
            ? h(
                'div',
                { className: 'ah-notice' },
                h(Icon, { name: 'alert', size: 15 }),
                h('span', null, status.tokenTail ? t('authExpired') : t('loginMissing')),
                h('button', { className: 'ah-link', type: 'button', onClick: () => setDialog({ type: 'settings' }) }, t('login')),
              )
            : null,
          list.error
            ? h(
                'div',
                { className: 'ah-alert ah-alert--block' },
                h(Icon, { name: 'alert', size: 16 }),
                h('span', null, list.error),
                h(Button, { size: 'sm', onClick: loadList }, t('retry')),
              )
            : null,
          busy && list.items.length === 0
            ? h(SkeletonGrid)
            : list.items.length === 0
              ? h(EmptyState, {
                  title: filters.q || filters.category || filters.kind || filters.mine ? t('noResultTitle') : t('emptyTitle'),
                  hint: filters.q || filters.category || filters.kind || filters.mine ? t('noResultHint') : t('emptyHint'),
                  action: h(
                    'div',
                    { className: 'ah-empty-actions' },
                    h(Button, { onClick: () => setFilters({ kind: '', q: '', category: '', sort: 'recent', mine: false, page: 1 }) }, t('clearFilters')),
                    h(Button, { variant: 'primary', onClick: () => openUpload('publish') }, h(Icon, { name: 'plus', size: 14 }), t('emptyAction')),
                  ),
                })
              : h(
                  React.Fragment,
                  null,
                  h(
                    'div',
                    { className: 'ah-grid', 'aria-busy': busy ? 'true' : 'false' },
                    list.items.map((asset, index) => h(AssetCard, { key: `${assetKind(asset)}-${assetId(asset)}-${index}`, asset, onOpen: openDetail, updates: updates.updates, installedAssets: updates.installed })),
                  ),
                  h(
                    'div',
                    { className: 'ah-pager' },
                    h('span', { className: 'ah-muted' }, t('totalCount').replace('{n}', String(list.total))),
                    h(
                      'div',
                      { className: 'ah-pager-controls' },
                      h(Button, { size: 'sm', disabled: busy || list.page <= 1, onClick: () => setFilters((current) => ({ ...current, page: Math.max(1, current.page - 1) })) }, t('prev')),
                      h('span', { className: 'ah-muted' }, t('pageOf').replace('{page}', String(list.page)).replace('{pages}', String(pages))),
                      h(Button, { size: 'sm', disabled: busy || !list.hasMore, onClick: () => setFilters((current) => ({ ...current, page: current.page + 1 })) }, t('next')),
                    ),
                  ),
                ),
        )
      }

      return h(
        LocaleCtx.Provider,
        { value: t },
        h(
          'div',
          { className: 'ah-root' },
          h('style', null, CSS),
          h(
            'div',
            { className: 'ah-scroll' },
            h(
              'div',
              { className: 'ah-inner' },
              h(
                'header',
                { className: 'ah-hero' },
                h(
                  'div',
                  { className: 'ah-brand' },
                  h('span', { className: 'ah-brand-icon' }, h(AssetHubIcon, { size: 26 })),
                  h(
                    'div',
                    { className: 'ah-head-text' },
                    h('h1', null, t('title')),
                    h('p', null, t('subtitle')),
                  ),
                ),
                h(
                  'div',
                  { className: 'ah-head-actions' },
                  status?.authenticated
                    ? h(
                        'span',
                        {
                          className: 'ah-endpoint',
                          title: `${t('patBadge')}${status.loginId ? ` · ${status.loginId}` : ''} · ${status.baseUrl}`,
                        },
                        `${t('patBadge')} · ${status.tokenTail || ''}`,
                      )
                    : status?.baseUrl
                      ? h('span', { className: 'ah-endpoint', title: status.baseUrl }, status.baseUrl)
                      : null,
                  h(Button, { onClick: () => setDialog({ type: 'settings' }) }, h(Icon, { name: 'settings', size: 15 }), t('settings')),
                  h(Button, { variant: 'primary', onClick: () => openUpload('publish') }, h(Icon, { name: 'plus', size: 15 }), t('publish')),
                ),
              ),
              content,
            ),
          ),
          h(Toasts, { items: toasts }),
          dialog && dialog.type === 'upload'
            ? h(UploadDialog, {
                mode: dialog.mode,
                asset: dialog.asset,
                pushToast,
                onAuthExpired: handleAuthExpired,
                onClose: () => setDialog(null),
                onDone: (asset) => {
                  setDialog(null)
                  refreshAll()
                  if (asset && assetId(asset) !== undefined) openDetail(asset)
                  else if (detail) reloadDetail('meta')
                },
              })
            : null,
          dialog && dialog.type === 'edit'
            ? h(EditDialog, {
                asset: dialog.asset,
                pushToast,
                onAuthExpired: handleAuthExpired,
                onClose: () => setDialog(null),
                onDone: (asset) => {
                  setDialog(null)
                  if (asset && assetId(asset) !== undefined) setDetail((current) => (current ? { ...current, asset } : { asset, versions: [], files: null, loading: false }))
                  else if (detail) reloadDetail('meta')
                  refreshAll()
                },
              })
            : null,
          dialog && dialog.type === 'delete'
            ? h(ConfirmDeleteDialog, {
                asset: dialog.asset,
                pushToast,
                onAuthExpired: handleAuthExpired,
                onClose: () => setDialog(null),
                onDone: () => {
                  setDialog(null)
                  setDetail(null)
                  refreshAll()
                },
              })
            : null,
          dialog && dialog.type === 'uninstall'
            ? h(ConfirmUninstallDialog, {
                asset: dialog.asset,
                pushToast,
                onClose: () => setDialog(null),
                onDone: async () => {
                  setDialog(null)
                  if (detail && detail.asset) {
                    const kind = assetKind(detail.asset)
                    const id = assetId(detail.asset)
                    let install = null
                    try {
                      install = await rpc('installStatus', { kind, id })
                    } catch {
                      install = null
                    }
                    setDetail((value) => (value ? { ...value, install, installResult: null, installError: '' } : value))
                  }
                  refreshAll()
                },
              })
            : null,
          dialog && dialog.type === 'upgrade'
            ? h(ConfirmUpgradeDialog, {
                asset: dialog.asset,
                install: detail?.install || null,
                onClose: () => setDialog(null),
                onConfirm: () => {
                  const asset = dialog.asset
                  setDialog(null)
                  installAsset(asset)
                },
              })
            : null,
          dialog && dialog.type === 'settings'
            ? h(SettingsDialog, {
                status,
                pushToast,
                onClose: () => setDialog(null),
                onStatus: (next) => {
                  if (!next) return
                  setStatus(next)
                  if (!next.authenticated) setFilters((current) => ({ ...current, mine: false, page: 1 }))
                  setReloadToken((value) => value + 1)
                  rpc('meta')
                    .then(setMeta)
                    .catch(() => {})
                },
                onSaved: (next) => {
                  if (next) setStatus(next)
                  setDialog(null)
                  refreshAll()
                },
              })
            : null,
          dialog && dialog.type === 'text'
            ? h(TextDialog, { title: dialog.title, text: dialog.text, onClose: () => setDialog(null) })
            : null,
        ),
      )
    }

    // ------------------------------------------------------------------ css

    const CSS = `
.ah-root{display:flex;flex-direction:column;height:100%;min-height:0;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);font-size:13px;line-height:1.5}
.ah-scroll{flex:1;min-height:0;overflow:auto}
.ah-inner{max-width:1160px;margin:0 auto;padding:26px 28px 48px}
.ah-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:18px}
.ah-head h1{margin:0;font-size:20px;line-height:1.3;font-weight:600;letter-spacing:-.01em}
.ah-head p{margin:4px 0 0;color:var(--dsw-alias-label-secondary);font-size:12.5px}
.ah-head-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.ah-endpoint{max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--dsw-alias-label-secondary);font-size:11.5px;border:1px solid var(--dsw-alias-border-l1);border-radius:999px;padding:4px 10px}
.ah-toolbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:10px 12px;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);border-radius:12px;margin-bottom:16px}
.ah-seg{display:inline-flex;align-items:center;gap:2px;padding:2px;background:var(--dsw-alias-bg-layer-2);border-radius:9px;flex:0 0 auto}
.ah-seg--full{width:100%}
.ah-seg--full .ah-seg-btn{flex:1}
.ah-seg-btn{appearance:none;border:0;background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-size:12.5px;padding:5px 10px;border-radius:7px;cursor:pointer;display:inline-flex;align-items:center;gap:5px;white-space:nowrap}
.ah-seg-btn:hover{color:var(--dsw-alias-label-primary)}
.ah-seg-btn.is-active{background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);box-shadow:0 1px 2px rgba(0,0,0,.08)}
.ah-seg-count{font-size:10.5px;color:var(--dsw-alias-label-secondary);background:var(--dsw-alias-bg-layer-2);border-radius:999px;padding:0 5px;line-height:15px}
.ah-search{display:flex;align-items:center;gap:6px;flex:1 1 220px;min-width:160px;background:var(--dsw-alias-bg-layer-2);border:1px solid transparent;border-radius:9px;padding:0 8px;color:var(--dsw-alias-label-secondary);height:32px}
.ah-search:focus-within{border-color:var(--dsw-alias-border-l2)}
.ah-search-input{flex:1;min-width:0;border:0;outline:0;background:transparent;color:var(--dsw-alias-label-primary);font:inherit;font-size:12.5px;height:100%}
.ah-input{width:100%;box-sizing:border-box;background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);border:1px solid var(--dsw-alias-border-l1);border-radius:8px;padding:7px 9px;font:inherit;font-size:12.5px;outline:0}
.ah-input:focus{border-color:var(--dsw-alias-brand-primary)}
.ah-textarea{resize:vertical;min-height:64px;line-height:1.5}
.ah-select{width:auto;min-width:104px;height:32px;padding:0 8px;flex:0 0 auto}
.ah-check{display:inline-flex;align-items:center;gap:7px;color:var(--dsw-alias-label-secondary);font-size:12.5px;cursor:pointer;user-select:none;white-space:nowrap}
.ah-check input{accent-color:var(--dsw-alias-brand-primary);margin:0}
.ah-check--block{display:flex;align-items:flex-start;padding:8px 10px;background:var(--dsw-alias-bg-layer-2);border-radius:8px;white-space:normal}
.ah-check--block small{display:block;color:var(--dsw-alias-label-secondary);font-size:11.5px;margin-top:2px}
.ah-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);border-radius:8px;padding:6px 11px;font:inherit;font-size:12.5px;line-height:18px;cursor:pointer;white-space:nowrap;transition:background .12s,border-color .12s}
.ah-btn:hover:not(:disabled){background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-border-l2)}
.ah-btn:disabled{opacity:.5;cursor:default}
.ah-btn--primary{background:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-brand-primary);color:var(--dsw-alias-bg-base)}
.ah-btn--primary:hover:not(:disabled){filter:brightness(1.06);background:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-brand-primary)}
.ah-btn--danger{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-border-l1)}
.ah-btn--danger:hover:not(:disabled){background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-state-error-primary)}
.ah-btn--sm{padding:3px 8px;font-size:11.5px;line-height:16px}
.ah-btn--md{height:32px}
.ah-iconbtn{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;border:0;background:transparent;color:var(--dsw-alias-label-secondary);border-radius:6px;cursor:pointer;padding:0}
.ah-iconbtn:hover:not(:disabled){background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary)}
.ah-iconbtn--danger:hover:not(:disabled){color:var(--dsw-alias-state-error-primary)}
.ah-iconbtn:disabled{opacity:.5;cursor:default}
.ah-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(264px,1fr));gap:12px}
.ah-card{display:flex;flex-direction:column;gap:7px;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);border-radius:12px;padding:14px;cursor:pointer;transition:border-color .12s,transform .12s;min-height:132px;outline:none}
.ah-card:hover,.ah-card:focus-visible{border-color:var(--dsw-alias-border-l2)}
.ah-card:focus-visible{box-shadow:0 0 0 2px color-mix(in srgb,var(--dsw-alias-brand-primary) 35%,transparent)}
.ah-card-top{display:flex;align-items:center;justify-content:space-between;gap:8px}
.ah-card-flags{display:inline-flex;align-items:center;justify-content:flex-end;gap:6px;flex-wrap:wrap;min-width:0}
.ah-badge{display:inline-flex;align-items:center;gap:5px;font-size:11px;line-height:18px;padding:1px 7px;border-radius:999px;border:1px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-label-secondary);background:var(--dsw-alias-bg-layer-2);white-space:nowrap}
.ah-badge--skill{color:var(--dsw-alias-state-success-primary)}
.ah-badge--mcp{color:var(--dsw-alias-brand-primary)}
.ah-badge--plugin{color:var(--dsw-alias-state-warn-primary)}
.ah-badge--warn{color:var(--dsw-alias-state-warn-primary)}
.ah-badge--installed{color:var(--dsw-alias-state-success-primary)}
.ah-install .ah-btn--primary{width:100%;margin-top:4px}
.ah-install-row{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:8px;flex-wrap:wrap}
.ah-install-ok{display:inline-flex;align-items:center;gap:5px;color:var(--dsw-alias-state-success-primary);font-size:12px}
.ah-dot{width:5px;height:5px;border-radius:50%;background:currentColor}
.ah-version{font-size:11px;color:var(--dsw-alias-label-secondary);font-variant-numeric:tabular-nums}
.ah-card-title{margin:0;font-size:14px;font-weight:600;line-height:1.35;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ah-card-summary{margin:0;color:var(--dsw-alias-label-secondary);font-size:12px;line-height:1.45;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;min-height:34px}
.ah-tagrow{display:flex;flex-wrap:wrap;gap:5px}
.ah-tag{font-size:10.5px;line-height:17px;padding:0 6px;border-radius:5px;background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-secondary);border:1px solid var(--dsw-alias-border-l1)}
.ah-card-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:auto;color:var(--dsw-alias-label-secondary);font-size:11px}
.ah-card-owner{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ah-skeleton{min-height:132px;background:linear-gradient(100deg,var(--dsw-alias-bg-layer-1) 30%,var(--dsw-alias-bg-layer-2) 50%,var(--dsw-alias-bg-layer-1) 70%);background-size:200% 100%;animation:ah-shimmer 1.4s ease-in-out infinite}
@keyframes ah-shimmer{0%{background-position:120% 0}100%{background-position:-20% 0}}
.ah-spinner{width:15px;height:15px;border-radius:50%;border:2px solid var(--dsw-alias-border-l2);border-top-color:var(--dsw-alias-brand-primary);display:inline-block;animation:ah-spin .7s linear infinite}
.ah-spinner--sm{width:11px;height:11px;border-width:1.5px}
@keyframes ah-spin{to{transform:rotate(360deg)}}
.ah-loading{display:flex;align-items:center;gap:8px;color:var(--dsw-alias-label-secondary);padding:18px 0}
.ah-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;gap:8px;padding:64px 20px;border:1px dashed var(--dsw-alias-border-l1);border-radius:14px;background:var(--dsw-alias-bg-layer-1)}
.ah-empty-icon{color:var(--dsw-alias-label-secondary);opacity:.65;margin-bottom:2px}
.ah-empty h3{margin:0;font-size:15px;font-weight:600}
.ah-empty p{margin:0;color:var(--dsw-alias-label-secondary);max-width:420px;font-size:12.5px}
.ah-empty-actions{display:flex;gap:8px;margin-top:6px;flex-wrap:wrap;justify-content:center}
.ah-notice{display:flex;align-items:center;gap:8px;padding:8px 12px;margin-bottom:14px;border-radius:9px;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);color:var(--dsw-alias-label-secondary);font-size:12px}
.ah-link{border:0;background:transparent;color:var(--dsw-alias-brand-primary);font:inherit;cursor:pointer;padding:0;text-decoration:underline;text-underline-offset:2px}
.ah-alert{display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:8px;border:1px solid var(--dsw-alias-state-error-primary);color:var(--dsw-alias-state-error-primary);background:color-mix(in srgb,var(--dsw-alias-state-error-primary) 7%,transparent);font-size:12px;margin-top:10px}
.ah-alert--ok{border-color:var(--dsw-alias-state-success-primary);color:var(--dsw-alias-state-success-primary);background:color-mix(in srgb,var(--dsw-alias-state-success-primary) 7%,transparent)}
.ah-alert--block{margin-bottom:14px}
.ah-alert span{flex:1;min-width:0}
.ah-pager{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:18px;flex-wrap:wrap}
.ah-pager-controls{display:flex;align-items:center;gap:8px}
.ah-muted{color:var(--dsw-alias-label-secondary)}
.ah-right{text-align:right}
.ah-wrap{white-space:pre-wrap;word-break:break-word}
.ah-detail-bar{margin-bottom:12px}
.ah-detail-head{display:flex;gap:16px;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;margin-bottom:10px}
.ah-detail-titlewrap{min-width:0;flex:1 1 320px}
.ah-detail-kicker{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px}
.ah-detail-title{margin:0;font-size:21px;font-weight:600;line-height:1.25;letter-spacing:-.01em;word-break:break-word}
.ah-detail-summary{margin:5px 0 0;color:var(--dsw-alias-label-secondary);font-size:13px}
.ah-detail-sub{display:flex;gap:14px;flex-wrap:wrap;color:var(--dsw-alias-label-secondary);font-size:11.5px;margin-top:7px}
.ah-detail-actions{display:flex;align-items:center;gap:7px;flex-wrap:wrap}
.ah-tabs{display:flex;align-items:center;gap:2px;border-bottom:1px solid var(--dsw-alias-border-l1);margin:14px 0 16px;padding-bottom:6px;flex-wrap:wrap}
.ah-tab{border:0;background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-size:12.5px;padding:5px 9px;border-radius:7px;cursor:pointer}
.ah-tab:hover{color:var(--dsw-alias-label-primary)}
.ah-tab.is-active{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-2)}
.ah-tabs-spacer{flex:1}
.ah-detail-grid{display:grid;grid-template-columns:minmax(0,1fr) 300px;gap:14px;align-items:start}
.ah-panel{background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);border-radius:12px;padding:14px 16px;min-width:0}
.ah-panel + .ah-panel{margin-top:12px}
.ah-panel h2{margin:0 0 8px;font-size:13px;font-weight:600}
.ah-panel-head{display:flex;align-items:center;justify-content:space-between;gap:8px}
.ah-panel-head h2{margin:0}
.ah-prose{margin:8px 0 0;white-space:pre-wrap;word-break:break-word;font-size:12.5px;line-height:1.65;color:var(--dsw-alias-label-primary)}
.ah-kv{display:grid;grid-template-columns:auto minmax(0,1fr);gap:6px 12px;margin:8px 0 0;font-size:12px}
.ah-kv dt{color:var(--dsw-alias-label-secondary);white-space:nowrap}
.ah-kv dd{margin:0;overflow-wrap:anywhere}
.ah-kv code,.ah-code{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11.5px}
.ah-kv code{background:var(--dsw-alias-bg-layer-2);border-radius:4px;padding:1px 5px}
.ah-code{margin:0;padding:12px;background:var(--dsw-alias-bg-layer-2);border-radius:8px;max-height:60vh;overflow:auto;white-space:pre-wrap;word-break:break-word;line-height:1.55}
.ah-table{width:100%;border-collapse:collapse;font-size:12px}
.ah-table th{text-align:left;font-weight:500;color:var(--dsw-alias-label-secondary);padding:7px 8px;border-bottom:1px solid var(--dsw-alias-border-l1);white-space:nowrap}
.ah-table td{padding:7px 8px;border-bottom:1px solid var(--dsw-alias-border-l1);vertical-align:top}
.ah-table tr:last-child td{border-bottom:0}
.ah-table code{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11.5px;background:var(--dsw-alias-bg-layer-2);border-radius:4px;padding:1px 5px}
.ah-mini{display:inline-block;margin-left:6px;font-size:10px;color:var(--dsw-alias-state-success-primary)}
.ah-files{list-style:none;margin:8px 0 0;padding:0;display:flex;flex-direction:column;gap:2px;max-height:52vh;overflow:auto}
.ah-file{display:flex;align-items:center;gap:9px;padding:6px 8px;border-radius:7px;font-size:12px}
.ah-file:hover{background:var(--dsw-alias-bg-layer-2)}
.ah-file-path{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:11.5px}
.ah-file-size{color:var(--dsw-alias-label-secondary);font-size:11px}
.ah-backdrop{position:fixed;inset:0;z-index:60;background:rgba(0,0,0,.38);display:flex;align-items:center;justify-content:center;padding:24px;animation:ah-fade .12s ease-out}
@keyframes ah-fade{from{opacity:0}to{opacity:1}}
.ah-modal{width:100%;max-height:88vh;display:flex;flex-direction:column;background:var(--dsw-alias-bg-overlay);border:1px solid var(--dsw-alias-border-l1);border-radius:14px;box-shadow:0 18px 48px rgba(0,0,0,.24);outline:none;animation:ah-pop .14s ease-out}
@keyframes ah-pop{from{transform:translateY(6px);opacity:.6}to{transform:none;opacity:1}}
.ah-modal-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 16px 10px}
.ah-modal-head h2{margin:0;font-size:15px;font-weight:600}
.ah-modal-body{padding:2px 16px 16px;overflow:auto}
.ah-form{display:flex;flex-direction:column;gap:11px}
.ah-form-note{margin:0;color:var(--dsw-alias-label-secondary);font-size:12px}
.ah-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:11px}
.ah-field{display:flex;flex-direction:column;gap:5px;min-width:0}
.ah-field-label{font-size:12px;color:var(--dsw-alias-label-secondary)}
.ah-field-hint{font-size:11px;color:var(--dsw-alias-label-secondary);opacity:.85}
.ah-field-error{font-size:11px;color:var(--dsw-alias-state-error-primary)}
.ah-drop{display:flex;align-items:center;gap:12px;padding:14px 16px;border:1px dashed var(--dsw-alias-border-l2);border-radius:10px;cursor:pointer;color:var(--dsw-alias-label-secondary);background:var(--dsw-alias-bg-layer-2);transition:border-color .12s,background .12s;outline:none}
.ah-drop:hover,.ah-drop:focus-visible,.ah-drop.is-dragging{border-color:var(--dsw-alias-brand-primary);color:var(--dsw-alias-label-primary)}
.ah-drop.has-file{border-style:solid}
.ah-drop-text{display:flex;flex-direction:column;gap:2px;min-width:0}
.ah-drop-text strong{font-size:12.5px;font-weight:600;color:var(--dsw-alias-label-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ah-drop-text span{font-size:11.5px}
.ah-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.ah-actions--end{justify-content:flex-end;margin-top:12px}
.ah-actions--between{justify-content:space-between;margin-top:4px}
.ah-confirm-text{margin:2px 0 0;font-size:12.5px;line-height:1.6;color:var(--dsw-alias-label-secondary)}
.ah-warn{color:var(--dsw-alias-state-warn-primary)}
.ah-auth-status{display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l1);border-radius:9px}
.ah-auth-dot{width:7px;height:7px;border-radius:50%;background:var(--dsw-alias-state-idle-primary);flex:0 0 auto}
.ah-auth-dot.is-on{background:var(--dsw-alias-state-success-primary)}
.ah-auth-text{display:flex;flex-direction:column;gap:2px;flex:1;min-width:0;font-size:12px}
.ah-auth-text strong{font-weight:600;font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ah-auth-text span{color:var(--dsw-alias-label-secondary);font-size:11.5px}
.ah-toasts{position:fixed;right:20px;bottom:20px;z-index:80;display:flex;flex-direction:column;gap:8px;pointer-events:none}
.ah-toast{display:flex;align-items:center;gap:8px;background:var(--dsw-alias-bg-overlay);border:1px solid var(--dsw-alias-border-l2);border-radius:9px;padding:8px 12px;font-size:12.5px;box-shadow:0 8px 24px rgba(0,0,0,.18);max-width:360px;animation:ah-pop .14s ease-out}
.ah-toast--success{color:var(--dsw-alias-label-primary)}
.ah-toast--success svg{color:var(--dsw-alias-state-success-primary)}
.ah-toast--error{border-color:var(--dsw-alias-state-error-primary);color:var(--dsw-alias-state-error-primary)}
@media (max-width:860px){.ah-detail-grid{grid-template-columns:1fr}.ah-inner{padding:18px 16px 40px}.ah-form-grid{grid-template-columns:1fr}}

/* ---------- visual refresh ---------- */
.ah-inner{max-width:1200px;padding:22px 26px 56px}
.ah-hero{position:relative;overflow:hidden;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:16px;padding:18px 20px;border:1px solid var(--dsw-alias-border-l1);border-radius:16px;background:radial-gradient(120% 180% at 0% 0%,color-mix(in srgb,var(--dsw-alias-brand-primary) 15%,transparent),transparent 55%),radial-gradient(120% 180% at 100% 0%,color-mix(in srgb,var(--dsw-alias-state-success-primary) 9%,transparent),transparent 52%),var(--dsw-alias-bg-layer-1);box-shadow:0 1px 2px rgba(0,0,0,.04)}
.ah-hero::before{content:"";position:absolute;inset:0;background-image:radial-gradient(color-mix(in srgb,var(--dsw-alias-label-secondary) 14%,transparent) 1px,transparent 1px);background-size:18px 18px;opacity:.35;pointer-events:none;mask-image:linear-gradient(100deg,transparent,black 55%,transparent)}
.ah-brand{display:flex;align-items:center;gap:13px;min-width:0;position:relative}
.ah-brand-icon{display:flex;align-items:center;justify-content:center;width:46px;height:46px;border-radius:13px;color:var(--dsw-alias-bg-base);background:linear-gradient(140deg,color-mix(in srgb,var(--dsw-alias-brand-primary) 82%,var(--dsw-alias-bg-base)),var(--dsw-alias-brand-primary));box-shadow:0 4px 12px color-mix(in srgb,var(--dsw-alias-brand-primary) 28%,transparent);flex:0 0 auto}
.ah-hero h1{margin:0;font-size:21px;line-height:1.25;font-weight:600;letter-spacing:-.015em}
.ah-hero p{margin:5px 0 0;color:var(--dsw-alias-label-secondary);font-size:12.5px}
.ah-hero .ah-head-actions{position:relative}
.ah-endpoint{border-color:color-mix(in srgb,var(--dsw-alias-border-l1) 70%,transparent);background:color-mix(in srgb,var(--dsw-alias-bg-base) 55%,transparent);backdrop-filter:blur(6px)}
.ah-toolbar{position:sticky;top:10px;z-index:6;margin-bottom:18px;padding:9px 10px;border-radius:14px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-1) 86%,transparent);backdrop-filter:blur(12px);box-shadow:0 4px 16px rgba(0,0,0,.05)}
.ah-seg{padding:3px;border-radius:10px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2) 80%,transparent)}
.ah-seg-btn{padding:5px 11px;border-radius:7px;transition:background .14s ease,color .14s ease,box-shadow .14s ease}
.ah-seg-btn.is-active{background:var(--dsw-alias-bg-layer-1);box-shadow:0 1px 3px rgba(0,0,0,.12);font-weight:500}
.ah-search{height:34px;border-radius:10px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2) 85%,transparent);border:1px solid transparent;transition:border-color .14s ease,box-shadow .14s ease}
.ah-search:focus-within{border-color:color-mix(in srgb,var(--dsw-alias-brand-primary) 55%,transparent);box-shadow:0 0 0 3px color-mix(in srgb,var(--dsw-alias-brand-primary) 14%,transparent)}
.ah-grid{gap:14px}
.ah-card{position:relative;overflow:hidden;min-height:150px;padding:16px;border-radius:14px;background:linear-gradient(180deg,var(--dsw-alias-bg-layer-1),color-mix(in srgb,var(--dsw-alias-bg-layer-1) 92%,var(--dsw-alias-bg-layer-2)));box-shadow:0 1px 2px rgba(0,0,0,.03);transition:transform .16s ease,box-shadow .16s ease,border-color .16s ease}
.ah-card::before{content:"";position:absolute;left:0;top:14px;bottom:14px;width:3px;border-radius:0 3px 3px 0;background:var(--dsw-alias-brand-primary);opacity:.85}
.ah-card--skill::before{background:var(--dsw-alias-state-success-primary)}
.ah-card--mcp::before{background:var(--dsw-alias-brand-primary)}
.ah-card--plugin::before{background:var(--dsw-alias-state-warn-primary)}
.ah-card:hover,.ah-card:focus-visible{transform:translateY(-2px);box-shadow:0 10px 28px rgba(0,0,0,.10);border-color:color-mix(in srgb,var(--dsw-alias-label-secondary) 28%,transparent)}
.ah-card-glyph{position:absolute;right:-6px;bottom:-10px;color:var(--dsw-alias-label-primary);opacity:.05;pointer-events:none;transition:opacity .2s ease,transform .2s ease}
.ah-card:hover .ah-card-glyph{opacity:.09;transform:scale(1.04)}
.ah-card-title{font-size:14.5px}
.ah-card-summary{min-height:36px}
.ah-badge{padding:2px 8px;font-weight:500}
.ah-badge--skill{background:color-mix(in srgb,var(--dsw-alias-state-success-primary) 10%,transparent);border-color:color-mix(in srgb,var(--dsw-alias-state-success-primary) 24%,transparent)}
.ah-badge--mcp{background:color-mix(in srgb,var(--dsw-alias-brand-primary) 10%,transparent);border-color:color-mix(in srgb,var(--dsw-alias-brand-primary) 24%,transparent)}
.ah-badge--plugin{background:color-mix(in srgb,var(--dsw-alias-state-warn-primary) 11%,transparent);border-color:color-mix(in srgb,var(--dsw-alias-state-warn-primary) 25%,transparent)}
.ah-badge--installed{background:color-mix(in srgb,var(--dsw-alias-state-success-primary) 10%,transparent);border-color:color-mix(in srgb,var(--dsw-alias-state-success-primary) 24%,transparent)}
.ah-btn{border-radius:9px;transition:transform .12s ease,background .12s ease,border-color .12s ease,box-shadow .12s ease}
.ah-btn:active:not(:disabled){transform:translateY(1px)}
.ah-btn--primary{background:linear-gradient(180deg,color-mix(in srgb,var(--dsw-alias-brand-primary) 92%,var(--dsw-alias-bg-base)),var(--dsw-alias-brand-primary));box-shadow:0 2px 8px color-mix(in srgb,var(--dsw-alias-brand-primary) 26%,transparent)}
.ah-btn--primary:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 5px 14px color-mix(in srgb,var(--dsw-alias-brand-primary) 32%,transparent);filter:none}
.ah-btn:focus-visible,.ah-iconbtn:focus-visible,.ah-seg-btn:focus-visible,.ah-tab:focus-visible{outline:none;box-shadow:0 0 0 3px color-mix(in srgb,var(--dsw-alias-brand-primary) 22%,transparent)}
.ah-panel{border-radius:14px;box-shadow:0 1px 2px rgba(0,0,0,.03)}
.ah-panel h2{font-size:13px;font-weight:600;letter-spacing:.01em}
.ah-install{background:linear-gradient(180deg,color-mix(in srgb,var(--dsw-alias-brand-primary) 7%,var(--dsw-alias-bg-layer-1)),var(--dsw-alias-bg-layer-1));border-color:color-mix(in srgb,var(--dsw-alias-brand-primary) 20%,var(--dsw-alias-border-l1))}
.ah-detail-head{padding:18px;border:1px solid var(--dsw-alias-border-l1);border-radius:16px;background:linear-gradient(120deg,color-mix(in srgb,var(--dsw-alias-brand-primary) 9%,var(--dsw-alias-bg-layer-1)),var(--dsw-alias-bg-layer-1) 58%);margin-bottom:10px;box-shadow:0 1px 2px rgba(0,0,0,.03)}
.ah-detail-head--skill{background:linear-gradient(120deg,color-mix(in srgb,var(--dsw-alias-state-success-primary) 9%,var(--dsw-alias-bg-layer-1)),var(--dsw-alias-bg-layer-1) 58%)}
.ah-detail-head--plugin{background:linear-gradient(120deg,color-mix(in srgb,var(--dsw-alias-state-warn-primary) 9%,var(--dsw-alias-bg-layer-1)),var(--dsw-alias-bg-layer-1) 58%)}
.ah-detail-title{font-size:23px}
.ah-tabs{gap:4px;border-bottom:0;padding:4px;border:1px solid var(--dsw-alias-border-l1);border-radius:11px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-1) 80%,transparent)}
.ah-tab{border-radius:7px;transition:background .14s ease,color .14s ease}
.ah-tab.is-active{background:var(--dsw-alias-bg-layer-2);box-shadow:inset 0 0 0 1px var(--dsw-alias-border-l1)}
.ah-auth-status{background:linear-gradient(180deg,color-mix(in srgb,var(--dsw-alias-brand-primary) 5%,var(--dsw-alias-bg-layer-2)),var(--dsw-alias-bg-layer-2))}
.ah-empty{padding:70px 20px;border-radius:16px;background:radial-gradient(120% 160% at 50% 0%,color-mix(in srgb,var(--dsw-alias-brand-primary) 7%,transparent),transparent 60%),var(--dsw-alias-bg-layer-1)}
.ah-empty-icon{width:58px;height:58px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:color-mix(in srgb,var(--dsw-alias-brand-primary) 10%,transparent);color:var(--dsw-alias-brand-primary);opacity:1;margin-bottom:4px}
.ah-backdrop{background:rgba(0,0,0,.42);backdrop-filter:blur(6px)}
.ah-modal{border-radius:16px;box-shadow:0 24px 64px rgba(0,0,0,.28)}
.ah-modal-head{border-bottom:1px solid var(--dsw-alias-border-l1);padding:15px 18px 12px}
.ah-modal-body{padding:14px 18px 18px}
.ah-toast{border-radius:11px;box-shadow:0 10px 30px rgba(0,0,0,.18)}
.ah-scroll::-webkit-scrollbar{width:10px;height:10px}
.ah-scroll::-webkit-scrollbar-thumb{background:color-mix(in srgb,var(--dsw-alias-label-secondary) 22%,transparent);border-radius:8px;border:3px solid transparent;background-clip:padding-box}
.ah-scroll::-webkit-scrollbar-track{background:transparent}
.ah-sidebar-icon{position:relative;display:inline-flex;align-items:center;justify-content:center}
.ah-sidebar-badge{position:absolute;top:-5px;right:-7px;min-width:15px;height:15px;padding:0 3px;border-radius:999px;background:var(--dsw-alias-state-error-primary,#e5484d);color:#fff;font-size:9px;line-height:15px;font-weight:600;text-align:center;box-shadow:0 0 0 2px var(--dsw-alias-bg-layer-1,#fff);pointer-events:none}
.ah-update-banner{display:flex;align-items:flex-start;gap:12px;padding:12px 14px;margin:0 0 14px;border:1px solid color-mix(in srgb,var(--dsw-alias-state-warn-primary) 34%,var(--dsw-alias-border-l1));background:color-mix(in srgb,var(--dsw-alias-state-warn-primary) 8%,var(--dsw-alias-bg-layer-1));border-radius:12px}
.ah-update-main{min-width:0;flex:1;display:flex;flex-direction:column;gap:6px}
.ah-update-main strong{font-size:13px}
.ah-update-hint{font-size:12px;color:var(--dsw-alias-label-secondary)}
.ah-update-list{display:flex;flex-wrap:wrap;gap:6px}
.ah-update-item{display:inline-flex;align-items:center;gap:8px;max-width:100%;padding:4px 8px;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);font:inherit;font-size:12px;cursor:pointer}
.ah-update-item:hover{background:var(--dsw-alias-interactive-bg-hover)}
.ah-update-name{font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ah-update-ver{color:var(--dsw-alias-state-warn-primary);font-variant-numeric:tabular-nums;white-space:nowrap}
.ah-card--update{border-color:color-mix(in srgb,var(--dsw-alias-state-warn-primary) 45%,var(--dsw-alias-border-l1))}
@media (max-width:720px){.ah-hero{padding:14px}.ah-brand-icon{width:40px;height:40px}.ah-toolbar{position:static}}
@media (prefers-reduced-motion:reduce){.ah-card,.ah-btn,.ah-modal,.ah-toast{transition:none;animation:none}}
`

    return {
      inject: ['slots', 'locale'],
      apply(ctx) {
        ctx.effect(
          () =>
            ctx.locale.register(NS, {
              zh,
              en,
            }),
          'asset-hub: dictionaries',
        )
        const t = ctx.locale.bind(NS)

        ctx.slots.inject('sidebar.panellist', () =>
          ctx.slots.register(
            {
              name: 'sidebar.panellist',
              id: PANEL_ID,
              order: 20,
              label: () => t('panel'),
              locale: NS,
            },
            (props) => h(SidebarAssetHubIcon, { ...props, t }),
          ),
        )

        ctx.slots.inject('main', () =>
          ctx.slots.register(
            {
              name: 'main',
              key: PANEL_ID,
              locale: NS,
            },
            AssetHubPage,
          ),
        )
      },
    }
  },
})
