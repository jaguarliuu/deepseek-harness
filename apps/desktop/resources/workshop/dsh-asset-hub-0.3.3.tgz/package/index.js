/**
 * Host half of the Ops Workshop Repository plugin.
 *
 * Owns every network call to the asset hub (the page never talks to the hub
 * directly, so CORS and self-signed certificates stay a Host concern), exposes
 * them to the page through a same-origin route, and offers the same operations
 * to the agent as the `asset_hub` tool.
 */

import { readFile, writeFile, mkdir } from 'node:fs/promises'
import { homedir } from 'node:os'
import { dirname, isAbsolute, join, resolve, sep } from 'node:path'
import { fileURLToPath } from 'node:url'
import { HubClient, HubError, defaultInsecureTls, normalizeBaseUrl } from './hub.js'
import { createInstaller, parseSkillManifest } from './installer.js'

export const inject = ['webServer', 'connection']

const ROUTE_PREFIX = '/assets-hub'
const SETTINGS_RECORD = 'asset-hub/settings'
const DEFAULT_BASE_URL = 'https://25.75.3.1'
const BUNDLED_SKILL_DIR = fileURLToPath(new URL('./skill/', import.meta.url))
const MAX_JSON_BODY = 2 * 1024 * 1024
const MAX_UPLOAD_BODY = 64 * 1024 * 1024
const PLUGIN_MAX_BYTES = 20 * 1024 * 1024
const ASSET_MAX_BYTES = 50 * 1024 * 1024

function asString(value, fallback = '') {
  return typeof value === 'string' && value.trim() !== '' ? value.trim() : fallback
}

function sendJson(res, status, value) {
  const body = Buffer.from(JSON.stringify(value), 'utf8')
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': body.length,
    'cache-control': 'no-store',
  })
  res.end(body)
}

function sendError(res, error) {
  const status = error instanceof HubError && error.status >= 400 && error.status < 600 ? error.status : 200
  sendJson(res, status, {
    ok: false,
    error: {
      code: error?.code || 'HUB_ERROR',
      message: error?.message || String(error),
      status: error?.status ?? 0,
      details: error?.details ?? undefined,
    },
  })
}

async function readBody(req, limit) {
  const chunks = []
  let size = 0
  for await (const chunk of req) {
    size += chunk.length
    if (size > limit) {
      throw new HubError({ status: 413, code: 'PAYLOAD_TOO_LARGE', message: `请求体超过 ${Math.round(limit / 1024 / 1024)}MB 上限` })
    }
    chunks.push(chunk)
  }
  return Buffer.concat(chunks)
}

function filenameHeader(name) {
  const ascii = String(name).replace(/[^\x20-\x7e]/g, '_').replace(/["\\]/g, '_')
  return `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(name)}`
}

function normalizeAssetList(result) {
  return {
    items: Array.isArray(result?.items) ? result.items : [],
    page: result?.page ?? 1,
    pageSize: result?.pageSize ?? 20,
    total: result?.total ?? 0,
    hasMore: result?.hasMore ?? false,
  }
}

export function apply(ctx, rawConfig = {}) {
  const config = {
    baseUrl: asString(rawConfig.baseUrl, ''),
    token: asString(rawConfig.token, ''),
    insecureTLS: typeof rawConfig.insecureTLS === 'boolean' ? rawConfig.insecureTLS : undefined,
    requestTimeoutMs: Number.isFinite(rawConfig.requestTimeoutMs) ? rawConfig.requestTimeoutMs : 30000,
  }

  const credentials = () => ctx.get('credentials')
  const workingDirectory = () => ctx.get('workingDirectory')

  // The only long-term credential is a PAT. Account login is just a one-time
  // exchange: password -> access token -> PAT -> discard the access token.
  const TOKEN_ENV = 'ASSET_HUB_PAT'
  const AUTH_SCOPE = 'assets:write'
  const AUTH_SCOPES = [AUTH_SCOPE]
  const PAT_EXPIRY = ['7d', '30d', '90d', '180d']
  const DEFAULT_TOKEN_NAME = 'dsh-asset-hub'

  function parseTime(value) {
    if (!value) return 0
    if (typeof value === 'number') return value
    const parsed = Date.parse(String(value))
    return Number.isFinite(parsed) ? parsed : 0
  }

  function compareVersions(left, right) {
    const parse = (value) => {
      const text = String(value || '').trim().replace(/^v/i, '')
      const [core, pre] = text.split('-', 2)
      return {
        core: core.split('.').map((part) => Number.parseInt(part, 10) || 0),
        pre: pre || '',
      }
    }
    const a = parse(left)
    const b = parse(right)
    for (let index = 0; index < 3; index += 1) {
      const x = a.core[index] || 0
      const y = b.core[index] || 0
      if (x !== y) return x > y ? 1 : -1
    }
    if (a.pre === b.pre) return 0
    if (!a.pre) return 1
    if (!b.pre) return -1
    return a.pre > b.pre ? 1 : -1
  }

  async function readStored() {
    const store = credentials()
    if (!store) return undefined
    try {
      const record = await store.readRecord(SETTINGS_RECORD)
      if (!record) return undefined
      let parsed
      if (record.kind === 'grant' && record.payload && typeof record.payload === 'object') {
        parsed = record.payload
      } else if (record.kind === 'api-key' && typeof record.key === 'string' && record.key !== '') {
        parsed = JSON.parse(record.key)
      }
      if (!parsed || typeof parsed !== 'object') return undefined
      const raw = asString(parsed.token) || asString(parsed.accessToken)
      const isPat = raw.startsWith('ops_pat_')
      return {
        baseUrl: asString(parsed.baseUrl),
        insecureTLS: typeof parsed.insecureTLS === 'boolean' ? parsed.insecureTLS : undefined,
        token: isPat ? raw : '',
        loginId: asString(parsed.loginId || parsed.email),
        patId: parsed.patId ?? null,
        scopes: Array.isArray(parsed.scopes) ? parsed.scopes : null,
        expiresAt: parsed.expiresAt ?? null,
        legacy: Boolean(raw && !isPat),
      }
    } catch {
      return undefined
    }
  }

  async function writeSettings(settings) {
    const store = credentials()
    if (!store) {
      throw new HubError({ code: 'CREDENTIALS_UNAVAILABLE', message: '当前部署没有凭据服务，无法保存 PAT' })
    }
    const now = new Date().toISOString()
    await store.modifyRecord(SETTINGS_RECORD, async (current) => ({
      kind: 'grant',
      payload: {
        baseUrl: settings.baseUrl,
        insecureTLS: Boolean(settings.insecureTLS),
        token: settings.token || '',
        loginId: settings.loginId || '',
        patId: settings.patId ?? null,
        scopes: Array.isArray(settings.scopes) ? settings.scopes : null,
        expiresAt: settings.expiresAt ?? null,
        createdAt: current?.payload?.createdAt || now,
        updatedAt: now,
      },
    }))
  }

  async function resolveSettings(overrides = {}) {
    const stored = await readStored()
    const baseUrl = normalizeBaseUrl(
      overrides.baseUrl !== undefined
        ? overrides.baseUrl
        : stored?.baseUrl || config.baseUrl || process.env.ASSET_HUB_BASE || DEFAULT_BASE_URL,
    )
    const insecureTLS =
      overrides.insecureTLS !== undefined
        ? Boolean(overrides.insecureTLS)
        : typeof stored?.insecureTLS === 'boolean'
          ? stored.insecureTLS
          : typeof config.insecureTLS === 'boolean'
            ? config.insecureTLS
            : defaultInsecureTls(baseUrl)
    const envToken = asString(process.env[TOKEN_ENV])
    const configuredToken = asString(config.token)
    const credentialToken = asString(stored?.token)
    const candidate =
      overrides.token !== undefined
        ? String(overrides.token ?? '').trim()
        : credentialToken || configuredToken || envToken
    // Machine-to-machine calls must use a PAT. A JWT found in config/env is
    // ignored instead of silently being sent to asset endpoints.
    const token = candidate.startsWith('ops_pat_') ? candidate : ''
    const tokenRejected = candidate !== '' && token === ''
    const tokenOrigin =
      overrides.token !== undefined
        ? 'override'
        : credentialToken
          ? 'credential'
          : configuredToken
            ? 'config'
            : envToken
              ? 'env'
              : 'none'
    const tokenSource = token ? tokenOrigin : tokenRejected ? 'invalid' : 'none'
    return {
      baseUrl,
      insecureTLS,
      token,
      tokenSource,
      tokenOrigin,
      tokenRejected,
      loginId: asString(stored?.loginId),
      patId: stored?.patId ?? null,
      scopes: Array.isArray(stored?.scopes) ? stored.scopes : null,
      expiresAt: stored?.expiresAt ?? null,
      legacy: Boolean(stored?.legacy && !credentialToken),
      timeoutMs: config.requestTimeoutMs,
    }
  }

  function statusOf(settings) {
    const hasToken = settings.token !== ''
    const scopes = Array.isArray(settings.scopes) ? settings.scopes : null
    let scopeStatus = 'none'
    if (hasToken) {
      if (scopes === null) scopeStatus = 'unknown'
      else scopeStatus = scopes.includes(AUTH_SCOPE) ? 'ok' : 'missing'
    }
    const expiresAt = parseTime(settings.expiresAt)
    return {
      ok: true,
      baseUrl: settings.baseUrl,
      insecureTLS: settings.insecureTLS,
      reachable: null,
      authenticated: false,
      authMode: hasToken ? 'pat' : 'none',
      tokenSource: settings.tokenSource || (hasToken ? 'credential' : 'none'),
      tokenRejected: Boolean(settings.tokenRejected),
      tokenTail: hasToken ? settings.token.slice(-4) : '',
      loginId: settings.loginId || '',
      scopes,
      scopeStatus,
      scopeRequired: AUTH_SCOPE,
      tokenExpiresAt: settings.expiresAt || null,
      tokenExpired: hasToken && expiresAt > 0 ? Date.now() >= expiresAt : false,
      legacySession: Boolean(settings.legacy),
    }
  }

  function authRequired(message = '请先配置 PAT：运行 asset_hub_auth（action=login 或 action=set）') {
    return new HubError({ status: 401, code: 'AUTH_REQUIRED', message })
  }

  function isAuthFailure(error) {
    return (
      error?.status === 401 ||
      error?.code === 'UNAUTHORIZED' ||
      error?.code === 'AUTH_REQUIRED' ||
      error?.code === 'PAT_INVALID' ||
      error?.code === 'TOKEN_EXPIRED' ||
      error?.code === 'TOKEN_REVOKED'
    )
  }

  function isScopeFailure(error) {
    return error?.status === 403 && error?.code === 'SCOPE_REQUIRED'
  }

  function scopeHint(error) {
    return new HubError({
      status: 403,
      code: 'SCOPE_REQUIRED',
      message: `当前 PAT 缺少所需资产权限（读取需要 assets:read，写需要 assets:write，写权限隐含读）。请用账号重新登录签发新的 PAT，或填写含对应权限的 PAT。`,
      details: error?.details,
    })
  }

  async function authed(operation) {
    const settings = await resolveSettings()
    const run = (token) => operation(new HubClient({ ...settings, token }))
    // Public reads must keep working without a PAT, and a stale PAT should not
    // break them either: fall back to an anonymous request before failing.
    try {
      return await run(settings.token)
    } catch (error) {
      if (!isAuthFailure(error) && !isScopeFailure(error)) throw error
      if (settings.token) {
        try {
          return await run('')
        } catch (anonymousError) {
          if (isScopeFailure(error)) throw scopeHint(error)
          if (isAuthFailure(error)) {
            throw authRequired('PAT 无效或已过期，请重新运行 asset_hub_auth（action=set 或 action=login）')
          }
          throw anonymousError
        }
      }
      if (isScopeFailure(error)) throw scopeHint(error)
      if (settings.tokenRejected) {
        throw new HubError({
          status: 400,
          code: 'INVALID_PAT',
          message: '配置/环境变量中的凭据不是 PAT（应以 ops_pat_ 开头）；JWT 只能用于兑换 PAT，不能用于资产操作。',
        })
      }
      throw authRequired(
        settings.legacy
          ? '检测到旧版账号会话（JWT），该方式已停用；请用账号密码重新登录或填写 PAT'
          : '这个操作需要 PAT；请运行 asset_hub_auth（action=login 或 action=set）',
      )
    }
  }

  const installer = createInstaller({
    ctx,
    dshHome: process.env.DSH_HOME || join(homedir(), '.dsh'),
    withHub: authed,
  })

  let bundledSkillDisposer
  ctx.effect(
    () => () => {
      try {
        bundledSkillDisposer?.()
      } catch {
        /* ignore */
      }
    },
    'asset-hub: bundled skill',
  )
  ctx.inject(['skills'], () => {
    void installer.restoreSkills()
    void (async () => {
      const service = ctx.get('skills')
      if (!service) return
      try {
        const text = await readFile(join(BUNDLED_SKILL_DIR, 'SKILL.md'), 'utf8')
        const { data, body } = parseSkillManifest(text)
        if (!data.name || !data.description) return
        bundledSkillDisposer = service.register({
          name: data.name,
          description: data.description,
          whenToUse: data.when_to_use || data.whenToUse || undefined,
          content: body.trim() || text,
          path: join(BUNDLED_SKILL_DIR, 'SKILL.md'),
          resourceBase: { kind: 'directory', path: BUNDLED_SKILL_DIR },
          invocation: { modelInvocable: true, userInvocable: true },
          source: 'bundled',
          provider: 'asset-hub',
        })
      } catch {
        /* a missing bundled skill must not affect publishing */
      }
    })()
  })

  async function status() {
    const settings = await resolveSettings()
    const result = statusOf(settings)
    try {
      result.meta = await new HubClient({ ...settings, token: '' }).meta()
      result.reachable = true
    } catch (error) {
      result.reachable = false
      result.error = { code: error?.code || 'HUB_ERROR', message: error?.message || String(error) }
    }
    if (settings.token) {
      try {
        await new HubClient(settings).me({ pageSize: 1 })
        result.authenticated = true
      } catch (error) {
        result.authError = { code: error?.code || 'HUB_ERROR', message: error?.message || String(error) }
      }
    }
    if (result.scopeStatus === 'missing') {
      result.scopeWarning = `当前 PAT 的 scopes 是 ${(result.scopes || []).join(', ') || '（空）'}，缺少 ${AUTH_SCOPE}；浏览/下载仍可用，但发布、发版和删除会返回 403 SCOPE_REQUIRED。如需发布，请用账号重新登录签发写权限 PAT（写权限隐含读）。`
    } else if (result.scopeStatus === 'unknown') {
      result.scopeWarning = `无法从本地记录确认当前 PAT 是否包含 ${AUTH_SCOPE}；若发布返回 403 SCOPE_REQUIRED，请用账号重新登录签发。`
    }
    if (result.tokenRejected) {
      const origin =
        settings.tokenOrigin === 'env'
          ? `环境变量 ${TOKEN_ENV}`
          : settings.tokenOrigin === 'config'
            ? '插件配置 token'
            : '配置的凭据'
      result.warning = `${origin}不是 PAT（应以 ops_pat_ 开头），已忽略；JWT 只能用于兑换 PAT，不能用于资产读写或发布。`
    }
    if (result.legacySession) {
      const legacy = '检测到旧版账号会话（JWT）记录，账号会话方式已停用；请用账号密码重新登录，或直接填写 PAT。'
      result.warning = result.warning ? `${result.warning} ${legacy}` : legacy
    }
    if (!settings.token && result.tokenSource === 'none' && !result.legacySession) {
      result.hint = '尚未配置 PAT。运行 asset_hub_auth：action=login（账号密码换 PAT）或 action=set（直接写入 PAT）。'
    }
    return result
  }

  async function savePat(patch = {}) {
    const token = String(patch.token || '').trim()
    if (!token) throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: 'PAT 不能为空' })
    if (!token.startsWith('ops_pat_')) {
      throw new HubError({
        status: 400,
        code: 'VALIDATION_ERROR',
        message: 'PAT 应以 ops_pat_ 开头；access token / JWT 不是长期令牌',
      })
    }
    const base = await resolveSettings({ baseUrl: patch.baseUrl, insecureTLS: patch.insecureTLS, token: '' })
    try {
      await new HubClient({ ...base, token }).me({ pageSize: 1 })
    } catch (error) {
      if (isAuthFailure(error)) throw new HubError({ status: 401, code: 'PAT_INVALID', message: 'PAT 无效或已过期' })
      if (isScopeFailure(error)) throw scopeHint(error)
      throw error
    }
    const next = {
      ...base,
      token,
      loginId: asString(patch.loginId),
      patId: patch.patId ?? null,
      scopes: Array.isArray(patch.scopes) ? patch.scopes : null,
      expiresAt: patch.expiresAt ?? null,
      tokenSource: 'credential',
      legacy: false,
    }
    await writeSettings(next)
    const result = statusOf(next)
    result.authenticated = true
    result.note = 'PAT 已保存到当前 profile 的凭据记录。'
    return result
  }

  async function login(patch = {}) {
    const email = asString(patch.email)
    const password = typeof patch.password === 'string' ? patch.password : ''
    if (!email) throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: '请填写邮箱/用户名/手机号' })
    if (!password) throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: '请填写密码' })
    const expiresIn = String(patch.expiresIn || '180d')
    if (!PAT_EXPIRY.includes(expiresIn)) {
      throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: `expires_in 只能是 ${PAT_EXPIRY.join(' / ')}` })
    }
    const base = await resolveSettings({ baseUrl: patch.baseUrl, insecureTLS: patch.insecureTLS, token: '' })
    const anonymous = new HubClient({ ...base, token: '' })
    let accessToken
    try {
      accessToken = await anonymous.login(email, password)
    } catch (error) {
      if (error?.status === 401) throw new HubError({ status: 401, code: 'LOGIN_FAILED', message: '账号或密码不正确' })
      throw error
    }
    let pat
    try {
      pat = await anonymous.createPat(accessToken, {
        name: asString(patch.tokenName, DEFAULT_TOKEN_NAME),
        scopes: AUTH_SCOPES,
        expiresIn,
      })
    } catch (error) {
      if (isScopeFailure(error)) throw scopeHint(error)
      throw error
    }
    try {
      await new HubClient({ ...base, token: pat.token }).me({ pageSize: 1 })
    } catch (error) {
      if (isAuthFailure(error)) throw new HubError({ status: 401, code: 'PAT_INVALID', message: 'PAT 已创建，但校验失败' })
      throw error
    }
    const next = {
      ...base,
      token: pat.token,
      loginId: email,
      patId: pat.id,
      scopes: pat.scopes,
      expiresAt: pat.expiresAt,
      tokenSource: 'credential',
      legacy: false,
    }
    await writeSettings(next)
    const result = statusOf(next)
    result.authenticated = true
    result.note = '已登录并创建含 assets:write 的 PAT（写权限隐含 assets:read）；密码未保存。'
    return result
  }

  async function importEnvToken(patch = {}) {
    const token = asString(process.env[TOKEN_ENV])
    if (!token) throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: `环境变量 ${TOKEN_ENV} 为空` })
    return savePat({ ...patch, token })
  }

  async function clearAuth() {
    const store = credentials()
    if (!store) throw new HubError({ code: 'CREDENTIALS_UNAVAILABLE', message: '当前 profile 没有 credentials 服务' })
    try {
      await store.deleteRecord(SETTINGS_RECORD)
    } catch {
      /* an absent record is already cleared */
    }
    const result = await status()
    result.cleared = true
    result.note =
      result.tokenSource === 'env' || result.tokenSource === 'config'
        ? `已清除保存的 PAT，但${result.tokenSource === 'env' ? `环境变量 ${TOKEN_ENV}` : '插件配置 token'}里仍有 PAT，仍会作为兜底凭据使用。`
        : '已清除保存的 PAT。如需继续使用，请用账号登录或重新填写 PAT。'
    return result
  }

  async function saveSettings(patch = {}) {
    const current = await resolveSettings()
    const baseUrl = patch.baseUrl !== undefined ? normalizeBaseUrl(patch.baseUrl) : current.baseUrl
    if (!baseUrl) throw new HubError({ code: 'INVALID_BASE_URL', message: '服务地址不能为空' })
    const insecureTLS = patch.insecureTLS !== undefined ? Boolean(patch.insecureTLS) : current.insecureTLS
    const baseChanged = baseUrl !== current.baseUrl
    const next = {
      ...current,
      baseUrl,
      insecureTLS,
      token: baseChanged ? '' : current.token,
      tokenSource: baseChanged ? 'none' : current.tokenSource,
      loginId: baseChanged ? '' : current.loginId,
      patId: baseChanged ? null : current.patId,
      scopes: baseChanged ? null : current.scopes,
      expiresAt: baseChanged ? null : current.expiresAt,
      legacy: baseChanged ? false : current.legacy,
    }
    await writeSettings(next)
    // Re-read through the server so `authenticated` reflects the retained PAT
    // instead of merely echoing the local record.
    return status()
  }

  let updatesCache = { at: 0, data: null }

  async function updates({ force = false } = {}) {
    if (!force && updatesCache.data && Date.now() - updatesCache.at < 60000) return updatesCache.data
    try {
      const installed = await installer.listInstalled()
      if (installed.length === 0) {
        const empty = { ok: true, count: 0, updates: [], installed: [], checkedAt: new Date().toISOString() }
        updatesCache = { at: Date.now(), data: empty }
        return empty
      }
      const assets = []
      let page = 1
      for (;;) {
        const listed = await authed((client) => client.list({ page, pageSize: 100 }))
        const items = Array.isArray(listed?.items) ? listed.items : []
        assets.push(...items)
        if (!listed?.hasMore || page >= 10) break
        page += 1
      }
      const byKey = new Map()
      const byPackage = new Map()
      for (const asset of assets) {
        if (asset?.kind && asset.id !== undefined) byKey.set(`${asset.kind}:${asset.id}`, asset)
        if (asset?.package_name) byPackage.set(String(asset.package_name), asset)
      }
      const installedView = []
      for (const item of installed) {
        const byId = item.id !== null && item.id !== undefined ? byKey.get(`${item.kind}:${item.id}`) : undefined
        const asset = byId || (item.kind === 'plugin' && item.packageName ? byPackage.get(item.packageName) : undefined)
        if (!asset) continue
        installedView.push({
          kind: item.kind,
          id: asset.id ?? item.id,
          slug: asset.slug || item.slug || '',
          name: asset.name || item.name || '',
          version: item.version,
          packageName: asset.package_name || item.packageName || '',
          latestVersion: asset.latest_version || '',
        })
      }
      const found = []
      const seen = new Set()
      for (const item of installed) {
        let asset = item.id !== null && item.id !== undefined ? byKey.get(`${item.kind}:${item.id}`) : undefined
        if (!asset && item.kind === 'plugin' && item.packageName) asset = byPackage.get(item.packageName)
        if (!asset || !asset.latest_version) continue
        const key = `${asset.kind}:${asset.id}`
        if (seen.has(key)) continue
        if (!item.version || compareVersions(asset.latest_version, item.version) <= 0) continue
        seen.add(key)
        found.push({
          kind: asset.kind,
          id: asset.id,
          slug: asset.slug || item.slug || '',
          name: asset.name || item.name || asset.slug || '',
          packageName: asset.package_name || item.packageName || '',
          installedVersion: item.version,
          latestVersion: asset.latest_version,
          summary: asset.summary || '',
        })
      }
      found.sort((left, right) => left.name.localeCompare(right.name))
      const data = { ok: true, count: found.length, updates: found, installed: installedView, checkedAt: new Date().toISOString() }
      updatesCache = { at: Date.now(), data }
      return data
    } catch (error) {
      return {
        ok: false,
        count: 0,
        updates: [],
        installed: [],
        error: { code: error?.code || 'HUB_ERROR', message: error?.message || String(error) },
        checkedAt: new Date().toISOString(),
      }
    }
  }

  async function downloadToPath(kind, id, version, cwdInput, savePath) {
    const file = await authed((client) => client.download(kind, id, version))
    const cwd = resolve(cwdInput)
    const target = resolve(cwd, savePath || file.filename)
    if (target !== cwd && !target.startsWith(`${cwd}${sep}`)) {
      throw new HubError({ code: 'PATH_OUTSIDE_WORKSPACE', message: '保存路径必须位于当前会话工作目录内' })
    }
    await mkdir(dirname(target), { recursive: true })
    await writeFile(target, file.buffer)
    return { path: target, bytes: file.buffer.length, filename: file.filename }
  }

  function uploadFields(request) {
    const fields = {}
    for (const key of ['slug', 'name', 'summary', 'description', 'category', 'language', 'tags', 'version', 'visibility']) {
      const value = request[key]
      if (value !== undefined && value !== null && String(value).trim() !== '') fields[key] = String(value)
    }
    return fields
  }

  const service = {
    status,
    meta: async () => authed((client) => client.meta()),
    list: async (params = {}) => normalizeAssetList(await authed((client) => client.list(params))),
    lookup: async (kind, owner, slug) => authed((client) => client.lookup(kind, owner, slug)),
    get: async (kind, id) => authed((client) => client.get(kind, id)),
    versions: async (kind, id) => authed((client) => client.versions(kind, id)),
    manifest: async (kind, id, version) => authed((client) => client.manifest(kind, id, version)),
    files: async (kind, id, version) => authed((client) => client.files(kind, id, version)),
    readFile: async (kind, id, path, version) => authed((client) => client.file(kind, id, path, version)),
    me: async (params = {}) => normalizeAssetList(await authed((client) => client.me(params))),
    admin: async (params = {}) => normalizeAssetList(await authed((client) => client.admin(params))),
    publish: async (request = {}) => {
      const buffer = request.buffer
      if (!buffer || buffer.length === 0) throw new HubError({ code: 'VALIDATION_ERROR', message: '请选择要上传的包文件' })
      const limit = request.kind === 'plugin' ? PLUGIN_MAX_BYTES : ASSET_MAX_BYTES
      if (buffer.length > limit) {
        throw new HubError({
          status: 413,
          code: 'PAYLOAD_TOO_LARGE',
          message: `${request.kind === 'plugin' ? '插件' : '资产'}包体超过 ${Math.round(limit / 1024 / 1024)}MB 上限`,
        })
      }
      return authed((client) =>
        client.publish({
          kind: request.kind,
          fields: uploadFields(request),
          file: { filename: request.filename, buffer },
          ifMatch: request.ifMatch,
        }),
      )
    },
    publishVersion: async (request = {}) => {
      const buffer = request.buffer
      if (!buffer || buffer.length === 0) throw new HubError({ code: 'VALIDATION_ERROR', message: '请选择要上传的包文件' })
      const limit = request.kind === 'plugin' ? PLUGIN_MAX_BYTES : ASSET_MAX_BYTES
      if (buffer.length > limit) {
        throw new HubError({ status: 413, code: 'PAYLOAD_TOO_LARGE', message: '包体超过大小上限' })
      }
      return authed((client) =>
        client.publishVersion({
          kind: request.kind,
          id: request.id,
          version: request.version,
          changelog: request.changelog,
          file: { filename: request.filename, buffer },
          ifMatch: request.ifMatch,
        }),
      )
    },
    replace: async (request = {}) => {
      const buffer = request.buffer
      if (!buffer || buffer.length === 0) throw new HubError({ code: 'VALIDATION_ERROR', message: '请选择要上传的包文件' })
      return authed((client) =>
        client.replace({
          kind: request.kind,
          id: request.id,
          fields: uploadFields(request),
          file: { filename: request.filename, buffer },
          ifMatch: request.ifMatch,
        }),
      )
    },
    updateMeta: async (kind, id, patch, ifMatch) => authed((client) => client.updateMeta(kind, id, patch, ifMatch)),
    remove: async (kind, id, options) => authed((client) => client.remove(kind, id, options)),
    suspend: async (kind, id) => authed((client) => client.suspend(kind, id)),
    restore: async (kind, id) => authed((client) => client.restore(kind, id)),
    download: async (kind, id, version) => authed((client) => client.download(kind, id, version)),
    installStatus: async (params = {}) => {
      let packageName = params.packageName
      if (!packageName && params.kind && params.id !== undefined) {
        try {
          const asset = await authed((client) => client.get(params.kind, params.id))
          packageName = asset?.package_name
        } catch {
          packageName = undefined
        }
      }
      return installer.status({ ...params, packageName })
    },
    install: async (params = {}) => {
      const asset = await authed((client) => client.get(params.kind, params.id))
      return installer.install(asset)
    },
    uninstall: async (params = {}) => installer.uninstall(params),
    updates,
    saveSettings,
    login,
    savePat,
    importEnvToken,
    clearAuth,
    logout: clearAuth,
    async testConnection(overrides = {}) {
      const settings = await resolveSettings({ baseUrl: overrides.baseUrl, insecureTLS: overrides.insecureTLS })
      const meta = await new HubClient({ ...settings, token: '' }).meta()
      let authenticated = false
      if (settings.token) {
        try {
          await new HubClient(settings).me({ pageSize: 1 })
          authenticated = true
        } catch {
          authenticated = false
        }
      }
      return {
        ok: true,
        baseUrl: settings.baseUrl,
        authenticated,
        authMode: settings.token ? 'pat' : 'none',
        loginId: settings.loginId || '',
        tokenSource: settings.tokenSource,
        meta,
      }
    },
  }

  const rpcMethods = {
    status: () => service.status(),
    updates: (params) => service.updates(params),
    meta: () => service.meta(),
    list: (params) => service.list(params),
    lookup: (params) => service.lookup(params?.kind, params?.owner, params?.slug),
    get: (params) => service.get(params?.kind, params?.id),
    versions: (params) => service.versions(params?.kind, params?.id),
    manifest: (params) => service.manifest(params?.kind, params?.id, params?.version),
    files: (params) => service.files(params?.kind, params?.id, params?.version),
    file: (params) => service.readFile(params?.kind, params?.id, params?.path, params?.version),
    me: (params) => service.me(params),
    admin: (params) => service.admin(params),
    updateMeta: (params) => service.updateMeta(params?.kind, params?.id, params?.patch ?? {}, params?.ifMatch),
    remove: (params) => service.remove(params?.kind, params?.id, { hard: Boolean(params?.hard) }),
    suspend: (params) => service.suspend(params?.kind, params?.id),
    restore: (params) => service.restore(params?.kind, params?.id),
    saveSettings: (params) => service.saveSettings(params),
    login: (params) => service.login(params),
    savePat: (params) => service.savePat(params),
    logout: () => service.logout(),
    testConnection: (params) => service.testConnection(params),
    download: async (params) => {
      const file = await service.download(params?.kind, params?.id, params?.version)
      return { filename: file.filename, contentType: file.contentType, size: file.buffer.length }
    },
    installStatus: (params) => service.installStatus(params),
    install: (params) => service.install(params),
    uninstall: (params) => service.uninstall(params),
  }

  async function handleRequest(req, res) {
    let admission
    try {
      admission = ctx.connection.admit(req)
    } catch {
      admission = { rejection: 401 }
    }
    if (admission && admission.rejection) {
      sendJson(res, admission.rejection, { ok: false, error: { code: 'UNAUTHORIZED', message: '需要已登录的 Harness 页面会话' } })
      return
    }

    const url = new URL(req.url || '/', 'http://localhost')
    try {
      if (req.method === 'POST' && url.pathname === `${ROUTE_PREFIX}/rpc`) {
        const raw = await readBody(req, MAX_JSON_BODY)
        let request
        try {
          request = JSON.parse(raw.toString('utf8') || '{}')
        } catch {
          throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: '请求体不是合法 JSON' })
        }
        const method = String(request?.method || '')
        const handler = rpcMethods[method]
        if (!handler) throw new HubError({ status: 404, code: 'UNKNOWN_METHOD', message: `未知操作：${method}` })
        const data = await handler(request?.params ?? {})
        sendJson(res, 200, { ok: true, data })
        return
      }

      if (req.method === 'POST' && url.pathname === `${ROUTE_PREFIX}/upload`) {
        const raw = await readBody(req, MAX_UPLOAD_BODY)
        if (raw.length < 4) throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: '上传请求为空' })
        const metaLength = raw.readUInt32BE(0)
        if (metaLength <= 0 || metaLength > 64 * 1024 || 4 + metaLength > raw.length) {
          throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: '上传元信息不合法' })
        }
        let meta
        try {
          meta = JSON.parse(raw.subarray(4, 4 + metaLength).toString('utf8'))
        } catch {
          throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: '上传元信息不是合法 JSON' })
        }
        const buffer = raw.subarray(4 + metaLength)
        const base = {
          kind: meta?.kind,
          filename: asString(meta?.filename, 'upload.bin'),
          buffer,
          version: meta?.version,
          changelog: meta?.changelog,
          ifMatch: meta?.ifMatch,
        }
        let data
        if (meta?.method === 'publish') {
          data = await service.publish({ ...base, slug: meta.slug, name: meta.name, summary: meta.summary, description: meta.description, category: meta.category, language: meta.language, tags: meta.tags, visibility: meta.visibility })
        } else if (meta?.method === 'publishVersion') {
          data = await service.publishVersion({ ...base, id: meta.id })
        } else if (meta?.method === 'replace') {
          data = await service.replace({ ...base, id: meta.id, slug: meta.slug, name: meta.name, summary: meta.summary, description: meta.description, category: meta.category, language: meta.language, tags: meta.tags, visibility: meta.visibility })
        } else {
          throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: `未知上传操作：${meta?.method}` })
        }
        sendJson(res, 200, { ok: true, data })
        return
      }

      if (req.method === 'GET' && url.pathname === `${ROUTE_PREFIX}/download`) {
        const kind = url.searchParams.get('kind') || ''
        const id = url.searchParams.get('id') || ''
        const version = url.searchParams.get('version') || undefined
        if (!kind || !id) throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: '缺少 kind 或 id' })
        const file = await service.download(kind, id, version)
        res.writeHead(200, {
          'content-type': file.contentType || 'application/octet-stream',
          'content-length': file.buffer.length,
          'content-disposition': filenameHeader(file.filename),
          'cache-control': 'no-store',
        })
        res.end(file.buffer)
        return
      }

      sendJson(res, 404, { ok: false, error: { code: 'NOT_FOUND', message: '未知的运维工坊仓库接口' } })
    } catch (error) {
      sendError(res, error)
    }
  }

  ctx.effect(
    () =>
      ctx.webServer.register({
        kind: 'prefix',
        path: ROUTE_PREFIX,
        handler: handleRequest,
      }),
    'asset-hub: HTTP routes',
  )

  ctx.inject(['tools'], (scope) => {
    const tool = {
      name: 'asset_hub',
      description:
        'Access the configured Ops workshop repository (MCP / Skill / Harness plugin registry). Browse public assets, check which installed assets have updates, inspect versions and files, publish a package file, update metadata, delete an asset, download a package into the workspace, or install/uninstall an asset into the current DSH profile. Uses a saved PAT; run asset_hub_auth first if status reports no credential. Use id from a list/get result for follow-up actions.',
      parameters: {
        type: 'object',
        properties: {
          action: {
            type: 'string',
            enum: ['status', 'updates', 'meta', 'list', 'get', 'versions', 'files', 'read_file', 'me', 'publish', 'publish_version', 'update', 'delete', 'download', 'install_status', 'install', 'uninstall'],
            description: 'Operation to perform.',
          },
          kind: { type: 'string', enum: ['mcp', 'skill', 'plugin'], description: 'Asset kind.' },
          id: { type: 'number', description: 'Asset id from list/get.' },
          q: { type: 'string', description: 'Keyword for list.' },
          category: { type: 'string' },
          language: { type: 'string' },
          owner: { type: 'string' },
          sort: { type: 'string', enum: ['recent', 'popular', 'name'] },
          page: { type: 'number' },
          page_size: { type: 'number' },
          version: { type: 'string' },
          path: { type: 'string', description: 'File path inside the package tree (read_file).' },
          file_path: { type: 'string', description: 'Local package path for publish or publish_version.' },
          save_path: { type: 'string', description: 'For download: destination relative to the session working directory.' },
          slug: { type: 'string' },
          name: { type: 'string' },
          summary: { type: 'string' },
          description: { type: 'string' },
          tags: { type: 'string', description: 'Comma separated tags.' },
          visibility: { type: 'string', enum: ['public', 'unlisted', 'private'] },
          changelog: { type: 'string' },
          patch: { type: 'object', description: 'For update: metadata fields to change.', additionalProperties: true },
          hard: { type: 'boolean', description: 'For delete: permanent removal (admin only).' },
          force: { type: 'boolean', description: 'For updates: bypass the 60s cache.' },
        },
        required: ['action'],
        additionalProperties: false,
      },
      output: {
        schema: { type: 'object', additionalProperties: true },
        render(_args, value) {
          const text = typeof value === 'string' ? value : JSON.stringify(value, null, 2)
          return [{ type: 'text', text: text.length > 20000 ? `${text.slice(0, 20000)}\n… (truncated)` : text }]
        },
      },
      async execute(args, exec) {
        const action = String(args?.action || '')
        if (action === 'status') return service.status()
        if (action === 'updates') return service.updates({ force: Boolean(args?.force) })
        if (action === 'meta') return service.meta()
        if (action === 'list') {
          const result = await service.list({
            kinds: args?.kind ? [args.kind] : undefined,
            q: args?.q,
            category: args?.category,
            language: args?.language,
            owner: args?.owner,
            sort: args?.sort,
            page: args?.page ?? 1,
            pageSize: args?.page_size ?? 20,
          })
          return {
            total: result.total,
            page: result.page,
            hasMore: result.hasMore,
            items: result.items.slice(0, 40).map(compactAsset),
          }
        }
        if (action === 'get') return compactAsset(await service.get(args?.kind, args?.id))
        if (action === 'versions') return service.versions(args?.kind, args?.id)
        if (action === 'files') return service.files(args?.kind, args?.id, args?.version)
        if (action === 'read_file') return service.readFile(args?.kind, args?.id, args?.path, args?.version)
        if (action === 'me') {
          const result = await service.me({ page: args?.page ?? 1, pageSize: args?.page_size ?? 20 })
          return { total: result.total, items: result.items.slice(0, 40).map(compactAsset) }
        }
        if (action === 'publish') {
          const cwd = await sessionDirectory(exec)
          const buffer = await readWorkspaceFile(cwd, args?.file_path)
          return compactAsset(
            await service.publish({
              kind: args?.kind,
              buffer,
              filename: String(args?.file_path || 'upload.bin').split('/').pop(),
              slug: args?.slug,
              name: args?.name,
              summary: args?.summary,
              description: args?.description,
              category: args?.category,
              language: args?.language,
              tags: args?.tags,
              version: args?.version,
              visibility: args?.visibility,
            }),
          )
        }
        if (action === 'publish_version') {
          const cwd = await sessionDirectory(exec)
          const buffer = await readWorkspaceFile(cwd, args?.file_path)
          return compactAsset(
            await service.publishVersion({
              kind: args?.kind,
              id: args?.id,
              version: args?.version,
              changelog: args?.changelog,
              buffer,
              filename: String(args?.file_path || 'upload.bin').split('/').pop(),
            }),
          )
        }
        if (action === 'update') return compactAsset(await service.updateMeta(args?.kind, args?.id, args?.patch ?? {}))
        if (action === 'delete') {
          await service.remove(args?.kind, args?.id, { hard: Boolean(args?.hard) })
          return { deleted: true, kind: args?.kind, id: args?.id, hard: Boolean(args?.hard) }
        }
        if (action === 'download') {
          const cwd = await sessionDirectory(exec)
          return downloadToPath(args?.kind, args?.id, args?.version, cwd, args?.save_path)
        }
        if (action === 'install_status') return service.installStatus(args)
        if (action === 'install') return service.install(args)
        if (action === 'uninstall') return service.uninstall(args)
        throw new HubError({ code: 'VALIDATION_ERROR', message: `未知操作：${action}` })
      },
    }

    const authTool = {
      name: 'asset_hub_auth',
      description:
        '管理运维工坊仓库的 PAT（唯一长期凭据）。action=status 查状态；action=set 从 token_file（推荐）或 token 写入 PAT 并校验；action=login 用 email + password_file 登录并创建含 assets:write 的 PAT（写权限隐含读，密码不保存）；action=import_env 导入 ASSET_HUB_PAT；action=clear 清除。',
      parameters: {
        type: 'object',
        properties: {
          action: {
            type: 'string',
            enum: ['status', 'set', 'login', 'import_env', 'clear'],
            description: '要执行的动作，默认 status。',
          },
          token: { type: 'string', description: 'PAT 明文（ops_pat_…）。会进入会话日志；优先用 token_file。' },
          token_file: { type: 'string', description: '存放 PAT 的文件路径（chmod 600），读取后 trim。' },
          email: { type: 'string', description: '登录账号：邮箱/用户名/手机号。' },
          password_file: { type: 'string', description: '存放密码的文件路径；登录后请删除，密码不会被保存。' },
          expires_in: {
            type: 'string',
            enum: ['7d', '30d', '90d', '180d'],
            description: '新建 PAT 的有效期，默认 180d；写权限最长 180d。',
          },
          token_name: { type: 'string', description: 'PAT 名称，默认 dsh-asset-hub。' },
          login_id: { type: 'string', description: '可选，记录到凭据里便于识别账号。' },
        },
        required: ['action'],
        additionalProperties: false,
      },
      output: {
        schema: { type: 'object', additionalProperties: true },
        render(_args, value) {
          const text = typeof value === 'string' ? value : JSON.stringify(value, null, 2)
          return [{ type: 'text', text: text.length > 20000 ? `${text.slice(0, 20000)}\n… (truncated)` : text }]
        },
      },
      async execute(args, exec) {
        const action = String(args?.action || 'status')
        if (action === 'status') return service.status()
        if (action === 'clear') return service.clearAuth()
        if (action === 'set') {
          let token = String(args?.token || '').trim()
          let source = 'inline'
          if (!token && args?.token_file) {
            const cwd = await sessionDirectory(exec)
            token = (await readSecretText(cwd, args.token_file, '令牌文件')).trim()
            source = 'file'
          }
          if (!token) {
            throw new HubError({
              status: 400,
              code: 'VALIDATION_ERROR',
              message: 'action=set 需要 token 或 token_file',
              details: { hint: '推荐 token_file（chmod 600），避免 PAT 明文进入会话日志。' },
            })
          }
          const result = await service.savePat({ token, loginId: args?.login_id })
          result.note =
            source === 'file'
              ? 'PAT 已从文件读取并保存到当前 profile 的凭据记录。'
              : 'PAT 已保存。明文可能已进入会话日志，建议轮换。'
          return result
        }
        if (action === 'login') {
          const email = String(args?.email || '').trim()
          if (!email) throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: 'action=login 需要 email（邮箱/用户名/手机号）' })
          if (!args?.password_file) {
            throw new HubError({
              status: 400,
              code: 'VALIDATION_ERROR',
              message: 'action=login 需要 password_file',
              details: { hint: '不要把密码直接放进工具参数：写进 chmod 600 的临时文件，登录后删除。' },
            })
          }
          const cwd = await sessionDirectory(exec)
          const password = (await readSecretText(cwd, args.password_file, '密码文件')).replace(/\r?\n$/, '')
          if (!password) throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: 'password_file 是空文件' })
          const result = await service.login({
            email,
            password,
            expiresIn: args?.expires_in || '180d',
            tokenName: args?.token_name || DEFAULT_TOKEN_NAME,
          })
          result.note = `${result.note || ''}建议删除 password_file。`
          return result
        }
        if (action === 'import_env') {
          const result = await service.importEnvToken({ loginId: args?.login_id })
          result.note = `已从环境变量 ${TOKEN_ENV} 读取并保存 PAT。`
          return result
        }
        throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: `未知 action：${action}` })
      },
    }

    scope.effect(() => scope.tools.register(tool), 'asset-hub: agent tool')
    scope.effect(() => scope.tools.register(authTool), 'asset-hub: auth tool')
  })

  async function sessionDirectory(exec) {
    const service = workingDirectory()
    if (!service || !exec?.agent) return process.cwd()
    try {
      return await service.ensure(exec.agent)
    } catch {
      return process.cwd()
    }
  }

  async function readSecretText(cwd, pathInput, label = '文件') {
    let value = String(pathInput ?? '').trim()
    if (!value) throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: `${label}路径不能为空` })
    if (value === '~') value = homedir()
    else if (value.startsWith('~/')) value = join(homedir(), value.slice(2))
    const target = isAbsolute(value) ? value : resolve(cwd || process.cwd(), value)
    try {
      return await readFile(target, 'utf8')
    } catch (error) {
      throw new HubError({ code: 'FILE_NOT_FOUND', message: `无法读取${label}：${target}（${error?.code || error?.message || String(error)}）` })
    }
  }

  async function readWorkspaceFile(cwd, pathInput, label = '包文件') {
    if (!pathInput) throw new HubError({ status: 400, code: 'VALIDATION_ERROR', message: `缺少 ${label}路径` })
    const cwdResolved = resolve(cwd)
    const target = resolve(cwdResolved, String(pathInput))
    if (target !== cwdResolved && !target.startsWith(`${cwdResolved}${sep}`)) {
      throw new HubError({ code: 'PATH_OUTSIDE_WORKSPACE', message: `${label}必须位于当前会话工作目录内` })
    }
    try {
      return await readFile(target)
    } catch (error) {
      throw new HubError({ code: 'FILE_NOT_FOUND', message: `无法读取${label}：${error?.message || String(error)}` })
    }
  }

  function compactAsset(asset) {
    if (!asset || typeof asset !== 'object') return asset
    const copy = { ...asset }
    if (typeof copy.description === 'string' && copy.description.length > 2000) {
      copy.description = `${copy.description.slice(0, 2000)}…`
    }
    delete copy.readme
    return copy
  }

}
