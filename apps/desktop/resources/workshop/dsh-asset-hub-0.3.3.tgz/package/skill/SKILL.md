---
name: ops-workshop-publish
description: Package and publish MCP servers, Skills, and Harness plugins to the Ops Workshop Repository (运维工坊仓库), then verify, install, or update them.
---

# Publishing to the Ops workshop repository

Use this skill when the user asks to publish, upload, update, verify, or install an MCP server, a Skill, or a Harness plugin in the Ops workshop repository.

The `asset_hub` tool is the preferred interface. It uses a PAT stored by the `dsh-asset-hub` plugin; the PAT is either minted from an account login or pasted directly, and it is the only long-term credential. Never ask the user to paste a password into the conversation. If `asset_hub` reports `AUTH_REQUIRED`, run `asset_hub_auth`: `action=status` to inspect, `action=login` with `email` + `password_file` to mint a PAT, or `action=set` with `token_file` to paste one. If the tool is missing, the `dsh-asset-hub` plugin is not installed in this profile: tell the user, or install that plugin first if the user asked for it.

## 1. Decide the kind

| Kind | Root manifest | Archive | `package_name` |
|---|---|---|---|
| `skill` | `SKILL.md` | `.zip` | empty |
| `mcp` | `mcp.json` | `.zip` | empty |
| `plugin` | `package.json` + `cordis.patch.yml` + the `main` entry | `.tgz` | from `package.json` `name` |

One package has **one** root manifest. A nested `**/SKILL.md`, `**/mcp.json`, or `**/package.json` is not accepted.

## 2. Package

### Skill

```bash
mkdir -p /tmp/my-skill
cat > /tmp/my-skill/SKILL.md <<'EOF'
---
name: my-skill
description: One sentence saying when this skill applies.
---

# My skill

Instructions...
EOF
cd /tmp/my-skill && zip -r ../my-skill-1.0.0.zip .
```

Rules: `SKILL.md` at the archive root; frontmatter `name` is kebab-case and matches the directory you would install it into; `description` is required; optional `when_to_use`, `disable-model-invocation`, `user-invocable`.

### MCP

```bash
mkdir -p /tmp/my-mcp
cat > /tmp/my-mcp/mcp.json <<'EOF'
{
  "serverName": "my-server",
  "transport": "streamable-http",
  "url": "https://mcp.example.com/mcp"
}
EOF
cd /tmp/my-mcp && zip -r ../my-mcp-1.0.0.zip .
```

For a local process use `"transport": "stdio"`, `"command": "npx"`, `"args": ["-y", "pkg"]`. `serverName` matches `[A-Za-z0-9_-]{1,32}`. `env` and `headers` are written into the installed config, so do not put secrets in an archive you publish publicly.

A standard `{"mcpServers": {"<name>": {...}}}` file is also accepted.

### Plugin

`package.json` must declare an exact SemVer `version`, a real `main`, `dsh.bundle.patch`, and `engines.dsh`:

```json
{
  "name": "my-plugin",
  "version": "1.0.0",
  "private": true,
  "type": "module",
  "main": "index.js",
  "engines": { "dsh": ">=0.2.0 <0.3.0" },
  "dsh": { "bundle": { "patch": "./cordis.patch.yml" } }
}
```

`cordis.patch.yml` must exist (an insert list), and every file named by `main`/`files` must exist. Build with:

```bash
cd my-plugin
npm pack
tar -tzf my-plugin-1.0.0.tgz    # expect package/package.json, package/cordis.patch.yml, package/index.js
```

Do not hand-build the tarball with a different root layout.

## 3. Preflight

- Version is exact SemVer and has never been published for this asset.
- Slug is kebab-case and unique under the same owner and kind.
- Plugin package name (`package_name`) is globally unique; a taken name returns `409 PACKAGE_NAME_TAKEN`.
- Limits: plugin ≤20MB, other kinds ≤50MB; ≤2000 files; ≤50MB per file; ≤200MB unpacked.
- No secrets, credentials, `node_modules`, or `dist` leftovers inside the archive.
- The archive root is the manifest file, not a wrapper directory.

## 4. Publish with the tool

```
asset_hub action=publish kind=skill file_path=/abs/or/relative/file.zip \
  slug=my-skill version=1.0.0 name="My skill" summary="..." \
  category=ops tags=ops,automation visibility=public
```

- `file_path` is resolved inside the session working directory when the tool runs; prefer a path under it.
- `version` is required for `skill` and `mcp`; `plugin` reads it from `package.json`.
- `name`, `summary`, `description`, `category`, `tags`, `visibility` are optional and fall back to the package manifest.
- The result contains `id`, `package_name`, `latest_version`, and `install`. Keep `id`.

## 5. Verify

```
asset_hub action=get kind=plugin id=<id>
asset_hub action=versions kind=plugin id=<id>
asset_hub action=files kind=plugin id=<id>
asset_hub action=read_file kind=plugin id=<id> path=package.json
```

Check `latest_version` and the file tree. For a plugin, also confirm `host_compat` is the intended range.

## 6. Update

- **Metadata only**: `asset_hub action=update kind=skill id=<id> patch={"summary":"..."}`
- **New version**: bump `version` in the package first, then:

```
asset_hub action=publish_version kind=plugin id=<id> version=1.1.0 \
  changelog="..." file_path=dist/my-plugin-1.1.0.tgz
```

`VERSION_EXISTS` means that version is already published; publish a new version instead of reusing it.

## 7. Install or test the published asset

```
asset_hub action=install_status kind=plugin id=<id>
asset_hub action=install kind=plugin id=<id>
asset_hub action=uninstall kind=plugin id=<id>
```

- `plugin`: installs the tarball into the current DSH profile and activates its bundle.
- `skill`: writes the package to `~/.dsh/asset-hub/skills/` and registers it; it appears in the next turn's skill catalog.
- `mcp`: generates a config-only bundle for `@deepseek-ai/dsh-mcp-client`; tools appear as `mcp__<serverName>__<tool>` once the server connects.

`asset_hub action=updates` returns the installed assets whose repository `latest_version` is newer, with `installedVersion` and `latestVersion`; use it when the user asks what can be updated.

`install` is also the upgrade action: when a different version is already installed, it uninstalls the old version and installs the new one. Updating the Ops workshop repository plugin itself returns `updating: true`; the page disconnects briefly, so tell the user to refresh when it finishes. In the Web page the same action appears as “更新到 vX”.

Installing runs package code. Only install sources the user trusts.

## 8. Errors

| Code | Meaning | Fix |
|---|---|---|
| `MANIFEST_INVALID` | Skill/MCP root manifest missing or malformed | Put `SKILL.md` / `mcp.json` at the archive root; fix frontmatter or `serverName` |
| `BUNDLE_INVALID` | Plugin three-piece set, `main`, SemVer, or `engines.dsh` is wrong | Fix `package.json`, `cordis.patch.yml`, and the entry file; `npm pack` again |
| `VERSION_EXISTS` | Version already published | Bump the version |
| `PACKAGE_NAME_TAKEN` | Another plugin owns the npm name | Rename `package.json` `name` |
| `SLUG_TAKEN` | Slug used by the same owner and kind | Choose another slug |
| `ARCHIVE_UNSAFE` | Path traversal, bomb, or a bad compression ratio | Rebuild the archive from a clean directory |
| `PAYLOAD_TOO_LARGE` | Over the size limit | Remove large files; plugin limit is 20MB |
| `FORBIDDEN` / `NOT_OWNER` | The account does not own the asset | Use the owning account |
| `AUTH_REQUIRED` | No PAT, or the PAT is invalid/expired | Run `asset_hub_auth action=status`; then `action=login` (email + password_file) or `action=set` (token_file) |
| `SCOPE_REQUIRED` | The PAT lacks `assets:write` | Mint a new PAT with `asset_hub_auth action=login`, which requests `assets:write` (write implies `assets:read`) |

## 9. Bootstrap

If another agent cannot publish, install the `dsh-asset-hub` plugin (the published plugin provides the `asset_hub` and `asset_hub_auth` tools plus this skill). Account login only mints a PAT: the plugin exchanges the password for a short-lived access token, creates an `assets:write` PAT (read is implied), and stores only the PAT. A PAT from the repository's `/my-tokens` page can also be saved directly. There is no JWT or refresh flow. Do not invent a token flow; the plugin handles authentication.
