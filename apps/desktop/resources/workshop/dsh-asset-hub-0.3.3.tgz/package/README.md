# 工坊插件（dsh-asset-hub）

对接 **25.75.3.1 能力资产中心** 的 Harness 插件：在 Web 界面里浏览、搜索、发布、更新、下载和安装 **MCP / Skill / 插件（plugin）** 三类资产，资源与 25.75.3.1 的资源中心同步。

- 侧边栏「工坊插件」入口，主面板即 25.75.3.1 能力资产中心的资产页面
- 全部仓库请求都在 **Host** 侧发起，页面只访问同源的 `/assets-hub`，因此不受 CORS 限制，也支持自签证书
- 同一套操作同时暴露给 Agent，作为 `asset_hub` 工具；授权由 `asset_hub_auth` 管理，长期凭据只有 PAT

## 内置发布技能

插件自带 `ops-workshop-publish` 技能（`skill/SKILL.md`），安装插件后会自动出现在技能目录中。Agent 因此知道：

- 三种包分别怎么打（Skill `.zip`、MCP `.zip`、插件 `.tgz`）
- 发布前检查什么（根清单、版本、`engines.dsh`、大小）
- 用 `asset_hub` 工具的哪些 action 发布、验证、发新版本、安装
- 常见错误（`VERSION_EXISTS`、`PACKAGE_NAME_TAKEN`、`BUNDLE_INVALID` 等）怎么处理

这就解决了“先有插件才能发布，但不会发布”的循环：装上插件，发布知识也跟着到位。技能随插件内置并自动注册，不再单独发布为独立 skill 资产。

## 新机器首次安装（还没有工坊插件）

私有仓库使用自签证书，pnpm 直接从 `https://25.75.3.1/npm/` 安装会因证书失败。最稳的是**先下载 tgz，再从本地文件安装**：

1. 下载最新包（浏览器会提示自签证书，继续即可）：
   - <https://25.75.3.1/api/v1/assets/plugin/1/download>
   - 或 `curl -kL -o dsh-asset-hub.tgz https://25.75.3.1/api/v1/assets/plugin/1/download`
2. 安装：
   - **界面**：DSH → 设置 → 插件 → 添加插件 → 输入 tgz 的绝对路径 → 安装（立即生效）。
   - **CLI**：`"/Applications/DeepSeek Harness.app/Contents/Resources/runtime/cli/bin/dsh" plugin --profile desktop add /绝对路径/dsh-asset-hub.tgz`，然后重启 DSH。
3. 安装后侧栏出现「运维工坊仓库」，技能目录出现 `ops-workshop-publish`。

如果团队要直接走 npm 源或市场索引，需要先让 Node/pnpm 信任仓库证书（`NODE_EXTRA_CA_CERTS` 指向 CA 文件，或把证书加入系统钥匙串），再把 `https://25.75.3.1/api/v1/market/dsh/index.json` 配到 `plugin-market.indexes`。自签证书未受信任时，pnpm 会报 `SELF_SIGNED_CERT_IN_CHAIN`。

## 使用

1. 打开 Harness Web，点击左侧栏的箱子图标「运维工坊仓库」。
2. 首次使用点「设置」：
   - **服务地址**：例如 `https://25.75.3.1`
   - 自签证书环境打开「忽略 TLS 证书校验」
   - 可先点「测试连接」确认地址可达
3. 获取凭据只有两条路，最终**都只保存 PAT**：
   - **账号密码换 PAT**：填写邮箱/手机/用户名 + 密码，插件调用 `/api/auth/login` 换一次性 access token，再用它调用 `POST /api/v1/tokens` 创建含 `assets:write` 的 PAT（写权限隐含 `assets:read`），随后丢弃 access token。**密码和 JWT 都不会落盘。**
   - **直接填写 PAT**：切换到「直接填写 PAT」，粘贴在运维工坊用户名下拉「访问令牌」页面（`https://25.75.3.1/my-tokens`）创建的 PAT。插件会先调用 `/api/v1/me/assets` 校验，通过后才保存。
4. PAT 是唯一的长期凭据（记录键 `asset-hub/settings`，`kind: grant`），保存 `loginId`、`scopes`、`patId` 和有效期。不再保存 access / refresh token，也没有自动续期。
   - PAT 按 scope 最小授权：`assets:read` 只读，`assets:write` 读写（隐含读）；登录只申请 `assets:write`，不再重复申请 `assets:read`。
   - 写权限最长 180 天；`never` 只适用于只读 scope，所以账号登录不提供永久 PAT。
5. PAT 过期或被撤销后，页面提示「PAT 无效或已过期」；重新用账号登录签发，或粘贴一个新的 PAT 即可。旧版 `0.1.x` 保存的账号会话（JWT）会被识别为 `legacySession`，不会继续使用；重新登录或填入 PAT 后自动覆盖。

### 更新提示

- 侧栏「工坊插件」图标会显示红色数字，表示本机已安装资产中可更新的数量；没有更新时不显示。
- 打开插件后，页面顶部会出现更新横幅，列出可更新资产及 `已安装版本 → 最新版本`；资产卡片和详情页也会标记「可更新」。
- 资产卡片同时显示「已安装」，工具栏显示「已安装 N」，因此能直接区分已安装和未安装的资产。
- 数据来自本机安装记录（插件 bundle 与 `~/.dsh/asset-hub/installs.json`）与仓库 `latest_version` 的比对；每 5 分钟自动刷新，窗口重新聚焦/恢复可见时立即检查，安装/更新/发布后也会立即刷新。
- Agent 也可以调用 `asset_hub action=updates` 获取同一份列表。

### 更新已安装的资产

详情页会在已安装版本落后时显示「更新到 vX」。点击并确认后：

- **插件**：先卸载旧 bundle，再安装新 tgz；更新运维工坊仓库自身时会先卸载当前版本，页面短暂断开，完成后刷新即可。
- **技能**：用新版本覆盖本地技能目录并重新注册。
- **MCP**：重建 MCP 连接配置。

这个能力从 `0.1.5` 起提供。更早的 0.1.2 / 0.1.4 需要先用本地 tgz 手动更到 0.1.5 一次，之后就能在页面里直接点更新。

### 能做什么

| 操作 | 说明 |
|------|------|
| 浏览 / 搜索 | 类型、关键词、分类、排序、分页；「我的资产」包含 unlisted / private / suspended |
| 详情 | 简介、标签、元数据、安装提示、版本列表、包内文件树与单文件预览、原生清单 |
| 下载 | 整包下载，或下载指定历史版本 |
| 发布 | 上传 `.zip`（skill / mcp）或 `.tgz`（plugin），填写 slug / 名称 / 简介 / 分类 / 标签 / 可见性 |
| 发新版本 | 在详情页直接上传新包 |
| 编辑元数据 | 名称、简介、描述、分类、语言、标签、可见性 |
| 删除 | 软删除（从列表、市场索引、packument 立即消失） |

发布/更新/删除需要 PAT；未配置或 PAT 失效时页面会提示并引导到设置。浏览、搜索和下载公开资产不需要 PAT。

## 一键安装到 DSH

详情页右侧有「安装到 DSH」面板，按资产类型执行：

| 类型 | 安装动作 | 安装后 |
|------|----------|--------|
| 插件 | 下载 `.tgz` 后交给当前 profile 的插件管理器，以**本地包**安装（不需要 pnpm 访问自签证书仓库），并启用 bundle | 出现在插件列表，可能需要刷新或重启 |
| 技能 | 通过资产的文件接口还原到 `~/.dsh/asset-hub/skills/<slug>-<id>/`，并注册到 `skill` 目录 | 下一轮对话即可被模型加载，资源目录随技能保留 |
| MCP | 读取包内 `mcp.json`，生成一个只包含 `@deepseek-ai/dsh-mcp-client` 配置的本地 bundle 并安装 | 工具以 `mcp__<serverName>__<tool>` 出现，资源工具同时可用 |

安装记录保存在 `~/.dsh/asset-hub/installs.json`；面板会显示「已安装」并提供「卸载」。卸载插件/ MCP 会从 profile 移除对应 bundle，卸载技能会注销并删除目录。

安装 MCP 时 `mcp.json` 支持两种写法：直接的客户端配置（`serverName` + `transport` + `url`/`command`），或标准 `{ "mcpServers": { "<name>": {...} } }`。`stdio` 需要 `command`，`streamable-http` 需要 `url`；`env`/`headers` 会原样写入配置，敏感值请自行评估。

## DSH 的 Skill 与 MCP

两者都能用：

- **Skill**：DSH 有 `skill` 注册表（`ctx.skills`）和 `skill` 工具。技能是目录里的 `SKILL.md`，本插件安装后通过 `ctx.skills.register()` 注册为运行时技能，因此不依赖 filesystem provider 是否启用；下一轮对话的可用技能列表会立即更新。DSH 自带的 filesystem provider 还会扫描 `$DSH_HOME/skills`、项目 `.dsh/skills`、`.agents/skills` 等目录。
- **MCP**：DSH 通过 `@deepseek-ai/dsh-mcp-client` 连接 MCP 服务器，一个条目对应一个服务器；工具名固定为 `mcp__<serverName>__<rawName>`，并共享 `mcpResources` 的资源读取工具。默认不连接任何服务器，本插件把 `mcp.json` 变成一条可安装的配置。

### 包格式（服务端会强校验）

- `skill`：`.zip`，根目录必须有 `SKILL.md`，frontmatter 的 `name` 必须是 kebab-case
- `mcp`：`.zip`，根目录必须有 `mcp.json`
- `plugin`：`.tgz`，必须包含 `package.json` + `cordis.patch.yml` + 入口文件，`package.json` 带 `dsh.bundle` 且版本为精确 SemVer
- 大小上限：plugin 20MB，其余 50MB

服务端错误码（`ASSET_NOT_FOUND`、`VERSION_EXISTS`、`PACKAGE_NAME_TAKEN`、`BUNDLE_INVALID` 等）会原样展示在页面提示里。

## Agent 工具

`asset_hub` 工具使用同一套 Host 服务，`action` 支持：

`status` · `updates` · `meta` · `list` · `get` · `versions` · `files` · `read_file` · `me` · `publish` · `publish_version` · `update` · `delete` · `download`

`asset_hub_auth` 负责管理唯一的长期凭据 PAT：

| action | 用途 |
|--------|------|
| `status` | 查看地址、PAT 末尾、账号、scopes、有效期、仓库连通性 |
| `set` | 用 `token_file`（推荐）或 `token` 写入 PAT 并校验 |
| `login` | 用 `email` + `password_file` 登录，创建并保存含 `assets:write` 的 PAT（写权限隐含读） |
| `import_env` | 从环境变量 `ASSET_HUB_PAT` 导入 |
| `clear` | 清除保存的 PAT |

示例：让 Agent「列出最近更新的 skill」「把 workspace 里的 k8s-triage.zip 发布为 skill」「下载 plugin 12 的最新包」。发布/下载只允许访问当前会话工作目录内的文件。

登录和 PAT 写入都走工具/设置页，不要把密码或 PAT 直接贴进对话；`token` 参数只作兜底，明文可能进入会话日志。

## 配置

`cordis.patch.yml` 只提供默认服务地址：

```yaml
- insert:
    - id: asset-hub
      name: dsh-asset-hub
      config:
        baseUrl: https://25.75.3.1
```

可选配置项：

| 键 | 默认 | 说明 |
|----|------|------|
| `baseUrl` | `https://25.75.3.1` | 运维工坊仓库地址；界面里保存的值优先 |
| `insecureTLS` | https + IP 主机时自动开启 | 忽略自签证书校验 |
| `token` | 空 | 可选的高级兜底：必须是 `ops_pat_` 开头的 PAT；JWT 会被忽略。正常使用界面登录/设置页即可 |
| `requestTimeoutMs` | `30000` | 普通请求超时 |

环境变量兜底：`ASSET_HUB_BASE`、`ASSET_HUB_PAT`（不常用；设置页保存的 PAT 优先）。

## 打包与发布这个插件

```bash
cd assets-hub
npm pack
# 生成 dsh-asset-hub-0.1.0.tgz
```

然后在「运维工坊仓库」页面点「发布资产」→ 类型选「插件」→ 选择这个 `.tgz`，填好 slug（`dsh-asset-hub`）、名称、简介后发布。后续版本先在 `package.json` 里递增 `version`，再 `npm pack`，用详情页的「发新版本」上传。

注意：服务端要求插件包的 `package.json` 声明可解析的 `engines.dsh`（本包已声明 `>=0.2.0 <0.3.0`），并包含 `cordis.patch.yml` 与入口文件；重复的 `package_name` 或版本会被拒绝。

## 安装 / 卸载

```bash
# 由 Harness 的插件管理器安装（当前 profile）
# 目标目录：本仓库的 assets-hub/
```

安装后刷新页面即可看到侧边栏入口。卸载用插件管理器的移除操作。

## 依赖

- 本插件不声明 npm 依赖；tgz 包里只有源码（`index.js`、`hub.js`、`installer.js`、`client.js`、`locale`、`skill` 等），没有 `node_modules`。
- Host 端只使用 Node 内置模块；Client 端的 `react` 由 DSH 运行时提供。
- 安装插件不需要额外执行 `npm install` / `pnpm install`。MCP 安装生成的配置引用 DSH 自带的 `@deepseek-ai/dsh-mcp-client`，它也不是本插件的依赖。

## 安全说明

- 账号密码只在登录时经 Host 转发一次，不写入磁盘；Host 用它换一次性 access token，再签出 PAT，随后丢弃 access token。保存的只有 PAT。
- PAT 只保存在 Host 侧凭据记录（`asset-hub/settings`）中，页面只能读到账号、scopes、有效期和令牌末尾 4 位。
- 运行期所有请求都用 `Authorization: Bearer <PAT>`；JWT 只在登录兑换 PAT 的瞬间使用且只在内存，资产读写、发布、安装、下载都不会用 JWT，也没有 refresh 流程。
- `ASSET_HUB_PAT` / `config.token` 必须是 `ops_pat_` 开头；误配成 JWT 会被忽略并在状态里提示，避免把 access token 当 PAT 用。
- `/assets-hub` 路由要求已认证的 Harness 页面会话（`ctx.connection.admit`），未登录请求返回 401。
- 页面不直接访问仓库域名，密码和 PAT 都不会进入浏览器网络请求。
- 「忽略 TLS 证书校验」仅建议用于内网自签证书部署。
- 安装插件或 MCP 会执行包内代码或按配置启动进程/访问网络，请只安装可信来源；技能安装只写入本机目录并注册到 skill 目录。

## 实现结构

| 文件 | 作用 |
|------|------|
| `index.js` | Host 插件：路由、设置、工具、上传/下载转发 |
| `hub.js` | 零依赖的运维工坊仓库 HTTP 客户端（http/https、multipart、错误信封） |
| `installer.js` | 插件包 / 技能 / MCP 的一键安装与卸载 |
| `skill/SKILL.md` | 随插件注册的 `ops-workshop-publish` 发布技能 |
| `client.js` | Web 页面（React.createElement，无 JSX / 无构建步骤） |
| `locale/*.json` | 插件管理器里显示的标题与描述 |
| `icon.svg` | 侧边栏与插件列表图标 |
