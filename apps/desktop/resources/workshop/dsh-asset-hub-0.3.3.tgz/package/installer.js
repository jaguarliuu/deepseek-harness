/**
 * One-click installers for the three asset kinds.
 *
 * plugin: download the hub tarball, then hand the local tarball to the profile's
 *         plugin manager (avoids asking pnpm to fetch from the self-signed hub).
 * skill:  reconstruct the package from the file API into a managed directory and
 *         register it with the Host skill registry.
 * mcp:    read mcp.json, generate a tiny configuration-only bundle around
 *         @deepseek-ai/dsh-mcp-client, and install that bundle.
 *
 * The installer owns $DSH_HOME/asset-hub and a small installs.json ledger so the
 * page can show what it installed and offer uninstall.
 */

import { readFile, writeFile, mkdir, rm, stat } from 'node:fs/promises'
import { join, resolve, sep, dirname } from 'node:path'
import { HubError } from './hub.js'

const MCP_CLIENT = '@deepseek-ai/dsh-mcp-client'
const MCP_PACKAGE_PREFIX = 'dsh-mcp-'
const LEDGER = 'installs.json'
const MAX_SKILL_FILES = 400
const LARGE_FILE = 2 * 1024 * 1024

function sanitizeSegment(value, fallback = 'asset') {
  const text = String(value ?? '')
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, '-')
    .replace(/^[._-]+|[._-]+$/g, '')
    .slice(0, 60)
  return text || fallback
}

function safeServerName(value) {
  const text = String(value ?? '')
    .replace(/[^A-Za-z0-9_-]+/g, '-')
    .replace(/^[-_]+|[-_]+$/g, '')
    .slice(0, 32)
  return text || 'mcp'
}

function safeJoin(base, relative) {
  const root = resolve(base)
  const target = resolve(root, String(relative))
  if (target !== root && !target.startsWith(`${root}${sep}`)) {
    throw new HubError({ code: 'ARCHIVE_UNSAFE', message: `文件路径越界：${relative}` })
  }
  return target
}

function assetVersion(asset) {
  return String(asset?.latest_version || asset?.version || asset?.current_version || '')
}

function assetSlug(asset) {
  return String(asset?.slug || asset?.package_name || asset?.name || `asset-${asset?.id ?? 0}`)
}

function flattenFiles(input) {
  const out = []
  const seen = new Set()
  const walk = (node, prefix) => {
    if (node === undefined || node === null) return
    if (typeof node === 'string') {
      const path = prefix ? `${prefix}/${node}` : node
      if (!seen.has(path)) {
        seen.add(path)
        out.push({ path })
      }
      return
    }
    if (Array.isArray(node)) {
      for (const child of node) walk(child, prefix)
      return
    }
    if (typeof node !== 'object') return
    for (const key of ['files', 'tree', 'entries', 'items', 'children']) {
      if (Array.isArray(node[key])) {
        walk(node[key], prefix)
        return
      }
    }
    const name = node.path || node.name || node.filename
    const isDir = node.type === 'dir' || node.type === 'directory' || node.is_dir === true || Array.isArray(node.children) || Array.isArray(node.items)
    const path = name ? (prefix && !String(name).includes('/') ? `${prefix}/${name}` : String(name)) : prefix
    if (isDir) {
      for (const child of node.children || node.items || []) walk(child, path)
      return
    }
    if (path && !seen.has(path)) {
      seen.add(path)
      out.push({ path, size: node.size ?? node.bytes })
    }
  }
  walk(input, '')
  return out
}

export function parseSkillManifest(text) {
  const normalized = String(text ?? '').replace(/^\uFEFF/, '')
  let data = {}
  let body = normalized
  if (normalized.startsWith('---')) {
    const end = normalized.indexOf('\n---', 3)
    if (end >= 0) {
      for (const line of normalized.slice(3, end).split('\n')) {
        const match = /^([A-Za-z0-9_-]+):\s*(.*)$/.exec(line.trim())
        if (match) data[match[1]] = match[2].trim().replace(/^["']|["']$/g, '')
      }
      body = normalized.slice(end + 4).replace(/^\n+/, '')
    }
  }
  return { data, body }
}

export function normalizeMcpManifest(input, fallbackName) {
  let source = input
  let chosenName = fallbackName
  if (input && typeof input === 'object' && input.mcpServers && typeof input.mcpServers === 'object') {
    const keys = Object.keys(input.mcpServers)
    if (keys.length === 0) throw new HubError({ code: 'MANIFEST_INVALID', message: 'mcp.json 的 mcpServers 为空' })
    const preferred = keys.find((key) => key === fallbackName) || keys[0]
    source = input.mcpServers[preferred]
    chosenName = preferred
  }
  if (!source || typeof source !== 'object') throw new HubError({ code: 'MANIFEST_INVALID', message: 'mcp.json 不是合法的对象' })

  const rawTransport = String(source.transport || source.type || '').toLowerCase()
  const transport =
    rawTransport === 'http' || rawTransport === 'sse' || rawTransport === 'streamable-http' || rawTransport === 'streamablehttp'
      ? 'streamable-http'
      : rawTransport === 'stdio'
        ? 'stdio'
        : source.url
          ? 'streamable-http'
          : 'stdio'

  const config = {
    serverName: safeServerName(source.serverName || chosenName),
    transport,
  }
  for (const key of ['command', 'args', 'env', 'cwd', 'url', 'headers', 'toolCallTimeoutMs', 'maxInstructionBytes', 'reconnect']) {
    if (source[key] !== undefined) config[key] = source[key]
  }
  if (transport === 'streamable-http' && typeof config.url !== 'string') {
    throw new HubError({ code: 'MANIFEST_INVALID', message: 'mcp.json 缺少 url（streamable-http）' })
  }
  if (transport === 'stdio' && typeof config.command !== 'string') {
    throw new HubError({ code: 'MANIFEST_INVALID', message: 'mcp.json 缺少 command（stdio）' })
  }
  if (!Array.isArray(config.args)) delete config.args
  return config
}

export function createInstaller({ ctx, dshHome, withHub }) {
  const root = join(dshHome, 'asset-hub')
  const skillsRoot = join(root, 'skills')
  const mcpRoot = join(root, 'mcp')
  const pluginsRoot = join(root, 'plugins')
  const skillDisposers = new Map()
  const ownedSkillNames = new Set(['ops-workshop-publish'])
  let writeChain = Promise.resolve()
  let opChain = Promise.resolve()
  let selfUpdating = false

  const manager = () => ctx.get('pluginManager')
  const skills = () => ctx.get('skills')

  function serialize(operation) {
    const run = opChain.then(operation, operation)
    opChain = run.then(
      () => undefined,
      () => undefined,
    )
    return run
  }

  async function loadLedger() {
    try {
      const text = await readFile(join(root, LEDGER), 'utf8')
      const parsed = JSON.parse(text)
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {}
    } catch {
      return {}
    }
  }

  function persistLedger(data) {
    const text = JSON.stringify(data ?? {}, null, 2)
    writeChain = writeChain
      .then(async () => {
        await mkdir(root, { recursive: true })
        await writeFile(join(root, LEDGER), text, 'utf8')
      })
      .catch(() => {})
    return writeChain
  }

  function keyOf(kind, id) {
    return `${kind}:${id}`
  }

  async function checkPluginInstalled(packageName) {
    if (!packageName) return null
    const service = manager()
    if (!service) return null
    try {
      const bundles = await service.listBundles()
      const bundle = bundles.find((item) => item.name === packageName)
      if (!bundle) return null
      return {
        installed: Boolean(bundle.installed),
        enabled: Boolean(bundle.enabled),
        version: bundle.version || '',
        packageName: bundle.name,
        removable: Boolean(bundle.removable),
      }
    } catch {
      return null
    }
  }

  async function status({ kind, id, packageName } = {}) {
    const data = await loadLedger()
    const record = data[keyOf(kind, id)]
    const available = Boolean(manager())
    if (kind === 'skill') {
      const dir = record?.dir
      let present = false
      if (dir) {
        try {
          await stat(join(dir, 'SKILL.md'))
          present = true
        } catch {
          present = false
        }
      }
      return {
        available: Boolean(skills()),
        installed: present && Boolean(record),
        managed: Boolean(record),
        canUninstall: present && Boolean(record),
        name: record?.name || '',
        version: record?.version || '',
        dir: dir || '',
        kind,
      }
    }
    const installed = await checkPluginInstalled(record?.packageName || packageName)
    if (kind === 'plugin') {
      return {
        available,
        installed: Boolean(installed?.installed || record),
        managed: Boolean(record),
        canUninstall: Boolean(record && installed?.removable !== false),
        version: installed?.version || record?.version || '',
        packageName: installed?.packageName || record?.packageName || packageName || '',
        enabled: installed?.enabled ?? null,
        kind,
      }
    }
    if (kind === 'mcp') {
      return {
        available,
        installed: Boolean(record) && (Boolean(installed?.installed) || Boolean(record?.dir)),
        managed: Boolean(record),
        canUninstall: Boolean(record),
        version: record?.version || '',
        packageName: record?.packageName || installed?.packageName || '',
        serverName: record?.serverName || '',
        enabled: installed?.enabled ?? null,
        kind,
      }
    }
    return { available, installed: false, managed: false, canUninstall: false, kind }
  }

  async function listInstalled() {
    const data = await loadLedger()
    const items = []
    const seen = new Set()
    for (const record of Object.values(data)) {
      if (!record || !record.kind || record.id === undefined || record.kind === 'plugin') continue
      const key = keyOf(record.kind, record.id)
      if (seen.has(key)) continue
      const state = await status({ kind: record.kind, id: record.id, packageName: record.packageName })
      if (!state.installed) continue
      seen.add(key)
      items.push({
        kind: record.kind,
        id: Number(record.id),
        slug: record.slug || '',
        name: record.title || record.name || record.slug || '',
        version: String(state.version || record.version || ''),
        packageName: state.packageName || record.packageName || '',
      })
    }
    const service = manager()
    if (service) {
      try {
        const bundles = await service.listBundles()
        for (const bundle of bundles) {
          if (!bundle || !bundle.installed) continue
          const packageName = String(bundle.name || '')
          if (!packageName || seen.has(`plugin-package:${packageName}`)) continue
          seen.add(`plugin-package:${packageName}`)
          items.push({
            kind: 'plugin',
            id: null,
            slug: '',
            name: packageName,
            version: String(bundle.version || ''),
            packageName,
          })
        }
      } catch {
        /* the plugin registry may be unavailable in a minimal profile */
      }
    }
    return items
  }

  async function readSkillFile(record) {
    const text = await readFile(join(record.dir, 'SKILL.md'), 'utf8')
    const { data, body } = parseSkillManifest(text)
    const name = String(data.name || record.name || '').trim()
    if (!name) throw new HubError({ code: 'MANIFEST_INVALID', message: 'SKILL.md 缺少 name' })
    return {
      name,
      description: String(data.description || record.description || record.name || name).trim(),
      whenToUse: data.when_to_use || data.whenToUse ? String(data.when_to_use || data.whenToUse) : undefined,
      content: body.trim() || text,
    }
  }

  async function registerSkill(record) {
    const service = skills()
    if (!service) throw new HubError({ code: 'SKILLS_UNAVAILABLE', message: '当前部署没有 skill 服务，无法安装技能' })
    const meta = await readSkillFile(record)
    const previous = skillDisposers.get(meta.name)
    if (previous) {
      try {
        previous()
      } catch {
        /* ignore */
      }
      skillDisposers.delete(meta.name)
    }
    let existing = []
    try {
      existing = await service.list({ cwd: record.dir })
    } catch {
      existing = []
    }
    if (existing.some((item) => item.name === meta.name && item.provider !== 'asset-hub' && !ownedSkillNames.has(meta.name))) {
      throw new HubError({ code: 'SKILL_NAME_TAKEN', message: `技能名称已被占用：${meta.name}` })
    }
    const disposer = service.register({
      name: meta.name,
      description: meta.description,
      whenToUse: meta.whenToUse,
      content: meta.content,
      path: join(record.dir, 'SKILL.md'),
      resourceBase: { kind: 'directory', path: record.dir },
      invocation: { modelInvocable: true, userInvocable: true },
      source: 'custom',
      provider: 'asset-hub',
    })
    skillDisposers.set(meta.name, disposer)
    ownedSkillNames.add(meta.name)
    return meta
  }

  async function restoreSkills() {
    const data = await loadLedger()
    for (const record of Object.values(data)) {
      if (!record || record.kind !== 'skill' || !record.dir) continue
      try {
        await stat(join(record.dir, 'SKILL.md'))
        const meta = await registerSkill(record)
        record.name = meta.name
      } catch {
        /* a missing or broken skill stays out of the catalog until reinstalled */
      }
    }
  }

  async function writeAssetFiles(kind, id, version, dir) {
    const listing = await withHub((client) => client.files(kind, id, version))
    const files = flattenFiles(listing)
    if (files.length === 0) throw new HubError({ code: 'BUNDLE_INVALID', message: '包内没有文件' })
    await rm(dir, { recursive: true, force: true })
    await mkdir(dir, { recursive: true })
    const skipped = []
    let written = 0
    for (const file of files.slice(0, MAX_SKILL_FILES)) {
      if (file.size && Number(file.size) > LARGE_FILE) {
        skipped.push({ path: file.path, reason: 'too-large' })
        continue
      }
      const target = safeJoin(dir, file.path)
      try {
        const text = await withHub((client) => client.file(kind, id, file.path, version))
        await mkdir(dirname(target), { recursive: true })
        await writeFile(target, text, 'utf8')
        written += 1
      } catch (error) {
        skipped.push({ path: file.path, reason: error?.code || 'unreadable' })
      }
    }
    return { written, skipped }
  }

  async function installSkill(asset) {
    const id = asset.id
    const version = assetVersion(asset)
    const slug = sanitizeSegment(assetSlug(asset))
    const dir = join(skillsRoot, `${slug}-${id}`)
    const priorData = await loadLedger()
    const prior = priorData[keyOf('skill', id)]
    const written = await writeAssetFiles('skill', id, version, dir)
    try {
      await stat(join(dir, 'SKILL.md'))
    } catch {
      throw new HubError({ code: 'MANIFEST_INVALID', message: '技能包根目录缺少 SKILL.md' })
    }
    const record = {
      kind: 'skill',
      id,
      name: '',
      slug: assetSlug(asset),
      title: asset.name || assetSlug(asset),
      version,
      dir,
      installedAt: new Date().toISOString(),
    }
    const meta = await registerSkill(record)
    record.name = meta.name
    record.description = meta.description
    if (prior?.name && prior.name !== meta.name) {
      const oldDisposer = skillDisposers.get(prior.name)
      if (oldDisposer) {
        try {
          oldDisposer()
        } catch {
          /* ignore */
        }
        skillDisposers.delete(prior.name)
      }
    }
    const data = await loadLedger()
    data[keyOf('skill', id)] = record
    await persistLedger(data)
    return {
      kind: 'skill',
      installed: true,
      upgraded: Boolean(prior),
      from: prior?.version || '',
      name: meta.name,
      description: meta.description,
      dir,
      files: written.written,
      skipped: written.skipped,
    }
  }

  async function installMcp(asset) {
    const id = asset.id
    const version = assetVersion(asset)
    const slug = sanitizeSegment(assetSlug(asset))
    const priorData = await loadLedger()
    const prior = priorData[keyOf('mcp', id)]
    const listing = await withHub((client) => client.files('mcp', id, version))
    const files = flattenFiles(listing)
    const manifest = files.find((file) => file.path === 'mcp.json') || files.find((file) => /(^|\/)mcp\.json$/i.test(file.path) && file.path.split('/').length <= 2)
    if (!manifest) throw new HubError({ code: 'MANIFEST_INVALID', message: 'MCP 包根目录缺少 mcp.json' })
    const text = await withHub((client) => client.file('mcp', id, manifest.path, version))
    let parsed
    try {
      parsed = JSON.parse(text)
    } catch {
      throw new HubError({ code: 'MANIFEST_INVALID', message: 'mcp.json 不是合法 JSON' })
    }
    const config = normalizeMcpManifest(parsed, slug)
    const packageName = `${MCP_PACKAGE_PREFIX}${slug}-${id}`
    const rowId = `mcp-${slug}-${id}`
    const dir = join(mcpRoot, `${slug}-${id}`)
    await rm(dir, { recursive: true, force: true })
    await mkdir(dir, { recursive: true })
    const manifestJson = {
      name: packageName,
      version: '1.0.0',
      private: true,
      type: 'module',
      description: `MCP server ${config.serverName} (asset ${id})`,
      engines: { dsh: '>=0.2.0 <0.3.0' },
      dsh: { bundle: { patch: './cordis.patch.yml' } },
    }
    const patch = [{ insert: [{ id: rowId, name: MCP_CLIENT, config }] }]
    await writeFile(join(dir, 'package.json'), `${JSON.stringify(manifestJson, null, 2)}\n`, 'utf8')
    await writeFile(join(dir, 'cordis.patch.yml'), `${JSON.stringify(patch, null, 2)}\n`, 'utf8')

    const service = manager()
    if (!service) throw new HubError({ code: 'PLUGIN_MANAGER_UNAVAILABLE', message: '当前部署没有插件管理器，无法安装 MCP' })
    if (prior?.packageName && prior.packageName !== packageName) {
      try {
        await service.removeBundle(prior.packageName)
      } catch {
        /* an orphaned old bundle is reported by the list, not fatal here */
      }
    }
    let result = await service.installBundle(dir, { enabled: true, saveExact: true })
    if (result?.error?.code === 'already-installed') {
      try {
        await service.removeBundle(packageName)
      } catch {
        /* continue to the original failure below */
      }
      result = await service.installBundle(dir, { enabled: true, saveExact: true })
    }
    if (result?.error) {
      throw new HubError({
        code: result.error.code || 'INSTALL_FAILED',
        message: `MCP 安装失败：${result.error.code || 'unknown'}${result.error.diagnostic ? `（${result.error.diagnostic}）` : ''}`,
        details: result,
      })
    }
    const record = {
      kind: 'mcp',
      id,
      slug: assetSlug(asset),
      title: asset.name || assetSlug(asset),
      version,
      packageName,
      serverName: config.serverName,
      dir,
      installedAt: new Date().toISOString(),
    }
    const data = await loadLedger()
    data[keyOf('mcp', id)] = record
    await persistLedger(data)
    return {
      kind: 'mcp',
      installed: true,
      upgraded: Boolean(prior),
      from: prior?.version || '',
      packageName,
      serverName: config.serverName,
      transport: config.transport,
      application: result.application,
      restartRequired: result.application === 'restart-required',
    }
  }

  async function downloadPluginTarball(asset, version, tag) {
    const packageName = String(asset.package_name || 'plugin')
    const downloaded = await withHub((client) => client.download('plugin', asset.id, version || undefined))
    const dir = join(pluginsRoot, `${sanitizeSegment(packageName)}-${sanitizeSegment(tag || version || 'latest', 'latest')}`)
    await mkdir(dir, { recursive: true })
    const filename = downloaded.filename || `${packageName}-${version || 'latest'}.tgz`
    const tarball = safeJoin(dir, filename)
    await writeFile(tarball, downloaded.buffer)
    return { tarball, dir }
  }

  async function installPlugin(asset) {
    const id = asset.id
    const packageName = String(asset.package_name || '')
    if (!packageName) throw new HubError({ code: 'VALIDATION_ERROR', message: '资产缺少 package_name' })
    const version = assetVersion(asset)
    const service = manager()
    if (!service) throw new HubError({ code: 'PLUGIN_MANAGER_UNAVAILABLE', message: '当前部署没有插件管理器，无法安装插件' })

    const installedInfo = await checkPluginInstalled(packageName)
    const currentVersion = installedInfo?.version || ''
    if (installedInfo?.installed && (!version || currentVersion === version)) {
      return {
        kind: 'plugin',
        installed: true,
        already: true,
        packageName,
        version: currentVersion || version,
        application: null,
        restartRequired: false,
        warnings: [],
      }
    }

    const target = await downloadPluginTarball(asset, version, version || 'latest')
    const record = {
      kind: 'plugin',
      id,
      slug: assetSlug(asset),
      title: asset.name || packageName,
      version: version || currentVersion,
      packageName,
      tarball: target.tarball,
      dir: target.dir,
      installedAt: new Date().toISOString(),
    }

    if (!installedInfo?.installed) {
      const result = await service.installBundle(target.tarball, { enabled: true, saveExact: true })
      const already = result?.error?.code === 'already-installed'
      if (result?.error && !already) {
        throw new HubError({
          code: result.error.code || 'INSTALL_FAILED',
          message: `插件安装失败：${result.error.code || 'unknown'}${result.error.diagnostic ? `（${result.error.diagnostic}）` : ''}`,
          details: result,
        })
      }
      if (result?.pendingBuilds?.length) {
        throw new HubError({
          code: 'BUILD_APPROVAL_REQUIRED',
          message: `插件需要允许构建脚本：${result.pendingBuilds.join(', ')}`,
          details: result,
        })
      }
      const info = await checkPluginInstalled(packageName)
      record.version = info?.version || version
      const data = await loadLedger()
      data[keyOf('plugin', id)] = record
      await persistLedger(data)
      return {
        kind: 'plugin',
        installed: true,
        already,
        packageName: record.packageName,
        version: record.version,
        application: already ? null : result?.application || null,
        restartRequired: result?.application === 'restart-required',
        warnings: result?.warnings || [],
      }
    }

    // Upgrade: the installed version differs from the asset's version.
    const from = currentVersion
    let rollback = null
    if (from) {
      try {
        rollback = await downloadPluginTarball(asset, from, `rollback-${from}`)
      } catch {
        rollback = null
      }
    }
    const to = version || from

    if (packageName === 'dsh-asset-hub') {
      if (selfUpdating) {
        throw new HubError({ code: 'UPDATE_IN_PROGRESS', message: '运维工坊仓库正在更新，请稍候' })
      }
      selfUpdating = true
      // Self-update: answer the request first, then replace the running bundle.
      // The page disconnects while its own plugin is unloaded and reinstalled.
      setTimeout(async () => {
        try {
          await service.removeBundle(packageName)
          const result = await service.installBundle(target.tarball, { enabled: true, saveExact: true })
          if (result?.error) throw new Error(result.error.code || 'install-failed')
          const data = await loadLedger()
          data[keyOf('plugin', id)] = { ...record, version: to }
          await persistLedger(data)
        } catch {
          if (rollback) {
            try {
              await service.installBundle(rollback.tarball, { enabled: true, saveExact: true })
            } catch {
              /* the old tarball stays on disk for a manual reinstall */
            }
          }
        } finally {
          selfUpdating = false
        }
      }, 700)
      return {
        kind: 'plugin',
        installed: true,
        updating: true,
        self: true,
        from,
        to,
        packageName,
        restartRequired: true,
      }
    }

    const removed = await service.removeBundle(packageName)
    if (removed?.error && removed.error.code !== 'unknown-plugin') {
      throw new HubError({
        code: removed.error.code || 'UNINSTALL_FAILED',
        message: `更新前卸载旧版本失败：${removed.error.code}`,
        details: removed,
      })
    }
    const result = await service.installBundle(target.tarball, { enabled: true, saveExact: true })
    if (result?.error || result?.pendingBuilds?.length) {
      if (rollback) {
        try {
          await service.installBundle(rollback.tarball, { enabled: true, saveExact: true })
        } catch {
          /* manual recovery remains */
        }
      }
      throw new HubError({
        code: result?.error?.code || 'BUILD_APPROVAL_REQUIRED',
        message: `插件更新失败${result?.error?.code ? `：${result.error.code}` : '：需要允许构建脚本'}`,
        details: result,
      })
    }
    const info = await checkPluginInstalled(packageName)
    record.version = info?.version || to
    const data = await loadLedger()
    data[keyOf('plugin', id)] = record
    await persistLedger(data)
    return {
      kind: 'plugin',
      installed: true,
      upgraded: true,
      from,
      to: record.version,
      packageName,
      application: result?.application || null,
      restartRequired: result?.application === 'restart-required',
      warnings: result?.warnings || [],
    }
  }

  async function install(asset) {
    if (!asset || !asset.kind) throw new HubError({ code: 'VALIDATION_ERROR', message: '缺少资产信息' })
    return serialize(async () => {
      if (asset.kind === 'skill') return installSkill(asset)
      if (asset.kind === 'mcp') return installMcp(asset)
      if (asset.kind === 'plugin') return installPlugin(asset)
      throw new HubError({ code: 'VALIDATION_ERROR', message: `不支持安装的类型：${asset.kind}` })
    })
  }

  async function uninstall({ kind, id } = {}) {
    return serialize(async () => {
      const data = await loadLedger()
      const record = data[keyOf(kind, id)]
      if (!record) throw new HubError({ code: 'NOT_INSTALLED', message: '这个资产不是由本页面安装的，未找到安装记录' })
      if (kind === 'skill') {
        const disposer = skillDisposers.get(record.name)
        if (disposer) {
          try {
            disposer()
          } catch {
            /* ignore */
          }
          skillDisposers.delete(record.name)
        }
        await rm(record.dir, { recursive: true, force: true })
      } else {
        const service = manager()
        if (!service) throw new HubError({ code: 'PLUGIN_MANAGER_UNAVAILABLE', message: '当前部署没有插件管理器' })
        if (kind === 'plugin' && record.packageName === 'dsh-asset-hub') {
          throw new HubError({ code: 'REFUSED', message: '不能在运维工坊仓库页面里卸载它自己，请到插件管理页操作' })
        }
        const result = await service.removeBundle(record.packageName)
        if (result?.error && result.error.code !== 'unknown-plugin') {
          throw new HubError({
            code: result.error.code || 'UNINSTALL_FAILED',
            message: `卸载失败：${result.error.code}${result.error.diagnostic ? `（${result.error.diagnostic}）` : ''}`,
            details: result,
          })
        }
        if (record.dir) await rm(record.dir, { recursive: true, force: true }).catch(() => {})
        if (record.tarball) await rm(record.tarball, { force: true }).catch(() => {})
      }
      delete data[keyOf(kind, id)]
      await persistLedger(data)
      return { kind, id, uninstalled: true }
    })
  }

  return {
    status,
    listInstalled,
    install,
    uninstall,
    restoreSkills,
    root,
  }
}
